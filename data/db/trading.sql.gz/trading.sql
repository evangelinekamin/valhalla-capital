--
-- PostgreSQL database dump
--

\restrict 6c6dlX5UwPd37AzwVZmFUVWgGOC3yHyvJAws8rd8bvmxAWJgPuXlhazqkRIPUoB

-- Dumped from database version 15.17
-- Dumped by pg_dump version 15.17

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: timescaledb; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS timescaledb WITH SCHEMA public;


--
-- Name: EXTENSION timescaledb; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION timescaledb IS 'Enables scalable inserts and complex queries for time-series data (Community Edition)';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: trades; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trades (
    id integer NOT NULL,
    request_id uuid NOT NULL,
    "timestamp" timestamp with time zone NOT NULL,
    ticker character varying(10) NOT NULL,
    action character varying(4) NOT NULL,
    quantity double precision NOT NULL,
    order_type character varying(20) DEFAULT 'MARKET'::character varying NOT NULL,
    status character varying(20) NOT NULL,
    filled_price double precision,
    commission double precision,
    order_id integer,
    reason text,
    kelly_fraction double precision,
    half_kelly_fraction double precision,
    portfolio_value_at_trade double precision,
    analysis_data jsonb,
    dry_run boolean DEFAULT false NOT NULL
);


--
-- Name: _hyper_2_10_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_2_10_chunk (
    CONSTRAINT constraint_9 CHECK ((("timestamp" >= '2026-04-30 00:00:00+00'::timestamp with time zone) AND ("timestamp" < '2026-05-07 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.trades);


--
-- Name: _hyper_2_11_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_2_11_chunk (
    CONSTRAINT constraint_10 CHECK ((("timestamp" >= '2026-05-07 00:00:00+00'::timestamp with time zone) AND ("timestamp" < '2026-05-14 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.trades);


--
-- Name: _hyper_2_12_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_2_12_chunk (
    CONSTRAINT constraint_11 CHECK ((("timestamp" >= '2026-05-14 00:00:00+00'::timestamp with time zone) AND ("timestamp" < '2026-05-21 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.trades);


--
-- Name: _hyper_2_13_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_2_13_chunk (
    CONSTRAINT constraint_12 CHECK ((("timestamp" >= '2026-05-21 00:00:00+00'::timestamp with time zone) AND ("timestamp" < '2026-05-28 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.trades);


--
-- Name: _hyper_2_14_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_2_14_chunk (
    CONSTRAINT constraint_13 CHECK ((("timestamp" >= '2026-05-28 00:00:00+00'::timestamp with time zone) AND ("timestamp" < '2026-06-04 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.trades);


--
-- Name: _hyper_2_15_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_2_15_chunk (
    CONSTRAINT constraint_14 CHECK ((("timestamp" >= '2026-06-04 00:00:00+00'::timestamp with time zone) AND ("timestamp" < '2026-06-11 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.trades);


--
-- Name: _hyper_2_16_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_2_16_chunk (
    CONSTRAINT constraint_15 CHECK ((("timestamp" >= '2026-06-11 00:00:00+00'::timestamp with time zone) AND ("timestamp" < '2026-06-18 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.trades);


--
-- Name: _hyper_2_1_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_2_1_chunk (
    CONSTRAINT constraint_1 CHECK ((("timestamp" >= '2026-02-19 00:00:00+00'::timestamp with time zone) AND ("timestamp" < '2026-02-26 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.trades);


--
-- Name: _hyper_2_3_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_2_3_chunk (
    CONSTRAINT constraint_3 CHECK ((("timestamp" >= '2026-03-12 00:00:00+00'::timestamp with time zone) AND ("timestamp" < '2026-03-19 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.trades);


--
-- Name: _hyper_2_4_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_2_4_chunk (
    CONSTRAINT constraint_4 CHECK ((("timestamp" >= '2026-03-19 00:00:00+00'::timestamp with time zone) AND ("timestamp" < '2026-03-26 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.trades);


--
-- Name: _hyper_2_5_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_2_5_chunk (
    CONSTRAINT constraint_5 CHECK ((("timestamp" >= '2026-04-02 00:00:00+00'::timestamp with time zone) AND ("timestamp" < '2026-04-09 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.trades);


--
-- Name: _hyper_2_6_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_2_6_chunk (
    CONSTRAINT constraint_6 CHECK ((("timestamp" >= '2026-04-09 00:00:00+00'::timestamp with time zone) AND ("timestamp" < '2026-04-16 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.trades);


--
-- Name: _hyper_2_7_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_2_7_chunk (
    CONSTRAINT constraint_7 CHECK ((("timestamp" >= '2026-04-16 00:00:00+00'::timestamp with time zone) AND ("timestamp" < '2026-04-23 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.trades);


--
-- Name: _hyper_2_8_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_2_8_chunk (
    CONSTRAINT constraint_8 CHECK ((("timestamp" >= '2026-04-23 00:00:00+00'::timestamp with time zone) AND ("timestamp" < '2026-04-30 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.trades);


--
-- Name: _hyper_2_9_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_2_9_chunk (
    CONSTRAINT constraint_9 CHECK ((("timestamp" >= '2026-04-30 00:00:00+00'::timestamp with time zone) AND ("timestamp" < '2026-05-07 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.trades);


--
-- Name: portfolio_snapshots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.portfolio_snapshots (
    id integer NOT NULL,
    "timestamp" timestamp with time zone NOT NULL,
    total_value double precision NOT NULL,
    cash_balance double precision NOT NULL,
    positions jsonb DEFAULT '{}'::jsonb NOT NULL,
    daily_pnl double precision DEFAULT 0 NOT NULL,
    daily_pnl_pct double precision DEFAULT 0 NOT NULL
);


--
-- Name: _hyper_3_2_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_3_2_chunk (
    CONSTRAINT constraint_2 CHECK ((("timestamp" >= '2026-02-19 00:00:00+00'::timestamp with time zone) AND ("timestamp" < '2026-02-20 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.portfolio_snapshots);


--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


--
-- Name: claude_decisions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.claude_decisions (
    id integer NOT NULL,
    "timestamp" timestamp with time zone DEFAULT now() NOT NULL,
    ticker character varying(10),
    decision character varying(20) NOT NULL,
    confidence double precision NOT NULL,
    win_probability double precision NOT NULL,
    expected_gain_pct double precision NOT NULL,
    expected_loss_pct double precision NOT NULL,
    reasoning text NOT NULL,
    data_sources jsonb,
    trade_id integer
);


--
-- Name: claude_decisions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.claude_decisions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: claude_decisions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.claude_decisions_id_seq OWNED BY public.claude_decisions.id;


--
-- Name: portfolio_snapshots_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.portfolio_snapshots_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: portfolio_snapshots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.portfolio_snapshots_id_seq OWNED BY public.portfolio_snapshots.id;


--
-- Name: risk_checks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.risk_checks (
    id integer NOT NULL,
    trade_id integer,
    check_name character varying(50) NOT NULL,
    result character varying(20) NOT NULL,
    message text NOT NULL,
    details jsonb,
    "timestamp" timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: risk_checks_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.risk_checks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: risk_checks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.risk_checks_id_seq OWNED BY public.risk_checks.id;


--
-- Name: trades_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.trades_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: trades_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.trades_id_seq OWNED BY public.trades.id;


--
-- Name: _hyper_2_10_chunk id; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_2_10_chunk ALTER COLUMN id SET DEFAULT nextval('public.trades_id_seq'::regclass);


--
-- Name: _hyper_2_10_chunk order_type; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_2_10_chunk ALTER COLUMN order_type SET DEFAULT 'MARKET'::character varying;


--
-- Name: _hyper_2_10_chunk dry_run; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_2_10_chunk ALTER COLUMN dry_run SET DEFAULT false;


--
-- Name: _hyper_2_11_chunk id; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_2_11_chunk ALTER COLUMN id SET DEFAULT nextval('public.trades_id_seq'::regclass);


--
-- Name: _hyper_2_11_chunk order_type; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_2_11_chunk ALTER COLUMN order_type SET DEFAULT 'MARKET'::character varying;


--
-- Name: _hyper_2_11_chunk dry_run; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_2_11_chunk ALTER COLUMN dry_run SET DEFAULT false;


--
-- Name: _hyper_2_12_chunk id; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_2_12_chunk ALTER COLUMN id SET DEFAULT nextval('public.trades_id_seq'::regclass);


--
-- Name: _hyper_2_12_chunk order_type; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_2_12_chunk ALTER COLUMN order_type SET DEFAULT 'MARKET'::character varying;


--
-- Name: _hyper_2_12_chunk dry_run; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_2_12_chunk ALTER COLUMN dry_run SET DEFAULT false;


--
-- Name: _hyper_2_13_chunk id; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_2_13_chunk ALTER COLUMN id SET DEFAULT nextval('public.trades_id_seq'::regclass);


--
-- Name: _hyper_2_13_chunk order_type; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_2_13_chunk ALTER COLUMN order_type SET DEFAULT 'MARKET'::character varying;


--
-- Name: _hyper_2_13_chunk dry_run; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_2_13_chunk ALTER COLUMN dry_run SET DEFAULT false;


--
-- Name: _hyper_2_14_chunk id; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_2_14_chunk ALTER COLUMN id SET DEFAULT nextval('public.trades_id_seq'::regclass);


--
-- Name: _hyper_2_14_chunk order_type; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_2_14_chunk ALTER COLUMN order_type SET DEFAULT 'MARKET'::character varying;


--
-- Name: _hyper_2_14_chunk dry_run; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_2_14_chunk ALTER COLUMN dry_run SET DEFAULT false;


--
-- Name: _hyper_2_15_chunk id; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_2_15_chunk ALTER COLUMN id SET DEFAULT nextval('public.trades_id_seq'::regclass);


--
-- Name: _hyper_2_15_chunk order_type; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_2_15_chunk ALTER COLUMN order_type SET DEFAULT 'MARKET'::character varying;


--
-- Name: _hyper_2_15_chunk dry_run; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_2_15_chunk ALTER COLUMN dry_run SET DEFAULT false;


--
-- Name: _hyper_2_16_chunk id; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_2_16_chunk ALTER COLUMN id SET DEFAULT nextval('public.trades_id_seq'::regclass);


--
-- Name: _hyper_2_16_chunk order_type; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_2_16_chunk ALTER COLUMN order_type SET DEFAULT 'MARKET'::character varying;


--
-- Name: _hyper_2_16_chunk dry_run; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_2_16_chunk ALTER COLUMN dry_run SET DEFAULT false;


--
-- Name: _hyper_2_1_chunk id; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_2_1_chunk ALTER COLUMN id SET DEFAULT nextval('public.trades_id_seq'::regclass);


--
-- Name: _hyper_2_1_chunk order_type; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_2_1_chunk ALTER COLUMN order_type SET DEFAULT 'MARKET'::character varying;


--
-- Name: _hyper_2_1_chunk dry_run; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_2_1_chunk ALTER COLUMN dry_run SET DEFAULT false;


--
-- Name: _hyper_2_3_chunk id; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_2_3_chunk ALTER COLUMN id SET DEFAULT nextval('public.trades_id_seq'::regclass);


--
-- Name: _hyper_2_3_chunk order_type; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_2_3_chunk ALTER COLUMN order_type SET DEFAULT 'MARKET'::character varying;


--
-- Name: _hyper_2_3_chunk dry_run; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_2_3_chunk ALTER COLUMN dry_run SET DEFAULT false;


--
-- Name: _hyper_2_4_chunk id; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_2_4_chunk ALTER COLUMN id SET DEFAULT nextval('public.trades_id_seq'::regclass);


--
-- Name: _hyper_2_4_chunk order_type; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_2_4_chunk ALTER COLUMN order_type SET DEFAULT 'MARKET'::character varying;


--
-- Name: _hyper_2_4_chunk dry_run; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_2_4_chunk ALTER COLUMN dry_run SET DEFAULT false;


--
-- Name: _hyper_2_5_chunk id; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_2_5_chunk ALTER COLUMN id SET DEFAULT nextval('public.trades_id_seq'::regclass);


--
-- Name: _hyper_2_5_chunk order_type; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_2_5_chunk ALTER COLUMN order_type SET DEFAULT 'MARKET'::character varying;


--
-- Name: _hyper_2_5_chunk dry_run; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_2_5_chunk ALTER COLUMN dry_run SET DEFAULT false;


--
-- Name: _hyper_2_6_chunk id; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_2_6_chunk ALTER COLUMN id SET DEFAULT nextval('public.trades_id_seq'::regclass);


--
-- Name: _hyper_2_6_chunk order_type; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_2_6_chunk ALTER COLUMN order_type SET DEFAULT 'MARKET'::character varying;


--
-- Name: _hyper_2_6_chunk dry_run; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_2_6_chunk ALTER COLUMN dry_run SET DEFAULT false;


--
-- Name: _hyper_2_7_chunk id; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_2_7_chunk ALTER COLUMN id SET DEFAULT nextval('public.trades_id_seq'::regclass);


--
-- Name: _hyper_2_7_chunk order_type; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_2_7_chunk ALTER COLUMN order_type SET DEFAULT 'MARKET'::character varying;


--
-- Name: _hyper_2_7_chunk dry_run; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_2_7_chunk ALTER COLUMN dry_run SET DEFAULT false;


--
-- Name: _hyper_2_8_chunk id; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_2_8_chunk ALTER COLUMN id SET DEFAULT nextval('public.trades_id_seq'::regclass);


--
-- Name: _hyper_2_8_chunk order_type; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_2_8_chunk ALTER COLUMN order_type SET DEFAULT 'MARKET'::character varying;


--
-- Name: _hyper_2_8_chunk dry_run; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_2_8_chunk ALTER COLUMN dry_run SET DEFAULT false;


--
-- Name: _hyper_2_9_chunk id; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_2_9_chunk ALTER COLUMN id SET DEFAULT nextval('public.trades_id_seq'::regclass);


--
-- Name: _hyper_2_9_chunk order_type; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_2_9_chunk ALTER COLUMN order_type SET DEFAULT 'MARKET'::character varying;


--
-- Name: _hyper_2_9_chunk dry_run; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_2_9_chunk ALTER COLUMN dry_run SET DEFAULT false;


--
-- Name: _hyper_3_2_chunk id; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_3_2_chunk ALTER COLUMN id SET DEFAULT nextval('public.portfolio_snapshots_id_seq'::regclass);


--
-- Name: _hyper_3_2_chunk positions; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_3_2_chunk ALTER COLUMN positions SET DEFAULT '{}'::jsonb;


--
-- Name: _hyper_3_2_chunk daily_pnl; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_3_2_chunk ALTER COLUMN daily_pnl SET DEFAULT 0;


--
-- Name: _hyper_3_2_chunk daily_pnl_pct; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_3_2_chunk ALTER COLUMN daily_pnl_pct SET DEFAULT 0;


--
-- Name: claude_decisions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.claude_decisions ALTER COLUMN id SET DEFAULT nextval('public.claude_decisions_id_seq'::regclass);


--
-- Name: portfolio_snapshots id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.portfolio_snapshots ALTER COLUMN id SET DEFAULT nextval('public.portfolio_snapshots_id_seq'::regclass);


--
-- Name: risk_checks id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.risk_checks ALTER COLUMN id SET DEFAULT nextval('public.risk_checks_id_seq'::regclass);


--
-- Name: trades id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trades ALTER COLUMN id SET DEFAULT nextval('public.trades_id_seq'::regclass);


--
-- Data for Name: hypertable; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: -
--

COPY _timescaledb_catalog.hypertable (id, schema_name, table_name, associated_schema_name, associated_table_prefix, num_dimensions, chunk_sizing_func_schema, chunk_sizing_func_name, chunk_target_size, compression_state, compressed_hypertable_id, status) FROM stdin;
2	public	trades	_timescaledb_internal	_hyper_2	1	_timescaledb_functions	calculate_chunk_interval	0	0	\N	0
3	public	portfolio_snapshots	_timescaledb_internal	_hyper_3	1	_timescaledb_functions	calculate_chunk_interval	0	0	\N	0
\.


--
-- Data for Name: bgw_job; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: -
--

COPY _timescaledb_catalog.bgw_job (id, application_name, schedule_interval, max_runtime, max_retries, retry_period, proc_schema, proc_name, owner, scheduled, fixed_schedule, initial_start, hypertable_id, config, check_schema, check_name, timezone) FROM stdin;
\.


--
-- Data for Name: chunk; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: -
--

COPY _timescaledb_catalog.chunk (id, hypertable_id, schema_name, table_name, compressed_chunk_id, status, osm_chunk, creation_time) FROM stdin;
10	2	_timescaledb_internal	_hyper_2_10_chunk	\N	0	f	2026-05-01 14:01:06.84924+00
11	2	_timescaledb_internal	_hyper_2_11_chunk	\N	0	f	2026-05-07 14:02:03.424074+00
12	2	_timescaledb_internal	_hyper_2_12_chunk	\N	0	f	2026-05-14 14:01:40.75912+00
13	2	_timescaledb_internal	_hyper_2_13_chunk	\N	0	f	2026-05-21 16:04:37.906494+00
14	2	_timescaledb_internal	_hyper_2_14_chunk	\N	0	f	2026-05-28 14:02:50.066469+00
15	2	_timescaledb_internal	_hyper_2_15_chunk	\N	0	f	2026-06-08 14:02:59.53527+00
16	2	_timescaledb_internal	_hyper_2_16_chunk	\N	0	f	2026-06-11 14:02:03.504134+00
\.


--
-- Data for Name: chunk_column_stats; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: -
--

COPY _timescaledb_catalog.chunk_column_stats (id, hypertable_id, chunk_id, column_name, range_start, range_end, valid) FROM stdin;
\.


--
-- Data for Name: dimension; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: -
--

COPY _timescaledb_catalog.dimension (id, hypertable_id, column_name, column_type, aligned, num_slices, partitioning_func_schema, partitioning_func, interval_length, compress_interval_length, integer_now_func_schema, integer_now_func) FROM stdin;
2	2	timestamp	timestamp with time zone	t	\N	\N	\N	604800000000	\N	\N	\N
3	3	timestamp	timestamp with time zone	t	\N	\N	\N	86400000000	\N	\N	\N
\.


--
-- Data for Name: dimension_slice; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: -
--

COPY _timescaledb_catalog.dimension_slice (id, dimension_id, range_start, range_end) FROM stdin;
1	2	1771459200000000	1772064000000000
2	3	1771459200000000	1771545600000000
3	2	1773273600000000	1773878400000000
4	2	1773878400000000	1774483200000000
5	2	1775088000000000	1775692800000000
6	2	1775692800000000	1776297600000000
7	2	1776297600000000	1776902400000000
8	2	1776902400000000	1777507200000000
9	2	1777507200000000	1778112000000000
10	2	1778112000000000	1778716800000000
11	2	1778716800000000	1779321600000000
12	2	1779321600000000	1779926400000000
13	2	1779926400000000	1780531200000000
14	2	1780531200000000	1781136000000000
15	2	1781136000000000	1781740800000000
\.


--
-- Data for Name: chunk_constraint; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: -
--

COPY _timescaledb_catalog.chunk_constraint (chunk_id, dimension_slice_id, constraint_name, hypertable_constraint_name) FROM stdin;
10	9	constraint_9	\N
11	10	constraint_10	\N
12	11	constraint_11	\N
13	12	constraint_12	\N
14	13	constraint_13	\N
15	14	constraint_14	\N
16	15	constraint_15	\N
\.


--
-- Data for Name: compression_chunk_size; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: -
--

COPY _timescaledb_catalog.compression_chunk_size (chunk_id, compressed_chunk_id, uncompressed_heap_size, uncompressed_toast_size, uncompressed_index_size, compressed_heap_size, compressed_toast_size, compressed_index_size, numrows_pre_compression, numrows_post_compression, numrows_frozen_immediately) FROM stdin;
\.


--
-- Data for Name: compression_settings; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: -
--

COPY _timescaledb_catalog.compression_settings (relid, compress_relid, segmentby, orderby, orderby_desc, orderby_nullsfirst, index) FROM stdin;
\.


--
-- Data for Name: continuous_agg; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: -
--

COPY _timescaledb_catalog.continuous_agg (mat_hypertable_id, raw_hypertable_id, parent_mat_hypertable_id, user_view_schema, user_view_name, partial_view_schema, partial_view_name, direct_view_schema, direct_view_name, materialized_only) FROM stdin;
\.


--
-- Data for Name: continuous_aggs_bucket_function; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: -
--

COPY _timescaledb_catalog.continuous_aggs_bucket_function (mat_hypertable_id, bucket_func, bucket_width, bucket_origin, bucket_offset, bucket_timezone, bucket_fixed_width) FROM stdin;
\.


--
-- Data for Name: continuous_aggs_hypertable_invalidation_log; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: -
--

COPY _timescaledb_catalog.continuous_aggs_hypertable_invalidation_log (hypertable_id, lowest_modified_value, greatest_modified_value) FROM stdin;
\.


--
-- Data for Name: continuous_aggs_invalidation_threshold; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: -
--

COPY _timescaledb_catalog.continuous_aggs_invalidation_threshold (hypertable_id, watermark) FROM stdin;
\.


--
-- Data for Name: continuous_aggs_jobs_refresh_ranges; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: -
--

COPY _timescaledb_catalog.continuous_aggs_jobs_refresh_ranges (materialization_id, start_range, end_range, pid, job_id, created_at) FROM stdin;
\.


--
-- Data for Name: continuous_aggs_materialization_invalidation_log; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: -
--

COPY _timescaledb_catalog.continuous_aggs_materialization_invalidation_log (materialization_id, lowest_modified_value, greatest_modified_value) FROM stdin;
\.


--
-- Data for Name: continuous_aggs_materialization_ranges; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: -
--

COPY _timescaledb_catalog.continuous_aggs_materialization_ranges (materialization_id, lowest_modified_value, greatest_modified_value) FROM stdin;
\.


--
-- Data for Name: continuous_aggs_watermark; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: -
--

COPY _timescaledb_catalog.continuous_aggs_watermark (mat_hypertable_id, watermark) FROM stdin;
\.


--
-- Data for Name: metadata; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: -
--

COPY _timescaledb_catalog.metadata (key, value, include_in_telemetry) FROM stdin;
install_timestamp	2026-02-14 17:27:42.851822+00	t
timescaledb_version	2.25.0	f
exported_uuid	d7833821-4dc3-405a-b8e0-086d31ee9cc1	t
\.


--
-- Data for Name: tablespace; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: -
--

COPY _timescaledb_catalog.tablespace (id, hypertable_id, tablespace_name) FROM stdin;
\.


--
-- Data for Name: _hyper_2_10_chunk; Type: TABLE DATA; Schema: _timescaledb_internal; Owner: -
--

COPY _timescaledb_internal._hyper_2_10_chunk (id, request_id, "timestamp", ticker, action, quantity, order_type, status, filled_price, commission, order_id, reason, kelly_fraction, half_kelly_fraction, portfolio_value_at_trade, analysis_data, dry_run) FROM stdin;
22	414cd984-ecb4-46f5-a584-38b6ffb2d1b3	2026-05-01 14:01:06.841667+00	CHH	SELL	1	MARKET	FILLED	102.07	1.002301	8	CHH thesis is broken due to Q1 earnings miss (EPS $0.44 vs expected). The position has -2.74% unrealized loss and 'NONE' conviction level in active theses. I would not buy CHH today at current price of $102.08, so holding is not justified. This is a clear application of sell discipline - the thesis has been invalidated by evidence.	-24.050000000000022	0	1023.96	{"confidence": 0.95, "win_probability": 0.95, "expected_gain_pct": 0.01, "expected_loss_pct": -5.0}	f
23	ae1eb1ea-d1a2-40a3-ab76-9d9cd4719378	2026-05-01 14:01:26.805173+00	BMI	BUY	1	MARKET	FILLED	121.83	1.000003	12	BMI is trading at a 10% discount to insider purchase price ($122.37 vs $136+), with strong Q1 2026 fundamentals (10.4% revenue growth, 7.2% net income growth). The company benefits from secular trends in water infrastructure modernization and smart metering adoption. Current position is 11.8% of portfolio, and adding 1 more share would bring it to ~16.5%, which is acceptable given the HIGH conviction level and strong insider alignment. The target price is $145.00, providing 18.5% upside.	0.7405405405405405	0.2	1040.38	{"confidence": 0.85, "win_probability": 0.85, "expected_gain_pct": 18.5, "expected_loss_pct": -13.5}	f
24	9a0de41f-cb1c-469f-940c-90db0bcfa15b	2026-05-01 14:01:45.793917+00	SU	BUY	2	MARKET	FILLED	66.77	1.000006	16	SU is a stable, large-cap integrated oil company benefiting from structural oil market changes (UAE OPEC exit, Hormuz blockade). With Q4 2025 net income $1.48B and EPS $1.23, SU has consistent earnings and a solid dividend yield (~2.5%). Adding SU provides diversified oil exposure that complements the existing DMLP position and addresses the TOP PRIORITY oil sector analysis need.	0.5833333333333334	0.2	1039.65	{"confidence": 0.75, "win_probability": 0.75, "expected_gain_pct": 15.0, "expected_loss_pct": -10.0}	f
\.


--
-- Data for Name: _hyper_2_11_chunk; Type: TABLE DATA; Schema: _timescaledb_internal; Owner: -
--

COPY _timescaledb_internal._hyper_2_11_chunk (id, request_id, "timestamp", ticker, action, quantity, order_type, status, filled_price, commission, order_id, reason, kelly_fraction, half_kelly_fraction, portfolio_value_at_trade, analysis_data, dry_run) FROM stdin;
25	fe920e29-f8ca-477a-8cea-5eae85771957	2026-05-07 14:02:03.420611+00	BMI	SELL	2	MARKET	FILLED	124.16	1.005511	22	BMI is 24.2% of portfolio, exceeding our 20% hard limit. This creates unacceptable concentration risk. We need to trim to approximately 15% of portfolio.	0.7	0.2	1031.04	{"confidence": 0.9, "win_probability": 0.85, "expected_gain_pct": 0.01, "expected_loss_pct": -0.01}	f
26	3f3a70f6-a0de-43fe-b790-8b3493abf3df	2026-05-07 14:02:28.468478+00	TBPH	SELL	4	MARKET	FILLED	16.81	0.674577	26	TBPH is a stub position at 6.5% of portfolio, below our 10% meaningful position threshold. Exiting frees capital for higher-conviction opportunities like GPN (5x P/E value).	0.3999999999999998	0.1999999999999999	1024.7	{"confidence": 0.8, "win_probability": 0.7, "expected_gain_pct": 0.01, "expected_loss_pct": -0.01}	f
27	c22b48c6-1713-4486-a5a7-8a07712a2e71	2026-05-08 14:02:26.545156+00	SU	SELL	1	MARKET	FILLED	63.685	0.63836	32	SU position showing concerning divergence from oil price fundamentals despite Brent at $114, with 5.4% decline from entry. Trim reduces exposure to geopolitical uncertainty while maintaining partial position for potential upside.	0.3875	0.19375	1024.23	{"confidence": 0.65, "win_probability": 0.65, "expected_gain_pct": 20.0, "expected_loss_pct": -15.0}	f
28	101e2430-3539-4e2b-b392-d50f5a193800	2026-05-08 14:02:35.807556+00	GPN	BUY	1	MARKET	FILLED	68.935	0.689353	36	GPN is trading at 5x P/E with $6.5B buyback planned, $3.4B FCF in 2026, and revenue/EBITDA/EPS up 60% from 2021-2026E. This represents a significant valuation gap versus peers and provides the best opportunity to deploy the portfolio's 44.4% cash position.	0.52	0.2	1018.06	{"confidence": 0.75, "win_probability": 0.7, "expected_gain_pct": 25.0, "expected_loss_pct": -15.0}	f
29	dbbf952e-afb4-479b-ad93-fe11bfc8654f	2026-05-13 14:03:25.142015+00	GPN	BUY	2	MARKET	FILLED	67.54	1.000006	42	GPN is a compelling value opportunity trading at 5x P/E with strong underlying business generating $849M EBITDA in Q1 2026. The $6.5B buyback program is temporarily paused but will resume as leverage improves. This represents the highest-conviction opportunity to deploy our 44% cash drag.	0.6	0.2	1017.38	{"confidence": 0.9, "win_probability": 0.75, "expected_gain_pct": 25.0, "expected_loss_pct": -15.0}	f
30	674fe158-bba8-46aa-a9e7-f9e065353f97	2026-05-13 14:03:40.5167+00	SU	SELL	1	MARKET	FILLED	66.805	0.669624	46	SU thesis is broken: persistent divergence from oil fundamentals despite Iran war and Hormuz blockade, consistent Substack sell recommendations, and Q1 beat not moving the stock. Market is pricing in demand destruction or de-escalation. Falsification criteria met: Hormuz remains closed but stock underperforms, indicating thesis invalidation.	-21.650000000000002	0	993.1	{"confidence": 0.95, "win_probability": 0.85, "expected_gain_pct": 0.01, "expected_loss_pct": -1.5}	f
\.


--
-- Data for Name: _hyper_2_12_chunk; Type: TABLE DATA; Schema: _timescaledb_internal; Owner: -
--

COPY _timescaledb_internal._hyper_2_12_chunk (id, request_id, "timestamp", ticker, action, quantity, order_type, status, filled_price, commission, order_id, reason, kelly_fraction, half_kelly_fraction, portfolio_value_at_trade, analysis_data, dry_run) FROM stdin;
31	52a79f99-d4f3-4fdd-9529-962857e8ba34	2026-05-14 14:01:40.755517+00	GPN	SELL	1	MARKET	FILLED	67.29	0.674484	52	GPN concentration exceeds 20% maximum (currently 20.35% of portfolio). Trim 1 share to reduce concentration risk and bring position to ~15% target size. This is pure risk management with no thesis change - the value thesis remains intact.	-29.150000000000002	0	992.44	{"confidence": 0.9, "win_probability": 0.85, "expected_gain_pct": 0.01, "expected_loss_pct": -2.0}	f
32	f5c89bb9-ffad-4a4e-b13a-9b4ca0014956	2026-05-14 14:01:59.79434+00	RILY	BUY	14	MARKET	FAILED	\N	\N	56	RILY is the portfolio's top performer (+11.2%) and has strong fundamentals (Q1 revenue $450M, net income $213M). It's a M&A/IPO wave beneficiary and has been consistently recommended by Substack. Adding to this high-conviction winner addresses the cash drag and underperformance.	0.7333333333333333	0.2	1004.8	{"confidence": 0.85, "win_probability": 0.8, "expected_gain_pct": 15.0, "expected_loss_pct": -5.0}	f
33	81d52503-9607-4013-9f84-cdf8d321a866	2026-05-14 14:02:14.325856+00	DMLP	BUY	4	MARKET	FILLED	27.47	1.000012	60	DMLP has performed well (+3.7%) and benefits directly from the oil crisis. With Aramco warning of critically low fuel stocks and 100M barrels lost weekly from Hormuz closure, DMLP's energy transportation thesis is strongly supported. This deployment addresses the cash drag and underperformance.	0.65	0.2	1004.8	{"confidence": 0.8, "win_probability": 0.75, "expected_gain_pct": 25.0, "expected_loss_pct": -10.0}	f
34	69923f9d-f7b2-44d5-8a76-c1d863a199c0	2026-05-14 14:02:38.26067+00	AENT	BUY	10	MARKET	FAILED	\N	\N	64	AENT has solid fundamentals (Q1 revenue $450M) and is trading near its 52-week low. Adding to this position diversifies the portfolio and addresses the cash drag. The stock has shown positive momentum recently.	0.5499999999999998	0.2	1003.65	{"confidence": 0.75, "win_probability": 0.7, "expected_gain_pct": 12.0, "expected_loss_pct": -6.0}	f
35	244b94fa-0b93-45a3-accd-58bd8c4ca77c	2026-05-14 14:02:50.595098+00	BUR	BUY	15	MARKET	FILLED	4.7293	0.70944	68	BUR has performed well (+1.35%) and operates in the litigation finance space, which benefits from market volatility and uncertainty. Adding to this position diversifies the portfolio and addresses the cash drag.	0.5599999999999999	0.2	1003.65	{"confidence": 0.75, "win_probability": 0.7, "expected_gain_pct": 15.0, "expected_loss_pct": -7.0}	f
36	913e8059-92bc-4321-99a5-ef76552075bf	2026-05-14 14:03:27.176054+00	COGT	BUY	5	MARKET	FILLED	34.96	1.000015	72	COGT has strong clinical oncology pipeline with Bezuclastinib for Systemic Mastocytosis & GIST, with >$3B peak sales estimated. It's a potential M&A target and has been consistently recommended by Yellowbrick. This deployment addresses the cash drag and diversifies the portfolio.	0.55	0.2	1003.28	{"confidence": 0.75, "win_probability": 0.7, "expected_gain_pct": 30.0, "expected_loss_pct": -15.0}	f
37	64624662-f2b7-469f-8a6d-be809d9e75c0	2026-05-15 14:02:12.431432+00	BUR	SELL	10	MARKET	FILLED	4.695	0.472447	78	Trimming BUR to reduce concentration risk from 19.9% to ~15% of portfolio. BUR has shown earnings volatility (Q4 2025 $37.5M loss vs Q2 2025 $88.3M profit) and is approaching our 20% position limit. This is risk management, not thesis invalidation.	-174.35	0	1004.23	{"confidence": 0.7, "win_probability": 0.65, "expected_gain_pct": 0.01, "expected_loss_pct": -5.0}	f
38	d77f9b9a-7406-481c-94aa-5176e547e2be	2026-05-15 14:02:22.474358+00	OBE	BUY	6	MARKET	FILLED	13.31	0.798618	82	OBE is the most shorted oil producer (34.1% short interest) with GME-like short squeeze potential if Hormuz tensions escalate. Trading at $13.095 with strong oil leverage thesis intact. Hormuz closure continues with 100M barrels lost weekly per Aramco warning. This represents the highest asymmetric opportunity in the energy sector.	0.65625	0.2	1005.58	{"confidence": 0.8, "win_probability": 0.75, "expected_gain_pct": 40.0, "expected_loss_pct": -15.0}	f
39	8f7d5db8-febf-47e4-ba37-59fabb25cd00	2026-05-18 14:02:26.43536+00	COGT	SELL	5	MARKET	FILLED	32.44	1.004332	88	COGT has no revenue and continues to burn cash ($97M loss in Q1 2026). The thesis of clinical oncology pipeline value has not materialized, and the position has underperformed by -7.7%. With no near-term catalysts and 78 days until next earnings, there's no reason to hold this pure burn play. The position violates our principle of not holding companies without revenue.	-99.0500000000001	0	990.4	{"confidence": 0.95, "win_probability": 0.95, "expected_gain_pct": 0.01, "expected_loss_pct": -20.0}	f
40	267082d7-c06c-4caa-afe3-3414553592a1	2026-05-18 14:02:35.514117+00	PEW	BUY	67	MARKET	FAILED	\N	\N	92	PEW trades at a 20% discount to cash ($2.905 vs $3.51 cash/share). With $106M cash vs $85M market cap, this represents a classic net-net value opportunity with strong downside protection. The business is growing 15% vs industry -10.6% decline, and $20M buyback is half executed. This is a high-conviction value play with asymmetric upside.	0.88	0.2	989.16	{"confidence": 0.95, "win_probability": 0.9, "expected_gain_pct": 25.0, "expected_loss_pct": -5.0}	f
41	db3b6217-fc20-45f7-9284-ed71891ca562	2026-05-18 14:02:44.795995+00	DMLP	SELL	7	MARKET	FILLED	27.5	1.005352	96	DMLP represents 19.1% of portfolio, approaching our 20% maximum position size. Given the binary outcome risk from UK military mission to stabilize Hormuz shipping (which could reduce oil premium), trimming this position reduces concentration risk while maintaining oil leverage exposure. The thesis remains valid but the position size is excessive.	-449.3000000000001	0	989.16	{"confidence": 0.8, "win_probability": 0.7, "expected_gain_pct": 0.01, "expected_loss_pct": -15.0}	f
42	ad7c20ac-8a53-43d9-9913-033080802f55	2026-05-18 14:03:10.421676+00	PEW	BUY	66	MARKET	FAILED	\N	\N	100	PEW trades at a 20% discount to cash ($2.905 vs $3.51 cash/share). With $106M cash vs $85M market cap, this represents a classic net-net value opportunity with strong downside protection. The business is growing 15% vs industry -10.6% decline, and $20M buyback is half executed. This is a high-conviction value play with asymmetric upside.	0.9416666666666667	0.2	985.06	{"confidence": 0.97, "win_probability": 0.95, "expected_gain_pct": 30.0, "expected_loss_pct": -5.0}	f
43	e7b743ab-f119-46d5-9bbd-63860976bede	2026-05-18 14:03:26.001635+00	PEW	BUY	66	MARKET	FAILED	\N	\N	104	PEW trades at a 20% discount to cash ($2.905 vs $3.51 cash/share). With $106M cash vs $85M market cap, this represents a classic net-net value opportunity with strong downside protection. The business is growing 15% vs industry -10.6% decline, and $20M buyback is half executed. This is a high-conviction value play with asymmetric upside.	0.9416666666666667	0.2	985.06	{"confidence": 0.97, "win_probability": 0.95, "expected_gain_pct": 30.0, "expected_loss_pct": -5.0}	f
44	f51d60e0-3c36-4542-acec-7d39e7dc2669	2026-05-18 14:03:38.933918+00	POOL	BUY	1	MARKET	FILLED	175.98	1.000003	108	POOL is a resilient consumer discretionary company in the pool products sector. Q1 2026 revenue $1.14B, net income $53.2M (EPS $1.46). The company has strong insider support with $7.67M in insider buying, indicating management confidence in the business. Trading at a reasonable valuation, this represents a quality value opportunity.	0.77	0.2	985.06	{"confidence": 0.9, "win_probability": 0.85, "expected_gain_pct": 15.0, "expected_loss_pct": -8.0}	f
45	2fdb4140-c3c0-464e-9092-f609d4b74e6d	2026-05-18 14:03:58.424874+00	RILY	BUY	5	MARKET	FAILED	\N	\N	112	RILY is our top-performing position (+15% alpha) with strong fundamentals. Q1 2026 revenue $450.6M, net income $213.3M (EPS $6.98). This represents a quality business at a cheap valuation (P/E ~1.3x). Adding to our winner makes sense given its strong performance and fundamentals.	0.75	0.2	984.54	{"confidence": 0.9, "win_probability": 0.85, "expected_gain_pct": 15.0, "expected_loss_pct": -10.0}	f
46	45e24476-e3d5-4cac-b84d-9dbb0c0cf1d4	2026-05-18 14:04:11.348051+00	RILY	BUY	5	MARKET	FAILED	\N	\N	116	RILY is our top-performing position (+15% alpha) with strong fundamentals. Q1 2026 revenue $450.6M, net income $213.3M (EPS $6.98). This represents a quality business at a cheap valuation (P/E ~1.3x). Adding to our winner makes sense given its strong performance and fundamentals.	0.75	0.2	984.54	{"confidence": 0.9, "win_probability": 0.85, "expected_gain_pct": 15.0, "expected_loss_pct": -10.0}	f
47	adba1cb9-d86a-4a3e-9589-6a9ea83cd2aa	2026-05-19 14:03:05.069337+00	AENT	SELL	9	MARKET	FILLED	6.4	0.578968	122	AENT is the worst performer in the portfolio at -6.2% and represents 12.2% of portfolio value. Trimming this position reduces exposure to underperforming assets and frees capital for higher-conviction opportunities. The company's fundamentals show declining revenue and margins, justifying reduction.	-749.3000000000001	0	969.3	{"confidence": 0.8, "win_probability": 0.7, "expected_gain_pct": 0.01, "expected_loss_pct": -25.0}	f
48	872ef257-5f8f-44a4-8652-216a2c11ede1	2026-05-19 14:03:23.012403+00	PEW	BUY	48	MARKET	FAILED	\N	\N	126	PEW trades at a 20% discount to cash ($2.89 vs $3.51 cash/share) with strong growth potential. The company is transitioning from losses to profitability, with revenue growing from $22.3M to $25.9M sequentially. Management is executing on growth initiatives including PEW Logistics for D2C fulfillment and targeting 3-4% market penetration of the $9B US firearms market.	0.58	0.2	969.3	{"confidence": 0.85, "win_probability": 0.7, "expected_gain_pct": 50.0, "expected_loss_pct": -20.0}	f
49	c174bd5e-85ec-4de5-864b-b44ffb5ca91d	2026-05-19 14:03:30.591782+00	OBE	BUY	7	MARKET	FILLED	13.045	0.913171	130	OBE is a Canadian oil producer benefiting from Substack's bullish summer travel demand thesis and current geopolitical energy supply disruption. With oil at $110/barrel and Hormuz closure, OBE has strong EBITDA ($55.8M in Q1 2026) and is positioned to benefit from summer travel-related demand.	0.35833333333333334	0.17916666666666667	969.3	{"confidence": 0.8, "win_probability": 0.65, "expected_gain_pct": 30.0, "expected_loss_pct": -25.0}	f
50	fd1e6ae4-0385-4114-a9bd-cd4d659640ef	2026-05-19 14:03:55.002118+00	GPN	SELL	1	MARKET	FILLED	69.3	0.694626	134	GPN is currently at 14.0% of portfolio weight, approaching the maximum position size limit of 20%. Trimming this position reduces concentration risk and frees capital for higher-conviction opportunities like PEW, while maintaining some exposure to the value opportunity.	-599.4	0	968.56	{"confidence": 0.7, "win_probability": 0.6, "expected_gain_pct": 0.01, "expected_loss_pct": -15.0}	f
51	3d5e5c59-4bbe-4b15-b697-9ef57beba12d	2026-05-19 14:04:10.123803+00	PEW	BUY	67	MARKET	FAILED	\N	\N	138	PEW trades at a 20% discount to cash ($2.89 vs $3.51 cash/share) with strong growth potential. The company is transitioning from losses to profitability, with revenue growing from $22.3M to $25.9M sequentially. Management is executing on growth initiatives including PEW Logistics for D2C fulfillment and targeting 3-4% market penetration of the $9B US firearms market.	0.58	0.2	968.21	{"confidence": 0.85, "win_probability": 0.7, "expected_gain_pct": 50.0, "expected_loss_pct": -20.0}	f
52	246f9a17-8ff2-4111-a060-05c1811e6b10	2026-05-19 14:04:24.081506+00	PEW	BUY	67	MARKET	FAILED	\N	\N	142	PEW trades at a 20% discount to cash ($2.89 vs $3.51 cash/share) with strong growth potential. The company is transitioning from losses to profitability, with revenue growing from $22.3M to $25.9M sequentially. Management is executing on growth initiatives including PEW Logistics for D2C fulfillment and targeting 3-4% market penetration of the $9B US firearms market.	0.58	0.2	968.21	{"confidence": 0.85, "win_probability": 0.7, "expected_gain_pct": 50.0, "expected_loss_pct": -20.0}	f
53	ce9a0ee0-8c36-4d28-a453-93a447f46261	2026-05-20 14:01:16.971415+00	PEW	BUY	70	MARKET	FAILED	\N	\N	148	PEW trades at $2.73/share with $3.51 cash per share (20% discount to cash), $106.4M cash, $29.7M debt, and solid growth (25.9M revenue in Q1 2026). This represents an exceptional net-net value opportunity with built-in downside protection. The company is well-positioned in the firearms retail sector with growing revenue and strong cash flow.	0.7857142857142857	0.2	969.43	{"confidence": 0.95, "win_probability": 0.85, "expected_gain_pct": 35.0, "expected_loss_pct": -15.0}	f
54	ffb2320a-8b87-4836-ad5c-1347e69245cc	2026-05-20 14:01:31.196773+00	OBE	BUY	2	MARKET	FILLED	12.88	0.257606	152	OBE is a Canadian oil producer trading at $12.85 with strong Q1 2026 fundamentals: $151.4M revenue, $29.6M operating income, $263.6M cash. Substack consistently recommends holding OBE as 'the most shorted oil producer' with GME-like short squeeze potential. The company benefits from oil prices at $110/barrel and upcoming summer travel demand, which should boost demand for oil and gas.	0.63	0.2	969.43	{"confidence": 0.9, "win_probability": 0.75, "expected_gain_pct": 25.0, "expected_loss_pct": -12.0}	f
55	425afda4-8d27-42c5-8300-0a152d24baf1	2026-05-20 14:01:53.506604+00	RILY	BUY	10	MARKET	FAILED	\N	\N	156	RILY is our strongest performer (+21.9% vs portfolio) with exceptional Q1 2026 results: $450.6M revenue, $253.6M operating income, and $213.3M net income. The company is executing exceptionally well on its business model and represents a high-quality growth opportunity. Adding to this position increases our exposure to a proven winner while deploying cash to address the portfolio's -10.31% alpha underperformance.	0.7	0.2	969.19	{"confidence": 0.95, "win_probability": 0.8, "expected_gain_pct": 20.0, "expected_loss_pct": -10.0}	f
56	a8fa4a89-d881-4fae-a218-9fd1929ce074	2026-05-20 14:02:09.180702+00	GPN	BUY	1	MARKET	FILLED	68.67	0.686703	160	GPN is a high-quality value stock trading at 5x P/E with $2.97B Q1 revenue and $6.5B buyback program. The company has strong fundamentals and represents a compelling deep value opportunity. Adding to this position aligns with our value investing thesis and deploys cash to address the portfolio's -10.31% alpha underperformance.	0.55	0.2	969.19	{"confidence": 0.85, "win_probability": 0.7, "expected_gain_pct": 30.0, "expected_loss_pct": -15.0}	f
57	e47ab52f-268b-42db-9d42-31a6638b657c	2026-05-20 14:03:10.124973+00	DMLP	BUY	5	MARKET	FILLED	28.715	1.000015	166	DMLP is a zero-capex oil/gas royalty LP with $129.7M TTM FCF, net cash position, and direct upside leverage to oil prices. The Hormuz closure from the Iran war is a structural supply disruption that elevates WTI well above the $55 falsification floor. Every $10/bbl oil increase adds ~$13M annual FCF. With oil at $110/barrel and ongoing geopolitical tensions, this represents a high-conviction oil leverage opportunity.	0.65	0.2	968.26	{"confidence": 0.9, "win_probability": 0.75, "expected_gain_pct": 30.0, "expected_loss_pct": -12.0}	f
\.


--
-- Data for Name: _hyper_2_13_chunk; Type: TABLE DATA; Schema: _timescaledb_internal; Owner: -
--

COPY _timescaledb_internal._hyper_2_13_chunk (id, request_id, "timestamp", ticker, action, quantity, order_type, status, filled_price, commission, order_id, reason, kelly_fraction, half_kelly_fraction, portfolio_value_at_trade, analysis_data, dry_run) FROM stdin;
58	3ba691f1-4ba1-46a3-9f83-930eda40e14b	2026-05-21 16:04:37.903019+00	AENT	SELL	6	MARKET	FILLED	5.715	0.344794	172	Trimming 6 shares of AENT (67% of position) to raise meaningful cash for portfolio optimization. Portfolio in crisis with -11.26% alpha underperformance, minimal cash (2.3%) limiting deployment. Need sufficient cash to deploy to higher-conviction opportunities.	-1.1102230246251565e-16	0	970.71	{"confidence": 0.7, "win_probability": 0.6, "expected_gain_pct": 2.0, "expected_loss_pct": -3.0}	f
59	e964dd4f-37eb-4f7d-b199-b6cfb7c00893	2026-05-21 16:05:14.803616+00	OBE	SELL	4	MARKET	FILLED	12.66	0.508235	176	Trimming 4 shares of OBE to reduce portfolio concentration from 19.7% toward target ~12.5%. Portfolio in crisis with -11.26% alpha underperformance requires rebalancing. Geopolitical de-escalation (Iran strike called off) may pressure oil premium. Cash raised can be deployed to other opportunities.	-1.1102230246251565e-16	0	967.26	{"confidence": 0.7, "win_probability": 0.6, "expected_gain_pct": 2.0, "expected_loss_pct": -3.0}	f
60	353f9af7-0fed-4555-a6ec-249c1cc8b836	2026-05-25 14:01:22.784921+00	AENT	SELL	3	MARKET	PENDING	\N	\N	182	AENT position has breached its $5.95 stop-loss ($6.16 current price), triggering CODE RED protocol. The position is also a stub at only 1.9% of portfolio, below the 5% minimum meaningful size. No earnings date has been confirmed despite multiple checks, creating uncertainty for position management. With the portfolio in crisis (-12.53% alpha underperformance vs SPY), capital should be redeployed to higher-conviction opportunities. Selling AENT frees up $18.48 for redeployment to addresses the portfolio crisis.	-201.65	0	981.51	{"confidence": 0.85, "win_probability": 0.85, "expected_gain_pct": 0.01, "expected_loss_pct": -13.5}	f
61	60222a57-a6c4-4f28-a486-684225b03e78	2026-05-25 14:01:49.67419+00	AENT	SELL	3	MARKET	FAILED	\N	\N	186	AENT position has breached its $5.95 stop-loss ($6.16 current price), triggering CODE RED protocol. The position is also a stub at only 1.9% of portfolio, below the 5% minimum meaningful size. No earnings date has been confirmed despite multiple checks, creating uncertainty for position management. With the portfolio in crisis (-12.53% alpha underperformance vs SPY), capital should be redeployed to higher-conviction opportunities. Selling AENT frees up $18.48 for redeployment to addresses the portfolio crisis.	-201.65	0	981.51	{"confidence": 0.85, "win_probability": 0.85, "expected_gain_pct": 0.01, "expected_loss_pct": -13.5}	f
62	daa16030-0fdf-4de6-88a3-1bdd26a31a78	2026-05-25 14:02:12.770181+00	AENT	SELL	3	MARKET	FAILED	\N	\N	190	AENT is a stub position at only 1.9% of portfolio value, below the 5% minimum meaningful size requirement. Stub positions do not justify monitoring cost and waste attention that should be focused on higher-conviction opportunities. With the portfolio in crisis (-12.53% alpha underperformance vs SPY), capital should be redeployed to higher-conviction opportunities. Selling AENT frees up $18.48 for redeployment to address the portfolio crisis.	-336.75	0	981.51	{"confidence": 0.75, "win_probability": 0.75, "expected_gain_pct": 0.01, "expected_loss_pct": -13.5}	f
63	1862d262-3abc-4851-9556-d33fb2b0fd89	2026-05-26 14:01:51.696869+00	AENT	SELL	3	MARKET	FAILED	\N	\N	196	AENT is a stub position at 1.9% (below 5% minimum threshold) and is approaching its stop-loss of $5.95 ($6.485 current price is only $0.535 above stop). The position is too small to justify monitoring cost while approaching a critical threshold. With no earnings date found in system and the portfolio crisis requiring urgent optimization, selling this stub position frees up capital for higher-conviction opportunities and eliminates a monitoring burden.	0.625	0.2	986.16	{"confidence": 0.9, "win_probability": 0.85, "expected_gain_pct": 10.0, "expected_loss_pct": -15.0}	f
64	20889e5d-9ee5-4543-b182-2bffe51da133	2026-05-26 14:02:00.632276+00	DMLP	SELL	5	MARKET	FILLED	27.62	1.003835	200	DMLP's oil leverage thesis is being materially undermined by Trump's announcement that the Strait of Hormuz deal is 'largely negotiated.' This represents a fundamental shift in the investment thesis, not just price movement. The core catalyst for DMLP's valuation premium (oil conflict risk) is being removed. Market implications: Oil premium compression likely, pressure on energy stocks with conflict premium exposure. With the portfolio overweight in energy (27.6% combined OBE+DMLP), reducing this position addresses sector concentration risk.	-3	0	986.16	{"confidence": 0.85, "win_probability": 0.2, "expected_gain_pct": 5.0, "expected_loss_pct": -20.0}	f
65	d8be5d5e-f6c5-4dcb-9a81-6c77c0be0eb8	2026-05-26 14:02:08.107622+00	OBE	SELL	11	MARKET	FILLED	11.82	1.004856	204	OBE's summer travel thesis remains but faces significant headwind from the Strait of Hormuz reopening, which would pressure oil premium and create a lower oil price environment. The portfolio is overweight energy (27.6% combined OBE+DMLP) and faces geopolitical uncertainty. With RILY as the sole strong performer, reducing energy concentration improves portfolio diversification and risk management.	-1.8875	0	987.25	{"confidence": 0.8, "win_probability": 0.3, "expected_gain_pct": 8.0, "expected_loss_pct": -25.0}	f
66	93cece78-faa5-407d-85ce-282a482efbd7	2026-05-26 14:02:15.71103+00	SBLK	BUY	7	MARKET	FILLED	27.1485	1.000021	208	SBLK is the top watchlist candidate from Yellowbrick - Star Bulk Carriers with 145-vessel dry bulk fleet, scrap value $975M > gross debt $951M, high operating leverage. This provides perfect portfolio diversification away from energy exposure and geopolitical risk. With the Strait of Hormuz reopening, shipping sector could benefit from increased trade flows. Current portfolio needs sector diversification away from oil exposure.	0.65	0.2	986.77	{"confidence": 0.85, "win_probability": 0.75, "expected_gain_pct": 30.0, "expected_loss_pct": -12.0}	f
67	2d4c0f4b-3f20-4aa7-bb2e-60486d3f026f	2026-05-26 14:02:40.27167+00	BRCB	BUY	25	MARKET	FAILED	\N	\N	212	BRCB shows strong fundamentals with $55.5M Q1 2026 revenue and improving profitability. The massive insider buying ($73.3M by 3 insiders) indicates exceptional institutional conviction. This provides diversification away from energy exposure and represents a high-conviction opportunity that fits within available capital constraints.	0.72	0.2	986.14	{"confidence": 0.85, "win_probability": 0.8, "expected_gain_pct": 25.0, "expected_loss_pct": -10.0}	f
68	308b94db-e9fc-4ebd-b493-4756bb1e3cb4	2026-05-27 14:02:12.826473+00	ESTA	BUY	2	MARKET	FILLED	73.87	1.000006	218	ESTA represents healthcare diversification with strong Ozempic tailwind catalyst and FDA approval catalyst. Current valuation discount provides attractive risk/reward. Portfolio needs sector diversification beyond energy exposure.	0.5227272727272727	0.2	986.14	{"confidence": 0.7, "win_probability": 0.65, "expected_gain_pct": 55.0, "expected_loss_pct": -20.0}	f
69	40cb01ed-dc9c-4b24-834b-02b9670fb68e	2026-05-27 14:03:33.49596+00	DNA	BUY	5	MARKET	FILLED	8.915	0.445765	226	DNA represents healthcare/biotech exposure with potential upside from synthetic biology platform. Current valuation appears reasonable given growth potential and market divergence creates opportunity.	0.35	0.175	983.93	{"confidence": 0.65, "win_probability": 0.6, "expected_gain_pct": 40.0, "expected_loss_pct": -25.0}	f
\.


--
-- Data for Name: _hyper_2_14_chunk; Type: TABLE DATA; Schema: _timescaledb_internal; Owner: -
--

COPY _timescaledb_internal._hyper_2_14_chunk (id, request_id, "timestamp", ticker, action, quantity, order_type, status, filled_price, commission, order_id, reason, kelly_fraction, half_kelly_fraction, portfolio_value_at_trade, analysis_data, dry_run) FROM stdin;
70	c6deae03-ea36-4842-9b2e-5fad80e1a226	2026-05-28 14:02:50.064635+00	ESTA	SELL	2	MARKET	FILLED	71.93	1.00336	232	ESTA has breached its stop-loss of $180.00, with current price at $71.995. The stop-loss breach triggers the default action to sell unless overwhelming new fundamental evidence is found. No such evidence has been identified in current analysis. The updated thesis indicates the FDA approval catalyst has not materialized as expected, invalidating the original investment premise.	-74.15000000000002	0	970.26	{"confidence": 0.95, "win_probability": 0.85, "expected_gain_pct": 0.01, "expected_loss_pct": -5.0}	f
71	9bdd2480-70a4-43d0-af92-55a530e98e93	2026-05-28 14:03:03.495587+00	DNA	SELL	5	MARKET	FILLED	9.07	0.455424	236	DNA is a stub position at 4.5% of the portfolio, below the 5% minimum threshold. Stub positions below 5% do not justify monitoring cost and should be exited to free up capital for more promising opportunities. The portfolio needs optimization to address the -11.0% underperformance crisis.	-59.300000000000004	0	968.44	{"confidence": 0.85, "win_probability": 0.7, "expected_gain_pct": 0.01, "expected_loss_pct": -2.0}	f
72	d67cbb46-e6e9-472f-9761-6dba04027731	2026-05-28 14:03:29.535473+00	RILY	SELL	3	MARKET	FILLED	10.64	0.320452	240	RILY has performed exceptionally well (+37.7%), representing 11.0% of the portfolio. To address the portfolio's -11.0% underperformance crisis, we need to deploy capital into new opportunities like VISN and OSB. Trimming 3 shares of RILY will free up approximately $32 to fund these new positions while maintaining a meaningful RILY position.	-119.40000000000002	0	967.59	{"confidence": 0.8, "win_probability": 0.6, "expected_gain_pct": 0.01, "expected_loss_pct": -3.0}	f
73	d1be0042-a3b7-4202-8dd9-700830c5319e	2026-05-28 14:03:43.594681+00	VISN	BUY	14	MARKET	FILLED	12.338	1.000042	244	VISN is trading at $12.32, well below its $14 target price from Substack. The company is a communications infrastructure provider with strong fundamentals ($471.8M revenue in Q1 2026) and benefits from the DOCSIS 4.0 upgrade tailwind. This represents an attractive entry point with asymmetric risk/reward.	0.6594202898550725	0.2	967.46	{"confidence": 0.85, "win_probability": 0.75, "expected_gain_pct": 13.8, "expected_loss_pct": -5.0}	f
74	29a6811a-76d2-4ab5-9ea0-cc5e73a72510	2026-05-29 14:02:38.023857+00	VISN	SELL	3	MARKET	FILLED	12.4407	0.374584	250	VISN is our second largest position at 18.0% of portfolio and has concerning financials with negative $1.5B net income in Q1 2026. We need to reduce concentration and address the fundamental weakness while raising cash for better opportunities.	0.20000000000000018	0.10000000000000009	966.31	{"confidence": 0.8, "win_probability": 0.8, "expected_gain_pct": 2.0, "expected_loss_pct": -6.0}	f
75	7912994f-9e69-42d3-9b26-55ed34300fec	2026-05-29 14:03:09.648556+00	SBLK	SELL	1	MARKET	FILLED	26.9412	0.270165	254	SBLK is our largest position at 19.6% of portfolio, exceeding our 20% maximum but violating our target of ~12.5%. We need to reduce concentration for risk management while maintaining our thesis that SBLK benefits from global trade normalization and shipping demand.	0.55	0.2	962.52	{"confidence": 0.85, "win_probability": 0.85, "expected_gain_pct": 2.5, "expected_loss_pct": -5.0}	f
76	796ecbee-b9ca-49ca-be5c-bb89c569b9de	2026-05-29 14:03:45.559849+00	ROCK	BUY	2	MARKET	FILLED	39.42	0.788406	258	ROCK has strong fundamentals with 12% revenue growth, margin expansion, and raised guidance. The substack $100 target represents 2.5x upside and is confirmed by the research showing sustained demand in solar and construction end-markets. We're buying 2 shares to establish a meaningful position while maintaining risk management discipline.	0.65	0.2	962.65	{"confidence": 0.85, "win_probability": 0.75, "expected_gain_pct": 25.0, "expected_loss_pct": -10.0}	f
77	409f5a76-39a9-48f3-80ee-363b96bfd234	2026-06-02 14:02:52.251514+00	RILY	SELL	3	MARKET	FILLED	9.745	0.293546	264	RILY has performed exceptionally well (+26.0% unrealized PnL) and represents the largest source of portfolio alpha. Selling 3 shares (42.9% of position) will generate approximately $29.31 in cash, increasing portfolio cash from 3.8% to ~7.0% and reducing concentration risk while maintaining exposure to this strong performer. This aligns with the portfolio rebalancing imperative and meets the minimum trade size requirement.	0.52	0.2	961.91	{"confidence": 0.8, "win_probability": 0.7, "expected_gain_pct": 25.0, "expected_loss_pct": -15.0}	f
78	5cb43963-fe22-4882-b18f-d5b1d2897310	2026-06-02 14:03:00.620884+00	ROCK	SELL	1	MARKET	FILLED	38.13	0.382283	268	ROCK has declined -4.1% from entry price ($39.81 to $38.16) and the Substack $100 target remains valid but distant. With 6 positions lacking formal theses and critical cash constraints, selling 1 share (50% of position) will generate $38.16 in cash, increasing portfolio cash to ~11.0% and addressing the discipline violation. This is a tactical cash generation move, not thesis invalidation, as the $100 target remains intact.	-1	0	956.16	{"confidence": 0.7, "win_probability": 0.6, "expected_gain_pct": 5.0, "expected_loss_pct": -20.0}	f
79	4992a8cf-965c-4833-9680-387877016578	2026-06-02 14:03:08.551738+00	SBLK	SELL	1	MARKET	FILLED	27.6315	0.277082	272	SBLK has performed moderately well (+1.6% unrealized PnL) and is our second largest position at 17.5% of portfolio. Selling 1 share (16.7% of position) will generate approximately $27.73 in cash, increasing portfolio cash to ~13.5% and reducing concentration risk. This addresses the portfolio rebalancing imperative while maintaining exposure to this core holding.	0.125	0.0625	955.79	{"confidence": 0.75, "win_probability": 0.65, "expected_gain_pct": 10.0, "expected_loss_pct": -15.0}	f
80	d06b8b54-3a7b-4f42-a2ca-ed2836a5c980	2026-06-03 14:01:50.045559+00	RLI	BUY	2	MARKET	FILLED	51	1.000006	278	RLI represents a high-conviction insurance sector rotation opportunity with strong fundamentals. Trading at $51.005 with Q1 2026 net income of $54.89M and $0.60 EPS, RLI shows consistent profitability in the property & casualty insurance space. With a low beta (0.383) and $4.66 dividend, it provides defensive characteristics while benefiting from sector rotation signals. The recent $859K insider buying cluster confirms management's confidence in the company's prospects.	0.5399999999999999	0.2	934.82	{"confidence": 0.75, "win_probability": 0.7, "expected_gain_pct": 15.0, "expected_loss_pct": -8.0}	f
81	9d6f46a5-da46-45e6-bc23-90e3434b1e04	2026-06-03 14:02:17.989997+00	ROCK	SELL	1	MARKET	FILLED	37.68	0.377774	282	ROCK requires thesis review and position size adjustment. Currently at 3.9% of portfolio (below 5% minimum), it's a stub position that doesn't justify monitoring cost. The $39.81 entry price is above current $37.98 price (-4.7% decline), but with strong insider buying ($1.56M by 4 insiders) and Substack $100 target (2.5x upside), the thesis remains intact. Selling 1 share reduces the position to 2 shares while maintaining exposure to the solar construction thesis.	0.28	0.14	933.27	{"confidence": 0.6, "win_probability": 0.55, "expected_gain_pct": 20.0, "expected_loss_pct": -12.0}	f
82	fe4f677f-a7d4-47e2-83ec-8d524a0daa76	2026-06-03 14:02:26.672971+00	POOL	SELL	1	MARKET	FILLED	179.109	1.003888	286	POOL is the largest portfolio position at 18.8% and requires risk management. With +1.4% performance and unknown earnings date, selling 1 share reduces concentration while generating cash. The cash will be redeployed to higher-conviction opportunities aligned with current geopolitical risks (energy) and sector rotation (insurance). This addresses both cash constraint and position sizing discipline.	0.2649999999999999	0.13249999999999995	932.91	{"confidence": 0.62, "win_probability": 0.58, "expected_gain_pct": 8.0, "expected_loss_pct": -6.0}	f
83	ab7253ef-7bb3-46d7-8c50-a18a83ec84a6	2026-06-03 14:02:43.696662+00	RILY	SELL	4	MARKET	FILLED	9.905	0.397808	290	RILY is currently a stub position at 4.1% of portfolio (below 5% minimum), requiring exit to eliminate monitoring cost. With +27.0% performance, exiting the full position locks in gains and generates cash for higher-conviction opportunities. The position has unknown earnings risk, making full exit the appropriate risk management action.	0.33333333333333326	0.16666666666666663	931.31	{"confidence": 0.65, "win_probability": 0.6, "expected_gain_pct": 12.0, "expected_loss_pct": -8.0}	f
84	c5e7629d-34f7-4e69-b437-969b5bf80ef0	2026-06-03 14:02:51.291723+00	GRNT	BUY	37	MARKET	FILLED	5.005	1.000111	294	GRNT presents a high-conviction energy opportunity aligned with current US-Iran geopolitical tensions. With $919K insider buying by 6 insiders at $5.36, the stock is currently trading at $4.995 (6.8% below insider purchase price), creating an attractive entry point. The company operates in oil & gas exploration with exposure to potential oil price premiums from Middle East tensions. GRNT has a low beta (0.228) and strong insider conviction, making it a defensive energy play with asymmetric upside.	0.51	0.2	931.46	{"confidence": 0.7, "win_probability": 0.65, "expected_gain_pct": 25.0, "expected_loss_pct": -10.0}	f
\.


--
-- Data for Name: _hyper_2_15_chunk; Type: TABLE DATA; Schema: _timescaledb_internal; Owner: -
--

COPY _timescaledb_internal._hyper_2_15_chunk (id, request_id, "timestamp", ticker, action, quantity, order_type, status, filled_price, commission, order_id, reason, kelly_fraction, half_kelly_fraction, portfolio_value_at_trade, analysis_data, dry_run) FROM stdin;
85	2fb7fde0-8021-45f1-a8f7-57c9d15a18db	2026-06-08 14:02:59.532147+00	GRNT	SELL	37	MARKET	FILLED	4.925	1.01108	300	GRNT faces substantial doubt about its ability to continue as a going concern with high debt maturity risk in 2027 and recent auditor change. In the current extreme geopolitical environment with Strait of Hormuz blockade likely to cause oil price volatility and credit market stress, GRNT's high leverage makes it extremely vulnerable. The stock is trading at $4.92, down 2.2% from our cost basis, and the going-concern warning represents an existential risk that violates our risk management principles.	-174.05000000000015	0	930.54	{"confidence": 0.9, "win_probability": 0.95, "expected_gain_pct": 0.01, "expected_loss_pct": -35.0}	f
86	f58a5e62-0dff-46a4-badb-152964808e7a	2026-06-08 14:03:13.213417+00	SBLK	SELL	5	MARKET	FILLED	26.73	1.003743	304	SBLK faces existential risk from the Strait of Hormuz blockade threat. With Iran threatening to completely block this critical oil chokepoint and US-Iran military escalation continuing, shipping routes are at extreme risk. News reports confirm shipping traffic has dropped to 36 ships/week from 130/day pre-war. SBLK's business model depends on global trade routes, and a complete Hormuz blockade would severely impact its operations. The stock is down 2.2% to $26.69 and the geopolitical risk has moved from potential to highly probable.	-249.0500000000002	0	921.96	{"confidence": 0.92, "win_probability": 0.95, "expected_gain_pct": 0.01, "expected_loss_pct": -50.0}	f
87	f984ea84-e288-43cf-860b-7473e936c399	2026-06-09 14:02:29.728241+00	SU	BUY	1	MARKET	FILLED	61.84	0.618403	310	SU is Canada's largest integrated energy company with direct exposure to oil price increases. With US-Iran conflict escalating at the Strait of Hormuz (20% of global oil supply), oil prices are likely to spike. SU has strong fundamentals: $15.4B Q1 revenue, $2.9B operating income, $2.1B net income, and $4.76B EBITDA. Trading at ~4.8x revenue is reasonable for integrated energy. This positions the portfolio for geopolitical tailwinds while maintaining quality.	0.5714285714285714	0.2	920.88	{"confidence": 0.75, "win_probability": 0.7, "expected_gain_pct": 35.0, "expected_loss_pct": -15.0}	f
88	9b53db9b-e33e-4687-a4e1-ec19a097340a	2026-06-10 14:02:54.415439+00	OBE	BUY	8	MARKET	FILLED	11.058	0.884664	316	OBE is a pure-play Canadian oil producer with strong fundamentals and direct exposure to oil price movements. With Iran-Israel missile exchanges escalating and Strait of Hormuz risk elevated, oil prices have significant upside potential. OBE's current price of $11.07 offers compelling entry point relative to $14.00 target price (26.5% upside) with $9.00 stop loss (18.7% downside). This provides asymmetric risk/reward profile perfectly aligned with our geopolitical energy theme.	0.48830188679245273	0.2	927.52	{"confidence": 0.75, "win_probability": 0.7, "expected_gain_pct": 26.5, "expected_loss_pct": -18.7}	f
\.


--
-- Data for Name: _hyper_2_16_chunk; Type: TABLE DATA; Schema: _timescaledb_internal; Owner: -
--

COPY _timescaledb_internal._hyper_2_16_chunk (id, request_id, "timestamp", ticker, action, quantity, order_type, status, filled_price, commission, order_id, reason, kelly_fraction, half_kelly_fraction, portfolio_value_at_trade, analysis_data, dry_run) FROM stdin;
89	9c3f97cb-ec1c-4bb0-a035-ceadfeca67be	2026-06-11 14:02:03.500403+00	GPN	SELL	2	MARKET	FILLED	62.925	1.002989	322	GPN's Q1 2026 results show catastrophic net income of -$1.8B despite $2.97B revenue, indicating serious accounting or operational issues that invalidate the original thesis. This fundamental deterioration makes the position unacceptable to hold, failing the 'would I buy today' test at current price ($62.65).	-599.3000000000001	0	914	{"confidence": 0.8, "win_probability": 0.7, "expected_gain_pct": 0.01, "expected_loss_pct": -20.0}	f
90	d07f5395-bbec-45d3-a885-c9e06972d2df	2026-06-11 14:02:12.754107+00	VISN	SELL	5	MARKET	FILLED	12.215	0.612998	326	VISN's Q1 2026 shows -$1.5B net loss despite $471.8M revenue, suggesting accounting issues. Current price ($12.205) is approaching the updated $13.5 target, and with the thesis weakened and financial concerns, trimming 45% of the position is appropriate risk management.	-0.05	0	914.4	{"confidence": 0.75, "win_probability": 0.65, "expected_gain_pct": 5.0, "expected_loss_pct": -10.0}	f
91	bcc9bb23-786e-423d-987b-aa6fe1dff2fd	2026-06-11 14:02:28.813774+00	BUR	SELL	32	MARKET	FILLED	4.222	1.009119	330	BUR's financials show consistent deterioration with negative operating income (-$53.7M) and net losses in recent quarters. Q4 2025 results show -$53.7M operating income and -$37.5M net income, indicating fundamental issues beyond market sentiment. The original thesis about strong risk-adjusted returns is invalidated by this financial data.	-374.25	0	913.71	{"confidence": 0.85, "win_probability": 0.75, "expected_gain_pct": 0.01, "expected_loss_pct": -15.0}	f
92	6c5e4c0a-67b8-471c-9c69-4fe02bf961ab	2026-06-15 14:01:47.575618+00	SU	SELL	1	MARKET	FILLED	58.65	0.590906	336	Geopolitical thesis weakened by conflicting Iran peace deal signals (Trump claims deal Sunday but CNBC reports deal in question as Israel strikes Lebanon). Updated thesis has decreased conviction and lowered target ($70 from $75). Current price ($58.55) is very close to new stop-loss ($57.5), making position highly vulnerable. With unknown earnings date (violates 7-day rule) and -7.9% unrealized loss, risk/reward is unfavorable. Full exit frees capital for higher-conviction opportunities.	-275.85	0	907.25	{"confidence": 0.75, "win_probability": 0.65, "expected_gain_pct": 0.01, "expected_loss_pct": -7.9}	f
93	40a6cb40-3f29-44db-8174-1355387c8614	2026-06-15 14:02:07.260799+00	OBE	SELL	8	MARKET	FILLED	10.4052	0.835715	340	Geopolitical thesis significantly weakened by conflicting Iran peace deal signals (Trump claims deal Sunday but CNBC reports deal in question as Israel strikes Lebanon). Updated thesis has decreased conviction and lowered target ($13.5 from $15). With unknown earnings date (violates 7-day rule) and -7.1% unrealized loss, risk/reward is unfavorable. Full exit frees capital for higher-conviction opportunities that meet commission requirements.	-212.3	0	906.82	{"confidence": 0.8, "win_probability": 0.7, "expected_gain_pct": 0.01, "expected_loss_pct": -7.1}	f
94	dc90b1c1-d53a-495e-ab8b-8354ada963d5	2026-06-15 14:02:34.359741+00	MOBI	BUY	10	MARKET	FAILED	\N	\N	344	MOBI has massive insider buying ($19.1M by 7 insiders) at $14.99, representing 30% upside from current price of $11.50. This is a strong signal of insider confidence in the company's prospects. As a medical device company, MOBI benefits from the growing healthcare technology sector. A 10-share position ($115) keeps commission drag at 1.74%, well within our 5% threshold.	0.625	0.2	905.96	{"confidence": 0.85, "win_probability": 0.75, "expected_gain_pct": 30.0, "expected_loss_pct": -15.0}	f
95	e4c6c5d9-8b78-4085-b017-1f3515ab51d4	2026-06-15 14:02:52.4135+00	BETR	BUY	5	MARKET	FAILED	\N	\N	348	BETR has massive insider buying ($8.4M by 5 insiders) at $29.46, and is currently trading at $29.89, showing strong insider confidence. The stock is up 12.75% today, indicating positive market sentiment. A 5-share position ($149.45) keeps commission drag at 1.34%, well within our 5% threshold.	0.5559999999999999	0.2	905.96	{"confidence": 0.8, "win_probability": 0.7, "expected_gain_pct": 25.0, "expected_loss_pct": -12.0}	f
96	f986038c-5bc4-486c-b1a4-ae7ebe445de2	2026-06-15 14:03:11.57854+00	SMMT	BUY	10	MARKET	FILLED	14.00964	1.00003	352	SMMT has massive insider buying ($100.7M by 3 insiders) at $13.13, and is currently trading at $14.01, showing strong insider confidence. The stock is up 0.000016% today, suggesting the market hasn't yet priced in this insider confidence. A 10-share position ($140.10) keeps commission drag at 1.43%, well within our 5% threshold.	0.5625	0.2	905.96	{"confidence": 0.9, "win_probability": 0.75, "expected_gain_pct": 20.0, "expected_loss_pct": -15.0}	f
97	a834d138-a6ea-45b8-af0a-21968974bb46	2026-06-16 14:01:53.506233+00	OBE	BUY	3	MARKET	FILLED	10.3	0.309009	358	OBE is a pure-play Canadian oil producer with strong Q1 2026 operating income ($29.6M) despite net losses due to non-operating expenses. With ongoing Iran tensions, US military action against oil tankers, and UK seizure of Russian shadow tanker, oil supply disruptions are real and continuing. OBE's valuation appears attractive relative to peers, and it would provide direct exposure to oil price upside from continued geopolitical risk premium. The current price of $10.27 is below its 52-week high of $14.59, providing a margin of safety.	0.44	0.2	902.58	{"confidence": 0.75, "win_probability": 0.65, "expected_gain_pct": 25.0, "expected_loss_pct": -15.0}	f
\.


--
-- Data for Name: _hyper_2_1_chunk; Type: TABLE DATA; Schema: _timescaledb_internal; Owner: -
--

COPY _timescaledb_internal._hyper_2_1_chunk (id, request_id, "timestamp", ticker, action, quantity, order_type, status, filled_price, commission, order_id, reason, kelly_fraction, half_kelly_fraction, portfolio_value_at_trade, analysis_data, dry_run) FROM stdin;
1	c5194ccd-91ac-4fb1-a53f-d6629e996b03	2026-02-19 18:51:17.047396+00	IPI	BUY	1	MARKET	FAILED	\N	\N	\N	TIER 2 CONVICTION - Fortress balance sheet, Gate City $49 target (+47% upside)	0.24927659574468083	0.12463829787234042	500	{"confidence": 0.58, "win_probability": 0.6, "expected_gain_pct": 47.0, "expected_loss_pct": -20.0}	f
2	8c865771-303d-4a51-8224-9fc8b92c3b9e	2026-02-19 18:51:21.451901+00	FOUR	BUY	1	MARKET	FAILED	\N	\N	\N	HIGHEST CONVICTION - Shift4 Payments at 11x EBITDA vs Toast 24x, Greystone $155 target	0.2835555555555556	0.1417777777777778	500	{"confidence": 0.58, "win_probability": 0.55, "expected_gain_pct": 162.0, "expected_loss_pct": -22.0}	f
3	bf3e416f-8293-4e74-a6d6-35ad3c54cd5d	2026-02-19 19:14:37.237262+00	DMLP	BUY	3.6255	MARKET	CANCELLED	\N	\N	16	DMLP oil royalty LP: Zero capex, $130M TTM FCF, 10.6% yield, net cash $40.8M. Iran crisis direct tailwind on oil prices. 5 insiders bought $1.63M at $22.95 (now +10.9%). 9.5x P/FCF for zero-capex royalty is cheap. Target $30 (conservative retest vs $32.47 52-wk high) = 17.8% upside. Commodity binary risk from Iran resolution. Small starter position given binary event risk around Iran decision (~March 1). FALSIFICATION: WTI below $55, 2+ quarters of declining distributions, overpriced royalty acquisition.	0.37	0.185	499.14	{"confidence": 0.5, "win_probability": 0.58, "expected_gain_pct": 20.0, "expected_loss_pct": -10.0}	f
4	bf3e416f-8293-4e74-a6d6-35ad3c54cd5d	2026-02-19 19:17:32.264112+00	DMLP	BUY	3	MARKET	FILLED	25.49	0.7647	24	DMLP oil royalty LP: Zero capex, $130M TTM FCF, 10.6% yield, net cash $40.8M. Iran crisis direct tailwind on oil prices. 5 insiders bought $1.63M at $22.95 (now +10.9%). 9.5x P/FCF for zero-capex royalty is cheap. Target $30 (conservative retest vs $32.47 52-wk high) = 17.8% upside. Commodity binary risk from Iran resolution. Small starter position given binary event risk around Iran decision (~March 1). FALSIFICATION: WTI below $55, 2+ quarters of declining distributions, overpriced royalty acquisition.	0.37	0.185	499.03	{"confidence": 0.5, "win_probability": 0.58, "expected_gain_pct": 20.0, "expected_loss_pct": -10.0}	f
5	5fd55675-f71d-4794-bcd8-fb26fcd2f2cc	2026-02-20 20:02:54.148526+00	RAL	BUY	2	MARKET	FILLED	43.56	0.8712	30	Ralliant Corp (RAL) is a precision instruments/defense company spun off from Fortive (IPO June 2025). Core thesis: 7.3% FCF yield ($358M TTM / $4.91B mkt cap) on a business with 15.2% YoY revenue growth ($481M→$554M in 4 quarters), net debt declining ($997M→$830M in 3 quarters), and direct defense tailwind. Q4 net loss of -$1.39B was entirely non-cash goodwill impairment; operating income was +$73.9M and FCF was $91.6M. Post-impairment goodwill stands at $1.672B — further impairments possible but unlikely at this level. 6 insiders bought $512K at $40.45 on Feb 10 (confirmed post-lockup discretionary buying); stock now $43.50 = +7.5% already. SCOTUS tariff ruling (today) is mildly positive for RAL's precision component inputs. Iran deal signal softens immediate defense catalyst slightly but RAL's revenue is from long-cycle DoD procurement programs (not Iran-war-dependent). Target: $60 = 13.8x TTM FCF (fair for defense precision instruments growing 15% with improving balance sheet). At $43.50, buying at 12.2x TTM FCF with 7.3% FCF yield. Commission on $50 position: $1 minimum = 2% drag, acceptable. Portfolio sizing: $50 = 10% of $496 portfolio = 1.15 shares. Total deployed after this: $50 RAL + $76 DMLP + $118 FOUR + $99 IPI = $343 = 69% deployed, $153 cash remaining. Within limits.	0.4421052631578948	0.2	496.22	{"confidence": 0.62, "win_probability": 0.6, "expected_gain_pct": 38.0, "expected_loss_pct": -15.0}	f
\.


--
-- Data for Name: _hyper_2_3_chunk; Type: TABLE DATA; Schema: _timescaledb_internal; Owner: -
--

COPY _timescaledb_internal._hyper_2_3_chunk (id, request_id, "timestamp", ticker, action, quantity, order_type, status, filled_price, commission, order_id, reason, kelly_fraction, half_kelly_fraction, portfolio_value_at_trade, analysis_data, dry_run) FROM stdin;
6	53c6b769-db91-4259-9d73-486ded78950b	2026-03-12 17:29:06.038019+00	IPI	SELL	1	MARKET	FILLED	49.1075	0.49127	37	MANDATORY RISK MANAGEMENT TRIM — not a thesis exit. IPI has surged to $49.21 (+46.6% from $33.56 cost), new all-time high $50.31 intraday. At 3 shares x $49.21 = $147.63 / ~$522 portfolio = 28.2% — above the 25% hard cap. Pre-committed trim at $48-49. Thesis intact. After selling 1 share: 2 shares remain for $55 target. Locking +$15.65/share gain on sold share.	0.6500000000000001	0.2	513.55	{"confidence": 0.95, "win_probability": 0.9, "expected_gain_pct": 2.0, "expected_loss_pct": -5.0}	f
7	29b51c83-fd33-40ee-9ba7-27f692b572fb	2026-03-17 14:02:15.237827+00	SKWD	BUY	2	MARKET	FILLED	45.44	0.9088	43	SKWD at $45.51 — HIGH conviction buy. 10.33% TTM operating income yield ($209M/$2.02B mktcap), 7.86% net income yield. Specialty P&C insurer: operating income IS the FCF proxy. Revenue growing 43% YoY. Iran war Day 18 — Ali Larijani killed TODAY = war escalation structurally elevates marine/aviation/war-risk premiums for months. 3 insiders bought $1.42M at $47.00 on Mar 2 (now 3.3% above entry = insiders underwater, strong signal). No meaningful debt. Beta 0.52 defensive. Target $65 = 42.9% upside. Stop at $40 = 11.9% loss. Sizing to 2 shares to stay within 25% position limit ($91 / $506 = 18%).	0.552913752913753	0.2	510.25	{"confidence": 0.68, "win_probability": 0.65, "expected_gain_pct": 42.9, "expected_loss_pct": -11.9}	f
\.


--
-- Data for Name: _hyper_2_4_chunk; Type: TABLE DATA; Schema: _timescaledb_internal; Owner: -
--

COPY _timescaledb_internal._hyper_2_4_chunk (id, request_id, "timestamp", ticker, action, quantity, order_type, status, filled_price, commission, order_id, reason, kelly_fraction, half_kelly_fraction, portfolio_value_at_trade, analysis_data, dry_run) FROM stdin;
8	b6fcf3f4-3ebc-46a1-8753-ae95ae9899d7	2026-03-25 14:01:47.485666+00	TBPH	BUY	4	MARKET	FILLED	15.13	0.6052	50	TBPH is a post-restructuring special situation with a highly asymmetric risk/reward profile, now actionable with $280.67 cash available. Key thesis pillars all confirmed:\n\n1. DEEP NAV DISCOUNT: $380M+ cash/investments at $770M mktcap = 49.4% cash-to-mktcap. At $15.20/share with ~$7.50/share in cash, we're paying ~$7.70 for the royalty business + pipeline.\n2. TRELEGY MILESTONE CONFIRMED: Q4 2025 filing showed $53M other income (TRELEGY milestone received). Cash now ~$380M+. Revenue $45.9M in Q4 vs $20M in Q3 = strong quarter.\n3. LAZARD STRATEGIC REVIEW ACTIVE: Investment bank retained for sale/merger process. Timeline Q2-Q3 2026 = within 3-6 months. Acquirer pays cash premium to current NAV.\n4. M&A CATALYST STRUCTURE: Pharma acquirers value YUPELRI royalty stream (recurring, growing), Izencitinib pipeline (JAK inhibitor in Phase IIb/III), and cash position. Comparable M&A in specialty pharma at 20-30% premiums to NAV.\n5. LIMITED DOWNSIDE: Floor = cash per share ~$7.50. Even if strategic review fails, $380M cash vs $770M mktcap = hard floor. Downside is limited to ~$10 (from $15.20).\n6. EARNINGS SAFE: 50 days to May 14 earnings = NO earnings risk on this trade.\n7. LOW BETA: Beta 0.107 = virtually uncorrelated to market. True diversifier in Iran war environment.\n\nVALUATION: Bull $21-22 (M&A at 1.4x NAV), Base $17.34 (Clark Street fair value), Bear $11-12 (strategic review fails, cash discount widens). Expected value = 0.62 * $17.34 + 0.38 * $12.00 = $15.31 vs $15.20 current = ENTRY JUSTIFIED with upside skew.\n\nPOSITION SIZING: With $280.67 cash, 4 shares at ~$15.20 = $60.80 = 8.4% of portfolio. Appropriate for MEDIUM-HIGH conviction special situation. Leaves $220 cash for further opportunities.	0.4127272727272727	0.2	721.65	{"confidence": 0.62, "win_probability": 0.62, "expected_gain_pct": 22.0, "expected_loss_pct": -12.0}	f
\.


--
-- Data for Name: _hyper_2_5_chunk; Type: TABLE DATA; Schema: _timescaledb_internal; Owner: -
--

COPY _timescaledb_internal._hyper_2_5_chunk (id, request_id, "timestamp", ticker, action, quantity, order_type, status, filled_price, commission, order_id, reason, kelly_fraction, half_kelly_fraction, portfolio_value_at_trade, analysis_data, dry_run) FROM stdin;
9	1c1a5bb9-e461-414e-a7bf-7e1c1e30807f	2026-04-06 14:01:15.939647+00	CHH	BUY	1	MARKET	FILLED	103.96	1	56	CHH meets our 7% FCF yield mandate with 7.43% after-interest yield, has attractive fundamentals (60%+ EBITDA margins, 26% short interest, 40% insider ownership), and is trading at historically cheap 8.0x EV/EBITDA (vs 14x historical average). The only obstacle is timing - the Iran war has created a consumer headwind. With the April 6 deadline approaching, a confirmed ceasefire would remove this headwind, allowing the stock to re-rate to more normal levels. At current $103.96 price, a move to $116-118 (representing 12-14% upside) is reasonable given the valuation gap and short interest potential. Our falsification criteria are clear: if Iran does NOT comply with Trump's April 6 deadline and instead faces escalation, the consumer headwind remains, and we would not execute this trade.	0.41666666666666674	0.2	1005.49	{"confidence": 0.7, "win_probability": 0.65, "expected_gain_pct": 12.0, "expected_loss_pct": -8.0}	f
\.


--
-- Data for Name: _hyper_2_6_chunk; Type: TABLE DATA; Schema: _timescaledb_internal; Owner: -
--

COPY _timescaledb_internal._hyper_2_6_chunk (id, request_id, "timestamp", ticker, action, quantity, order_type, status, filled_price, commission, order_id, reason, kelly_fraction, half_kelly_fraction, portfolio_value_at_trade, analysis_data, dry_run) FROM stdin;
10	15645b29-b1cd-4643-b270-b239c41efefa	2026-04-14 14:01:16.368305+00	AENT	BUY	26	MARKET	FILLED	7.08	1	62	AENT is undervalued at 6x EV/EBITDA with strong vinyl tailwinds and 37-day earnings catalyst. Q2 financials show solid $368.7M revenue and $9.4M net income. Vinyl industry growth provides durable tailwind. The 0.40 beta makes it defensive in current market environment.	0.55	0.2	1026.52	{"confidence": 0.85, "win_probability": 0.7, "expected_gain_pct": 30.0, "expected_loss_pct": -15.0}	f
11	958dc762-cd7c-4a49-ad6c-d258831d01d2	2026-04-15 14:01:00.011607+00	AENT	SELL	4	MARKET	FILLED	6.77	0.272138	68	AENT position has grown to 17.7% of portfolio, exceeding target 12.5% and approaching 20% maximum. Trimming to ~15% ($153.64) aligns with rebalancing rules and manages risk while maintaining core position. Current price $6.98 remains attractive with 36 days to earnings catalyst.	0.7	0.2	1024.29	{"confidence": 0.8, "win_probability": 0.75, "expected_gain_pct": 25.0, "expected_loss_pct": -5.0}	f
\.


--
-- Data for Name: _hyper_2_7_chunk; Type: TABLE DATA; Schema: _timescaledb_internal; Owner: -
--

COPY _timescaledb_internal._hyper_2_7_chunk (id, request_id, "timestamp", ticker, action, quantity, order_type, status, filled_price, commission, order_id, reason, kelly_fraction, half_kelly_fraction, portfolio_value_at_trade, analysis_data, dry_run) FROM stdin;
12	bb4183a8-c19e-4e21-a6cf-fabd383615da	2026-04-16 14:02:05.577613+00	IPI	BUY	4	MARKET	FILLED	38.46	1	74	IPI is benefiting from fertilizer demand surge and geopolitical tensions. Current price $38.43 is below $45 target with strong fundamentals. Adding to this position leverages the ongoing crisis.	0.5499999999999998	0.2	1021.84	{"confidence": 0.8, "win_probability": 0.7, "expected_gain_pct": 12.0, "expected_loss_pct": -6.0}	f
13	cdc2fa80-39b4-4d77-a30c-d6357d129ac0	2026-04-17 14:03:56.342832+00	RILY	BUY	10	MARKET	FILLED	7.6786	0.76786	84	RILY is a Substack HIGH conviction pick with 25% BW ownership, diversified financial business, and attractive valuation. Current price $7.64 is 30% below 52-week high and offers significant upside to estimated NAV. 10 shares costs $76.40, fitting comfortably within available cash of $92.60 while establishing meaningful exposure.	0.75625	0.2	1017.51	{"confidence": 0.85, "win_probability": 0.85, "expected_gain_pct": 40.0, "expected_loss_pct": -25.0}	f
\.


--
-- Data for Name: _hyper_2_8_chunk; Type: TABLE DATA; Schema: _timescaledb_internal; Owner: -
--

COPY _timescaledb_internal._hyper_2_8_chunk (id, request_id, "timestamp", ticker, action, quantity, order_type, status, filled_price, commission, order_id, reason, kelly_fraction, half_kelly_fraction, portfolio_value_at_trade, analysis_data, dry_run) FROM stdin;
14	4c71954f-ac2e-4e5a-b54c-95422a9a1d93	2026-04-23 14:01:23.047937+00	FOUR	SELL	2	MARKET	FILLED	49.01	0.982609	90	Position has underperformed by -17.92% with no near-term catalyst to reverse the trend. Capital would be better deployed to higher-conviction opportunities like BUR at 41% book value discount with strong catalysts. FOUR has been a significant portfolio drag.	0.3999999999999998	0.1999999999999999	1024.23	{"confidence": 0.85, "win_probability": 0.7, "expected_gain_pct": 0.01, "expected_loss_pct": -0.01}	f
15	893c725d-2477-40ea-99fc-630a63d7a36c	2026-04-23 14:01:38.243787+00	IPI	SELL	2	MARKET	FILLED	37.2369	0.746662	94	Concentration risk management - IPI position is 21.91% of portfolio, exceeding the 20% maximum limit. Reducing to ~15% aligns with target position sizing and risk management requirements.	0.8999999999999999	0.2	1023.85	{"confidence": 0.95, "win_probability": 0.95, "expected_gain_pct": 0.01, "expected_loss_pct": -0.01}	f
16	bd2cd735-3eef-4412-9a40-e7c58636f71f	2026-04-23 14:01:51.813814+00	BUR	BUY	27	MARKET	FILLED	4.625	1	98	BUR is trading at $4.615, representing a 41% discount to book value ($8.13) with strong catalysts including legal finance portfolio value realization and potential spin-off. This is the highest conviction watchlist item per recent analysis. Position sizing to ~12.5% of portfolio aligns with target allocation.	0.7	0.2	1022.85	{"confidence": 0.85, "win_probability": 0.8, "expected_gain_pct": 30.0, "expected_loss_pct": -15.0}	f
17	355c34d2-cadd-4362-b9ed-2239a34ca1f8	2026-04-29 14:01:04.758127+00	IPI	SELL	4	MARKET	FILLED	38.67	1.003966	104	Full exit of IPI due to stale thesis with no catalyst realization in 76 days. Position has been a drag on portfolio performance and capital is better deployed to higher-conviction opportunities like BMI, GPN, or EFOR.	-7.8	0	1032.21	{"confidence": 0.9, "win_probability": 0.2, "expected_gain_pct": 1.0, "expected_loss_pct": -10.0}	f
18	ccf8c1d2-1a96-4ada-8750-79639d170cf8	2026-04-29 14:01:24.355724+00	AENT	SELL	4	MARKET	FILLED	7.3	0.293382	108	Reduce position from 16.3% to ~13.7% to address concentration risk and portfolio overweight. AENT remains fundamentally sound but position size exceeds target allocation. This 4-share trim meets the $25 minimum trade value requirement ($28.92).	0.125	0.0625	1030.4	{"confidence": 0.8, "win_probability": 0.75, "expected_gain_pct": 2.0, "expected_loss_pct": -5.0}	f
\.


--
-- Data for Name: _hyper_2_9_chunk; Type: TABLE DATA; Schema: _timescaledb_internal; Owner: -
--

COPY _timescaledb_internal._hyper_2_9_chunk (id, request_id, "timestamp", ticker, action, quantity, order_type, status, filled_price, commission, order_id, reason, kelly_fraction, half_kelly_fraction, portfolio_value_at_trade, analysis_data, dry_run) FROM stdin;
19	01485ca8-6d69-4d89-b2dc-131fc23d6e65	2026-04-30 14:01:48.457358+00	SKWD	SELL	2	MARKET	FILLED	44.74	0.903033	114	SKWD is ranked 8th in conviction ranking and has been underperforming (-2.28% in portfolio). Portfolio action required explicitly states 'SELL RAL/SKWD post-open'. Current price $44.86 is above stop-loss $35.00 but well below target $52.00 with no catalyst realization. Opportunity cost is high with BMI available at 12.2% insider discount.	0.2	0.1	1029.35	{"confidence": 0.7, "win_probability": 0.6, "expected_gain_pct": 0.01, "expected_loss_pct": -0.01}	f
20	eb6d9582-02b4-4ec5-99cc-088b36152f06	2026-04-30 14:02:06.469856+00	RAL	SELL	2	MARKET	FILLED	43.48	0.871781	118	RAL is ranked 7th in conviction ranking and has been a drag (-2.34% in portfolio). Portfolio action required explicitly states 'SELL RAL/SKWD post-open'. Current price $43.48 is above stop-loss $36.00 but well below target $52.00 with no catalyst realization. Opportunity cost is high with BMI available at 12.2% insider discount.	0.2	0.1	1016.06	{"confidence": 0.7, "win_probability": 0.6, "expected_gain_pct": 0.01, "expected_loss_pct": -0.01}	f
21	e8002923-050c-452a-9fe1-472b0d6a4e07	2026-04-30 14:02:25.316653+00	BMI	BUY	1	MARKET	FILLED	119.23	1	122	BMI is available at $121.75, representing a 12.2% discount to insider purchases at $136. The company has strong fundamentals with $202M Q1 revenue (+15% YoY) and $27M net income. With next earnings 89 days away (low risk), this represents a high-conviction value opportunity with strong insider alignment.	0.5694444444444444	0.2	1014.91	{"confidence": 0.85, "win_probability": 0.75, "expected_gain_pct": 18.0, "expected_loss_pct": -13.0}	f
\.


--
-- Data for Name: _hyper_3_2_chunk; Type: TABLE DATA; Schema: _timescaledb_internal; Owner: -
--

COPY _timescaledb_internal._hyper_3_2_chunk (id, "timestamp", total_value, cash_balance, positions, daily_pnl, daily_pnl_pct) FROM stdin;
1	2026-02-19 19:17:32.651744+00	498.12	329.59	{}	0	0
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alembic_version (version_num) FROM stdin;
002_fractional_shares
\.


--
-- Data for Name: claude_decisions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.claude_decisions (id, "timestamp", ticker, decision, confidence, win_probability, expected_gain_pct, expected_loss_pct, reasoning, data_sources, trade_id) FROM stdin;
1	2026-02-19 18:51:17.090364+00	IPI	BUY	0.58	0.6	47	-20	TIER 2 CONVICTION - Fortress balance sheet, Gate City $49 target (+47% upside)	null	1
2	2026-02-19 18:51:21.459772+00	FOUR	BUY	0.58	0.55	162	-22	HIGHEST CONVICTION - Shift4 Payments at 11x EBITDA vs Toast 24x, Greystone $155 target	null	2
3	2026-02-19 19:14:37.250705+00	DMLP	BUY	0.5	0.58	20	-10	DMLP oil royalty LP: Zero capex, $130M TTM FCF, 10.6% yield, net cash $40.8M. Iran crisis direct tailwind on oil prices. 5 insiders bought $1.63M at $22.95 (now +10.9%). 9.5x P/FCF for zero-capex royalty is cheap. Target $30 (conservative retest vs $32.47 52-wk high) = 17.8% upside. Commodity binary risk from Iran resolution. Small starter position given binary event risk around Iran decision (~March 1). FALSIFICATION: WTI below $55, 2+ quarters of declining distributions, overpriced royalty acquisition.	null	3
4	2026-02-19 19:17:32.276873+00	DMLP	BUY	0.5	0.58	20	-10	DMLP oil royalty LP: Zero capex, $130M TTM FCF, 10.6% yield, net cash $40.8M. Iran crisis direct tailwind on oil prices. 5 insiders bought $1.63M at $22.95 (now +10.9%). 9.5x P/FCF for zero-capex royalty is cheap. Target $30 (conservative retest vs $32.47 52-wk high) = 17.8% upside. Commodity binary risk from Iran resolution. Small starter position given binary event risk around Iran decision (~March 1). FALSIFICATION: WTI below $55, 2+ quarters of declining distributions, overpriced royalty acquisition.	null	4
5	2026-02-20 20:02:54.160536+00	RAL	BUY	0.62	0.6	38	-15	Ralliant Corp (RAL) is a precision instruments/defense company spun off from Fortive (IPO June 2025). Core thesis: 7.3% FCF yield ($358M TTM / $4.91B mkt cap) on a business with 15.2% YoY revenue growth ($481M→$554M in 4 quarters), net debt declining ($997M→$830M in 3 quarters), and direct defense tailwind. Q4 net loss of -$1.39B was entirely non-cash goodwill impairment; operating income was +$73.9M and FCF was $91.6M. Post-impairment goodwill stands at $1.672B — further impairments possible but unlikely at this level. 6 insiders bought $512K at $40.45 on Feb 10 (confirmed post-lockup discretionary buying); stock now $43.50 = +7.5% already. SCOTUS tariff ruling (today) is mildly positive for RAL's precision component inputs. Iran deal signal softens immediate defense catalyst slightly but RAL's revenue is from long-cycle DoD procurement programs (not Iran-war-dependent). Target: $60 = 13.8x TTM FCF (fair for defense precision instruments growing 15% with improving balance sheet). At $43.50, buying at 12.2x TTM FCF with 7.3% FCF yield. Commission on $50 position: $1 minimum = 2% drag, acceptable. Portfolio sizing: $50 = 10% of $496 portfolio = 1.15 shares. Total deployed after this: $50 RAL + $76 DMLP + $118 FOUR + $99 IPI = $343 = 69% deployed, $153 cash remaining. Within limits.	null	5
6	2026-03-12 17:29:06.077754+00	IPI	SELL	0.95	0.9	2	-5	MANDATORY RISK MANAGEMENT TRIM — not a thesis exit. IPI has surged to $49.21 (+46.6% from $33.56 cost), new all-time high $50.31 intraday. At 3 shares x $49.21 = $147.63 / ~$522 portfolio = 28.2% — above the 25% hard cap. Pre-committed trim at $48-49. Thesis intact. After selling 1 share: 2 shares remain for $55 target. Locking +$15.65/share gain on sold share.	null	6
7	2026-03-17 14:02:15.251681+00	SKWD	BUY	0.68	0.65	42.9	-11.9	SKWD at $45.51 — HIGH conviction buy. 10.33% TTM operating income yield ($209M/$2.02B mktcap), 7.86% net income yield. Specialty P&C insurer: operating income IS the FCF proxy. Revenue growing 43% YoY. Iran war Day 18 — Ali Larijani killed TODAY = war escalation structurally elevates marine/aviation/war-risk premiums for months. 3 insiders bought $1.42M at $47.00 on Mar 2 (now 3.3% above entry = insiders underwater, strong signal). No meaningful debt. Beta 0.52 defensive. Target $65 = 42.9% upside. Stop at $40 = 11.9% loss. Sizing to 2 shares to stay within 25% position limit ($91 / $506 = 18%).	null	7
8	2026-03-25 14:01:47.522724+00	TBPH	BUY	0.62	0.62	22	-12	TBPH is a post-restructuring special situation with a highly asymmetric risk/reward profile, now actionable with $280.67 cash available. Key thesis pillars all confirmed:\n\n1. DEEP NAV DISCOUNT: $380M+ cash/investments at $770M mktcap = 49.4% cash-to-mktcap. At $15.20/share with ~$7.50/share in cash, we're paying ~$7.70 for the royalty business + pipeline.\n2. TRELEGY MILESTONE CONFIRMED: Q4 2025 filing showed $53M other income (TRELEGY milestone received). Cash now ~$380M+. Revenue $45.9M in Q4 vs $20M in Q3 = strong quarter.\n3. LAZARD STRATEGIC REVIEW ACTIVE: Investment bank retained for sale/merger process. Timeline Q2-Q3 2026 = within 3-6 months. Acquirer pays cash premium to current NAV.\n4. M&A CATALYST STRUCTURE: Pharma acquirers value YUPELRI royalty stream (recurring, growing), Izencitinib pipeline (JAK inhibitor in Phase IIb/III), and cash position. Comparable M&A in specialty pharma at 20-30% premiums to NAV.\n5. LIMITED DOWNSIDE: Floor = cash per share ~$7.50. Even if strategic review fails, $380M cash vs $770M mktcap = hard floor. Downside is limited to ~$10 (from $15.20).\n6. EARNINGS SAFE: 50 days to May 14 earnings = NO earnings risk on this trade.\n7. LOW BETA: Beta 0.107 = virtually uncorrelated to market. True diversifier in Iran war environment.\n\nVALUATION: Bull $21-22 (M&A at 1.4x NAV), Base $17.34 (Clark Street fair value), Bear $11-12 (strategic review fails, cash discount widens). Expected value = 0.62 * $17.34 + 0.38 * $12.00 = $15.31 vs $15.20 current = ENTRY JUSTIFIED with upside skew.\n\nPOSITION SIZING: With $280.67 cash, 4 shares at ~$15.20 = $60.80 = 8.4% of portfolio. Appropriate for MEDIUM-HIGH conviction special situation. Leaves $220 cash for further opportunities.	null	8
9	2026-04-06 14:01:15.977953+00	CHH	BUY	0.7	0.65	12	-8	CHH meets our 7% FCF yield mandate with 7.43% after-interest yield, has attractive fundamentals (60%+ EBITDA margins, 26% short interest, 40% insider ownership), and is trading at historically cheap 8.0x EV/EBITDA (vs 14x historical average). The only obstacle is timing - the Iran war has created a consumer headwind. With the April 6 deadline approaching, a confirmed ceasefire would remove this headwind, allowing the stock to re-rate to more normal levels. At current $103.96 price, a move to $116-118 (representing 12-14% upside) is reasonable given the valuation gap and short interest potential. Our falsification criteria are clear: if Iran does NOT comply with Trump's April 6 deadline and instead faces escalation, the consumer headwind remains, and we would not execute this trade.	null	9
10	2026-04-14 14:01:16.405975+00	AENT	BUY	0.85	0.7	30	-15	AENT is undervalued at 6x EV/EBITDA with strong vinyl tailwinds and 37-day earnings catalyst. Q2 financials show solid $368.7M revenue and $9.4M net income. Vinyl industry growth provides durable tailwind. The 0.40 beta makes it defensive in current market environment.	null	10
11	2026-04-15 14:01:00.027748+00	AENT	SELL	0.8	0.75	25	-5	AENT position has grown to 17.7% of portfolio, exceeding target 12.5% and approaching 20% maximum. Trimming to ~15% ($153.64) aligns with rebalancing rules and manages risk while maintaining core position. Current price $6.98 remains attractive with 36 days to earnings catalyst.	null	11
12	2026-04-16 14:02:05.608874+00	IPI	BUY	0.8	0.7	12	-6	IPI is benefiting from fertilizer demand surge and geopolitical tensions. Current price $38.43 is below $45 target with strong fundamentals. Adding to this position leverages the ongoing crisis.	null	12
13	2026-04-17 14:03:56.35111+00	RILY	BUY	0.85	0.85	40	-25	RILY is a Substack HIGH conviction pick with 25% BW ownership, diversified financial business, and attractive valuation. Current price $7.64 is 30% below 52-week high and offers significant upside to estimated NAV. 10 shares costs $76.40, fitting comfortably within available cash of $92.60 while establishing meaningful exposure.	null	13
14	2026-04-23 14:01:23.08991+00	FOUR	SELL	0.85	0.7	0.01	-0.01	Position has underperformed by -17.92% with no near-term catalyst to reverse the trend. Capital would be better deployed to higher-conviction opportunities like BUR at 41% book value discount with strong catalysts. FOUR has been a significant portfolio drag.	null	14
15	2026-04-23 14:01:38.252209+00	IPI	SELL	0.95	0.95	0.01	-0.01	Concentration risk management - IPI position is 21.91% of portfolio, exceeding the 20% maximum limit. Reducing to ~15% aligns with target position sizing and risk management requirements.	null	15
16	2026-04-23 14:01:51.821983+00	BUR	BUY	0.85	0.8	30	-15	BUR is trading at $4.615, representing a 41% discount to book value ($8.13) with strong catalysts including legal finance portfolio value realization and potential spin-off. This is the highest conviction watchlist item per recent analysis. Position sizing to ~12.5% of portfolio aligns with target allocation.	null	16
17	2026-04-29 14:01:04.768021+00	IPI	SELL	0.9	0.2	1	-10	Full exit of IPI due to stale thesis with no catalyst realization in 76 days. Position has been a drag on portfolio performance and capital is better deployed to higher-conviction opportunities like BMI, GPN, or EFOR.	null	17
18	2026-04-29 14:01:24.364042+00	AENT	SELL	0.8	0.75	2	-5	Reduce position from 16.3% to ~13.7% to address concentration risk and portfolio overweight. AENT remains fundamentally sound but position size exceeds target allocation. This 4-share trim meets the $25 minimum trade value requirement ($28.92).	null	18
19	2026-04-30 14:01:48.484179+00	SKWD	SELL	0.7	0.6	0.01	-0.01	SKWD is ranked 8th in conviction ranking and has been underperforming (-2.28% in portfolio). Portfolio action required explicitly states 'SELL RAL/SKWD post-open'. Current price $44.86 is above stop-loss $35.00 but well below target $52.00 with no catalyst realization. Opportunity cost is high with BMI available at 12.2% insider discount.	null	19
20	2026-04-30 14:02:06.478076+00	RAL	SELL	0.7	0.6	0.01	-0.01	RAL is ranked 7th in conviction ranking and has been a drag (-2.34% in portfolio). Portfolio action required explicitly states 'SELL RAL/SKWD post-open'. Current price $43.48 is above stop-loss $36.00 but well below target $52.00 with no catalyst realization. Opportunity cost is high with BMI available at 12.2% insider discount.	null	20
21	2026-04-30 14:02:25.323638+00	BMI	BUY	0.85	0.75	18	-13	BMI is available at $121.75, representing a 12.2% discount to insider purchases at $136. The company has strong fundamentals with $202M Q1 revenue (+15% YoY) and $27M net income. With next earnings 89 days away (low risk), this represents a high-conviction value opportunity with strong insider alignment.	null	21
22	2026-05-01 14:01:06.902878+00	CHH	SELL	0.95	0.95	0.01	-5	CHH thesis is broken due to Q1 earnings miss (EPS $0.44 vs expected). The position has -2.74% unrealized loss and 'NONE' conviction level in active theses. I would not buy CHH today at current price of $102.08, so holding is not justified. This is a clear application of sell discipline - the thesis has been invalidated by evidence.	null	22
23	2026-05-01 14:01:26.827931+00	BMI	BUY	0.85	0.85	18.5	-13.5	BMI is trading at a 10% discount to insider purchase price ($122.37 vs $136+), with strong Q1 2026 fundamentals (10.4% revenue growth, 7.2% net income growth). The company benefits from secular trends in water infrastructure modernization and smart metering adoption. Current position is 11.8% of portfolio, and adding 1 more share would bring it to ~16.5%, which is acceptable given the HIGH conviction level and strong insider alignment. The target price is $145.00, providing 18.5% upside.	null	23
24	2026-05-01 14:01:45.81517+00	SU	BUY	0.75	0.75	15	-10	SU is a stable, large-cap integrated oil company benefiting from structural oil market changes (UAE OPEC exit, Hormuz blockade). With Q4 2025 net income $1.48B and EPS $1.23, SU has consistent earnings and a solid dividend yield (~2.5%). Adding SU provides diversified oil exposure that complements the existing DMLP position and addresses the TOP PRIORITY oil sector analysis need.	null	24
25	2026-05-07 14:02:03.479749+00	BMI	SELL	0.9	0.85	0.01	-0.01	BMI is 24.2% of portfolio, exceeding our 20% hard limit. This creates unacceptable concentration risk. We need to trim to approximately 15% of portfolio.	null	25
26	2026-05-07 14:02:28.481183+00	TBPH	SELL	0.8	0.7	0.01	-0.01	TBPH is a stub position at 6.5% of portfolio, below our 10% meaningful position threshold. Exiting frees capital for higher-conviction opportunities like GPN (5x P/E value).	null	26
27	2026-05-08 14:02:26.56978+00	SU	SELL	0.65	0.65	20	-15	SU position showing concerning divergence from oil price fundamentals despite Brent at $114, with 5.4% decline from entry. Trim reduces exposure to geopolitical uncertainty while maintaining partial position for potential upside.	null	27
28	2026-05-08 14:02:35.831636+00	GPN	BUY	0.75	0.7	25	-15	GPN is trading at 5x P/E with $6.5B buyback planned, $3.4B FCF in 2026, and revenue/EBITDA/EPS up 60% from 2021-2026E. This represents a significant valuation gap versus peers and provides the best opportunity to deploy the portfolio's 44.4% cash position.	null	28
29	2026-05-13 14:03:25.165775+00	GPN	BUY	0.9	0.75	25	-15	GPN is a compelling value opportunity trading at 5x P/E with strong underlying business generating $849M EBITDA in Q1 2026. The $6.5B buyback program is temporarily paused but will resume as leverage improves. This represents the highest-conviction opportunity to deploy our 44% cash drag.	null	29
30	2026-05-13 14:03:40.541889+00	SU	SELL	0.95	0.85	0.01	-1.5	SU thesis is broken: persistent divergence from oil fundamentals despite Iran war and Hormuz blockade, consistent Substack sell recommendations, and Q1 beat not moving the stock. Market is pricing in demand destruction or de-escalation. Falsification criteria met: Hormuz remains closed but stock underperforms, indicating thesis invalidation.	null	30
31	2026-05-14 14:01:40.80129+00	GPN	SELL	0.9	0.85	0.01	-2	GPN concentration exceeds 20% maximum (currently 20.35% of portfolio). Trim 1 share to reduce concentration risk and bring position to ~15% target size. This is pure risk management with no thesis change - the value thesis remains intact.	null	31
32	2026-05-14 14:01:59.813355+00	RILY	BUY	0.85	0.8	15	-5	RILY is the portfolio's top performer (+11.2%) and has strong fundamentals (Q1 revenue $450M, net income $213M). It's a M&A/IPO wave beneficiary and has been consistently recommended by Substack. Adding to this high-conviction winner addresses the cash drag and underperformance.	null	32
33	2026-05-14 14:02:14.339796+00	DMLP	BUY	0.8	0.75	25	-10	DMLP has performed well (+3.7%) and benefits directly from the oil crisis. With Aramco warning of critically low fuel stocks and 100M barrels lost weekly from Hormuz closure, DMLP's energy transportation thesis is strongly supported. This deployment addresses the cash drag and underperformance.	null	33
34	2026-05-14 14:02:38.28103+00	AENT	BUY	0.75	0.7	12	-6	AENT has solid fundamentals (Q1 revenue $450M) and is trading near its 52-week low. Adding to this position diversifies the portfolio and addresses the cash drag. The stock has shown positive momentum recently.	null	34
35	2026-05-14 14:02:50.617948+00	BUR	BUY	0.75	0.7	15	-7	BUR has performed well (+1.35%) and operates in the litigation finance space, which benefits from market volatility and uncertainty. Adding to this position diversifies the portfolio and addresses the cash drag.	null	35
36	2026-05-14 14:03:27.193029+00	COGT	BUY	0.75	0.7	30	-15	COGT has strong clinical oncology pipeline with Bezuclastinib for Systemic Mastocytosis & GIST, with >$3B peak sales estimated. It's a potential M&A target and has been consistently recommended by Yellowbrick. This deployment addresses the cash drag and diversifies the portfolio.	null	36
37	2026-05-15 14:02:12.453719+00	BUR	SELL	0.7	0.65	0.01	-5	Trimming BUR to reduce concentration risk from 19.9% to ~15% of portfolio. BUR has shown earnings volatility (Q4 2025 $37.5M loss vs Q2 2025 $88.3M profit) and is approaching our 20% position limit. This is risk management, not thesis invalidation.	null	37
38	2026-05-15 14:02:22.498941+00	OBE	BUY	0.8	0.75	40	-15	OBE is the most shorted oil producer (34.1% short interest) with GME-like short squeeze potential if Hormuz tensions escalate. Trading at $13.095 with strong oil leverage thesis intact. Hormuz closure continues with 100M barrels lost weekly per Aramco warning. This represents the highest asymmetric opportunity in the energy sector.	null	38
39	2026-05-18 14:02:26.45699+00	COGT	SELL	0.95	0.95	0.01	-20	COGT has no revenue and continues to burn cash ($97M loss in Q1 2026). The thesis of clinical oncology pipeline value has not materialized, and the position has underperformed by -7.7%. With no near-term catalysts and 78 days until next earnings, there's no reason to hold this pure burn play. The position violates our principle of not holding companies without revenue.	null	39
40	2026-05-18 14:02:35.536789+00	PEW	BUY	0.95	0.9	25	-5	PEW trades at a 20% discount to cash ($2.905 vs $3.51 cash/share). With $106M cash vs $85M market cap, this represents a classic net-net value opportunity with strong downside protection. The business is growing 15% vs industry -10.6% decline, and $20M buyback is half executed. This is a high-conviction value play with asymmetric upside.	null	40
41	2026-05-18 14:02:44.824259+00	DMLP	SELL	0.8	0.7	0.01	-15	DMLP represents 19.1% of portfolio, approaching our 20% maximum position size. Given the binary outcome risk from UK military mission to stabilize Hormuz shipping (which could reduce oil premium), trimming this position reduces concentration risk while maintaining oil leverage exposure. The thesis remains valid but the position size is excessive.	null	41
42	2026-05-18 14:03:10.441069+00	PEW	BUY	0.97	0.95	30	-5	PEW trades at a 20% discount to cash ($2.905 vs $3.51 cash/share). With $106M cash vs $85M market cap, this represents a classic net-net value opportunity with strong downside protection. The business is growing 15% vs industry -10.6% decline, and $20M buyback is half executed. This is a high-conviction value play with asymmetric upside.	null	42
43	2026-05-18 14:03:26.0224+00	PEW	BUY	0.97	0.95	30	-5	PEW trades at a 20% discount to cash ($2.905 vs $3.51 cash/share). With $106M cash vs $85M market cap, this represents a classic net-net value opportunity with strong downside protection. The business is growing 15% vs industry -10.6% decline, and $20M buyback is half executed. This is a high-conviction value play with asymmetric upside.	null	43
44	2026-05-18 14:03:38.956954+00	POOL	BUY	0.9	0.85	15	-8	POOL is a resilient consumer discretionary company in the pool products sector. Q1 2026 revenue $1.14B, net income $53.2M (EPS $1.46). The company has strong insider support with $7.67M in insider buying, indicating management confidence in the business. Trading at a reasonable valuation, this represents a quality value opportunity.	null	44
45	2026-05-18 14:03:58.439052+00	RILY	BUY	0.9	0.85	15	-10	RILY is our top-performing position (+15% alpha) with strong fundamentals. Q1 2026 revenue $450.6M, net income $213.3M (EPS $6.98). This represents a quality business at a cheap valuation (P/E ~1.3x). Adding to our winner makes sense given its strong performance and fundamentals.	null	45
46	2026-05-18 14:04:11.371292+00	RILY	BUY	0.9	0.85	15	-10	RILY is our top-performing position (+15% alpha) with strong fundamentals. Q1 2026 revenue $450.6M, net income $213.3M (EPS $6.98). This represents a quality business at a cheap valuation (P/E ~1.3x). Adding to our winner makes sense given its strong performance and fundamentals.	null	46
47	2026-05-19 14:03:05.100011+00	AENT	SELL	0.8	0.7	0.01	-25	AENT is the worst performer in the portfolio at -6.2% and represents 12.2% of portfolio value. Trimming this position reduces exposure to underperforming assets and frees capital for higher-conviction opportunities. The company's fundamentals show declining revenue and margins, justifying reduction.	null	47
48	2026-05-19 14:03:23.033753+00	PEW	BUY	0.85	0.7	50	-20	PEW trades at a 20% discount to cash ($2.89 vs $3.51 cash/share) with strong growth potential. The company is transitioning from losses to profitability, with revenue growing from $22.3M to $25.9M sequentially. Management is executing on growth initiatives including PEW Logistics for D2C fulfillment and targeting 3-4% market penetration of the $9B US firearms market.	null	48
49	2026-05-19 14:03:30.617693+00	OBE	BUY	0.8	0.65	30	-25	OBE is a Canadian oil producer benefiting from Substack's bullish summer travel demand thesis and current geopolitical energy supply disruption. With oil at $110/barrel and Hormuz closure, OBE has strong EBITDA ($55.8M in Q1 2026) and is positioned to benefit from summer travel-related demand.	null	49
50	2026-05-19 14:03:55.033605+00	GPN	SELL	0.7	0.6	0.01	-15	GPN is currently at 14.0% of portfolio weight, approaching the maximum position size limit of 20%. Trimming this position reduces concentration risk and frees capital for higher-conviction opportunities like PEW, while maintaining some exposure to the value opportunity.	null	50
51	2026-05-19 14:04:10.140553+00	PEW	BUY	0.85	0.7	50	-20	PEW trades at a 20% discount to cash ($2.89 vs $3.51 cash/share) with strong growth potential. The company is transitioning from losses to profitability, with revenue growing from $22.3M to $25.9M sequentially. Management is executing on growth initiatives including PEW Logistics for D2C fulfillment and targeting 3-4% market penetration of the $9B US firearms market.	null	51
52	2026-05-19 14:04:24.102683+00	PEW	BUY	0.85	0.7	50	-20	PEW trades at a 20% discount to cash ($2.89 vs $3.51 cash/share) with strong growth potential. The company is transitioning from losses to profitability, with revenue growing from $22.3M to $25.9M sequentially. Management is executing on growth initiatives including PEW Logistics for D2C fulfillment and targeting 3-4% market penetration of the $9B US firearms market.	null	52
53	2026-05-20 14:01:16.998546+00	PEW	BUY	0.95	0.85	35	-15	PEW trades at $2.73/share with $3.51 cash per share (20% discount to cash), $106.4M cash, $29.7M debt, and solid growth (25.9M revenue in Q1 2026). This represents an exceptional net-net value opportunity with built-in downside protection. The company is well-positioned in the firearms retail sector with growing revenue and strong cash flow.	null	53
54	2026-05-20 14:01:31.2118+00	OBE	BUY	0.9	0.75	25	-12	OBE is a Canadian oil producer trading at $12.85 with strong Q1 2026 fundamentals: $151.4M revenue, $29.6M operating income, $263.6M cash. Substack consistently recommends holding OBE as 'the most shorted oil producer' with GME-like short squeeze potential. The company benefits from oil prices at $110/barrel and upcoming summer travel demand, which should boost demand for oil and gas.	null	54
55	2026-05-20 14:01:53.527578+00	RILY	BUY	0.95	0.8	20	-10	RILY is our strongest performer (+21.9% vs portfolio) with exceptional Q1 2026 results: $450.6M revenue, $253.6M operating income, and $213.3M net income. The company is executing exceptionally well on its business model and represents a high-quality growth opportunity. Adding to this position increases our exposure to a proven winner while deploying cash to address the portfolio's -10.31% alpha underperformance.	null	55
56	2026-05-20 14:02:09.19797+00	GPN	BUY	0.85	0.7	30	-15	GPN is a high-quality value stock trading at 5x P/E with $2.97B Q1 revenue and $6.5B buyback program. The company has strong fundamentals and represents a compelling deep value opportunity. Adding to this position aligns with our value investing thesis and deploys cash to address the portfolio's -10.31% alpha underperformance.	null	56
57	2026-05-20 14:03:10.146876+00	DMLP	BUY	0.9	0.75	30	-12	DMLP is a zero-capex oil/gas royalty LP with $129.7M TTM FCF, net cash position, and direct upside leverage to oil prices. The Hormuz closure from the Iran war is a structural supply disruption that elevates WTI well above the $55 falsification floor. Every $10/bbl oil increase adds ~$13M annual FCF. With oil at $110/barrel and ongoing geopolitical tensions, this represents a high-conviction oil leverage opportunity.	null	57
58	2026-05-21 16:04:37.945142+00	AENT	SELL	0.7	0.6	2	-3	Trimming 6 shares of AENT (67% of position) to raise meaningful cash for portfolio optimization. Portfolio in crisis with -11.26% alpha underperformance, minimal cash (2.3%) limiting deployment. Need sufficient cash to deploy to higher-conviction opportunities.	null	58
59	2026-05-21 16:05:14.822356+00	OBE	SELL	0.7	0.6	2	-3	Trimming 4 shares of OBE to reduce portfolio concentration from 19.7% toward target ~12.5%. Portfolio in crisis with -11.26% alpha underperformance requires rebalancing. Geopolitical de-escalation (Iran strike called off) may pressure oil premium. Cash raised can be deployed to other opportunities.	null	59
60	2026-05-25 14:01:22.803877+00	AENT	SELL	0.85	0.85	0.01	-13.5	AENT position has breached its $5.95 stop-loss ($6.16 current price), triggering CODE RED protocol. The position is also a stub at only 1.9% of portfolio, below the 5% minimum meaningful size. No earnings date has been confirmed despite multiple checks, creating uncertainty for position management. With the portfolio in crisis (-12.53% alpha underperformance vs SPY), capital should be redeployed to higher-conviction opportunities. Selling AENT frees up $18.48 for redeployment to addresses the portfolio crisis.	null	60
61	2026-05-25 14:01:49.692433+00	AENT	SELL	0.85	0.85	0.01	-13.5	AENT position has breached its $5.95 stop-loss ($6.16 current price), triggering CODE RED protocol. The position is also a stub at only 1.9% of portfolio, below the 5% minimum meaningful size. No earnings date has been confirmed despite multiple checks, creating uncertainty for position management. With the portfolio in crisis (-12.53% alpha underperformance vs SPY), capital should be redeployed to higher-conviction opportunities. Selling AENT frees up $18.48 for redeployment to addresses the portfolio crisis.	null	61
62	2026-05-25 14:02:12.791808+00	AENT	SELL	0.75	0.75	0.01	-13.5	AENT is a stub position at only 1.9% of portfolio value, below the 5% minimum meaningful size requirement. Stub positions do not justify monitoring cost and waste attention that should be focused on higher-conviction opportunities. With the portfolio in crisis (-12.53% alpha underperformance vs SPY), capital should be redeployed to higher-conviction opportunities. Selling AENT frees up $18.48 for redeployment to address the portfolio crisis.	null	62
63	2026-05-26 14:01:51.724802+00	AENT	SELL	0.9	0.85	10	-15	AENT is a stub position at 1.9% (below 5% minimum threshold) and is approaching its stop-loss of $5.95 ($6.485 current price is only $0.535 above stop). The position is too small to justify monitoring cost while approaching a critical threshold. With no earnings date found in system and the portfolio crisis requiring urgent optimization, selling this stub position frees up capital for higher-conviction opportunities and eliminates a monitoring burden.	null	63
64	2026-05-26 14:02:00.647647+00	DMLP	SELL	0.85	0.2	5	-20	DMLP's oil leverage thesis is being materially undermined by Trump's announcement that the Strait of Hormuz deal is 'largely negotiated.' This represents a fundamental shift in the investment thesis, not just price movement. The core catalyst for DMLP's valuation premium (oil conflict risk) is being removed. Market implications: Oil premium compression likely, pressure on energy stocks with conflict premium exposure. With the portfolio overweight in energy (27.6% combined OBE+DMLP), reducing this position addresses sector concentration risk.	null	64
65	2026-05-26 14:02:08.133062+00	OBE	SELL	0.8	0.3	8	-25	OBE's summer travel thesis remains but faces significant headwind from the Strait of Hormuz reopening, which would pressure oil premium and create a lower oil price environment. The portfolio is overweight energy (27.6% combined OBE+DMLP) and faces geopolitical uncertainty. With RILY as the sole strong performer, reducing energy concentration improves portfolio diversification and risk management.	null	65
66	2026-05-26 14:02:15.729759+00	SBLK	BUY	0.85	0.75	30	-12	SBLK is the top watchlist candidate from Yellowbrick - Star Bulk Carriers with 145-vessel dry bulk fleet, scrap value $975M > gross debt $951M, high operating leverage. This provides perfect portfolio diversification away from energy exposure and geopolitical risk. With the Strait of Hormuz reopening, shipping sector could benefit from increased trade flows. Current portfolio needs sector diversification away from oil exposure.	null	66
67	2026-05-26 14:02:40.297636+00	BRCB	BUY	0.85	0.8	25	-10	BRCB shows strong fundamentals with $55.5M Q1 2026 revenue and improving profitability. The massive insider buying ($73.3M by 3 insiders) indicates exceptional institutional conviction. This provides diversification away from energy exposure and represents a high-conviction opportunity that fits within available capital constraints.	null	67
68	2026-05-27 14:02:12.85022+00	ESTA	BUY	0.7	0.65	55	-20	ESTA represents healthcare diversification with strong Ozempic tailwind catalyst and FDA approval catalyst. Current valuation discount provides attractive risk/reward. Portfolio needs sector diversification beyond energy exposure.	null	68
69	2026-05-27 14:03:33.519287+00	DNA	BUY	0.65	0.6	40	-25	DNA represents healthcare/biotech exposure with potential upside from synthetic biology platform. Current valuation appears reasonable given growth potential and market divergence creates opportunity.	null	69
70	2026-05-28 14:02:50.098056+00	ESTA	SELL	0.95	0.85	0.01	-5	ESTA has breached its stop-loss of $180.00, with current price at $71.995. The stop-loss breach triggers the default action to sell unless overwhelming new fundamental evidence is found. No such evidence has been identified in current analysis. The updated thesis indicates the FDA approval catalyst has not materialized as expected, invalidating the original investment premise.	null	70
71	2026-05-28 14:03:03.521862+00	DNA	SELL	0.85	0.7	0.01	-2	DNA is a stub position at 4.5% of the portfolio, below the 5% minimum threshold. Stub positions below 5% do not justify monitoring cost and should be exited to free up capital for more promising opportunities. The portfolio needs optimization to address the -11.0% underperformance crisis.	null	71
72	2026-05-28 14:03:29.562968+00	RILY	SELL	0.8	0.6	0.01	-3	RILY has performed exceptionally well (+37.7%), representing 11.0% of the portfolio. To address the portfolio's -11.0% underperformance crisis, we need to deploy capital into new opportunities like VISN and OSB. Trimming 3 shares of RILY will free up approximately $32 to fund these new positions while maintaining a meaningful RILY position.	null	72
73	2026-05-28 14:03:43.618484+00	VISN	BUY	0.85	0.75	13.8	-5	VISN is trading at $12.32, well below its $14 target price from Substack. The company is a communications infrastructure provider with strong fundamentals ($471.8M revenue in Q1 2026) and benefits from the DOCSIS 4.0 upgrade tailwind. This represents an attractive entry point with asymmetric risk/reward.	null	73
74	2026-05-29 14:02:38.044562+00	VISN	SELL	0.8	0.8	2	-6	VISN is our second largest position at 18.0% of portfolio and has concerning financials with negative $1.5B net income in Q1 2026. We need to reduce concentration and address the fundamental weakness while raising cash for better opportunities.	null	74
75	2026-05-29 14:03:09.66819+00	SBLK	SELL	0.85	0.85	2.5	-5	SBLK is our largest position at 19.6% of portfolio, exceeding our 20% maximum but violating our target of ~12.5%. We need to reduce concentration for risk management while maintaining our thesis that SBLK benefits from global trade normalization and shipping demand.	null	75
76	2026-05-29 14:03:45.576156+00	ROCK	BUY	0.85	0.75	25	-10	ROCK has strong fundamentals with 12% revenue growth, margin expansion, and raised guidance. The substack $100 target represents 2.5x upside and is confirmed by the research showing sustained demand in solar and construction end-markets. We're buying 2 shares to establish a meaningful position while maintaining risk management discipline.	null	76
77	2026-06-02 14:02:52.273358+00	RILY	SELL	0.8	0.7	25	-15	RILY has performed exceptionally well (+26.0% unrealized PnL) and represents the largest source of portfolio alpha. Selling 3 shares (42.9% of position) will generate approximately $29.31 in cash, increasing portfolio cash from 3.8% to ~7.0% and reducing concentration risk while maintaining exposure to this strong performer. This aligns with the portfolio rebalancing imperative and meets the minimum trade size requirement.	null	77
78	2026-06-02 14:03:00.635082+00	ROCK	SELL	0.7	0.6	5	-20	ROCK has declined -4.1% from entry price ($39.81 to $38.16) and the Substack $100 target remains valid but distant. With 6 positions lacking formal theses and critical cash constraints, selling 1 share (50% of position) will generate $38.16 in cash, increasing portfolio cash to ~11.0% and addressing the discipline violation. This is a tactical cash generation move, not thesis invalidation, as the $100 target remains intact.	null	78
79	2026-06-02 14:03:08.572588+00	SBLK	SELL	0.75	0.65	10	-15	SBLK has performed moderately well (+1.6% unrealized PnL) and is our second largest position at 17.5% of portfolio. Selling 1 share (16.7% of position) will generate approximately $27.73 in cash, increasing portfolio cash to ~13.5% and reducing concentration risk. This addresses the portfolio rebalancing imperative while maintaining exposure to this core holding.	null	79
80	2026-06-03 14:01:50.063819+00	RLI	BUY	0.75	0.7	15	-8	RLI represents a high-conviction insurance sector rotation opportunity with strong fundamentals. Trading at $51.005 with Q1 2026 net income of $54.89M and $0.60 EPS, RLI shows consistent profitability in the property & casualty insurance space. With a low beta (0.383) and $4.66 dividend, it provides defensive characteristics while benefiting from sector rotation signals. The recent $859K insider buying cluster confirms management's confidence in the company's prospects.	null	80
81	2026-06-03 14:02:18.013697+00	ROCK	SELL	0.6	0.55	20	-12	ROCK requires thesis review and position size adjustment. Currently at 3.9% of portfolio (below 5% minimum), it's a stub position that doesn't justify monitoring cost. The $39.81 entry price is above current $37.98 price (-4.7% decline), but with strong insider buying ($1.56M by 4 insiders) and Substack $100 target (2.5x upside), the thesis remains intact. Selling 1 share reduces the position to 2 shares while maintaining exposure to the solar construction thesis.	null	81
82	2026-06-03 14:02:26.690577+00	POOL	SELL	0.62	0.58	8	-6	POOL is the largest portfolio position at 18.8% and requires risk management. With +1.4% performance and unknown earnings date, selling 1 share reduces concentration while generating cash. The cash will be redeployed to higher-conviction opportunities aligned with current geopolitical risks (energy) and sector rotation (insurance). This addresses both cash constraint and position sizing discipline.	null	82
83	2026-06-03 14:02:43.719161+00	RILY	SELL	0.65	0.6	12	-8	RILY is currently a stub position at 4.1% of portfolio (below 5% minimum), requiring exit to eliminate monitoring cost. With +27.0% performance, exiting the full position locks in gains and generates cash for higher-conviction opportunities. The position has unknown earnings risk, making full exit the appropriate risk management action.	null	83
84	2026-06-03 14:02:51.308913+00	GRNT	BUY	0.7	0.65	25	-10	GRNT presents a high-conviction energy opportunity aligned with current US-Iran geopolitical tensions. With $919K insider buying by 6 insiders at $5.36, the stock is currently trading at $4.995 (6.8% below insider purchase price), creating an attractive entry point. The company operates in oil & gas exploration with exposure to potential oil price premiums from Middle East tensions. GRNT has a low beta (0.228) and strong insider conviction, making it a defensive energy play with asymmetric upside.	null	84
85	2026-06-08 14:02:59.570181+00	GRNT	SELL	0.9	0.95	0.01	-35	GRNT faces substantial doubt about its ability to continue as a going concern with high debt maturity risk in 2027 and recent auditor change. In the current extreme geopolitical environment with Strait of Hormuz blockade likely to cause oil price volatility and credit market stress, GRNT's high leverage makes it extremely vulnerable. The stock is trading at $4.92, down 2.2% from our cost basis, and the going-concern warning represents an existential risk that violates our risk management principles.	null	85
86	2026-06-08 14:03:13.238877+00	SBLK	SELL	0.92	0.95	0.01	-50	SBLK faces existential risk from the Strait of Hormuz blockade threat. With Iran threatening to completely block this critical oil chokepoint and US-Iran military escalation continuing, shipping routes are at extreme risk. News reports confirm shipping traffic has dropped to 36 ships/week from 130/day pre-war. SBLK's business model depends on global trade routes, and a complete Hormuz blockade would severely impact its operations. The stock is down 2.2% to $26.69 and the geopolitical risk has moved from potential to highly probable.	null	86
87	2026-06-09 14:02:29.752747+00	SU	BUY	0.75	0.7	35	-15	SU is Canada's largest integrated energy company with direct exposure to oil price increases. With US-Iran conflict escalating at the Strait of Hormuz (20% of global oil supply), oil prices are likely to spike. SU has strong fundamentals: $15.4B Q1 revenue, $2.9B operating income, $2.1B net income, and $4.76B EBITDA. Trading at ~4.8x revenue is reasonable for integrated energy. This positions the portfolio for geopolitical tailwinds while maintaining quality.	null	87
88	2026-06-10 14:02:54.432651+00	OBE	BUY	0.75	0.7	26.5	-18.7	OBE is a pure-play Canadian oil producer with strong fundamentals and direct exposure to oil price movements. With Iran-Israel missile exchanges escalating and Strait of Hormuz risk elevated, oil prices have significant upside potential. OBE's current price of $11.07 offers compelling entry point relative to $14.00 target price (26.5% upside) with $9.00 stop loss (18.7% downside). This provides asymmetric risk/reward profile perfectly aligned with our geopolitical energy theme.	null	88
89	2026-06-11 14:02:03.539751+00	GPN	SELL	0.8	0.7	0.01	-20	GPN's Q1 2026 results show catastrophic net income of -$1.8B despite $2.97B revenue, indicating serious accounting or operational issues that invalidate the original thesis. This fundamental deterioration makes the position unacceptable to hold, failing the 'would I buy today' test at current price ($62.65).	null	89
90	2026-06-11 14:02:12.773782+00	VISN	SELL	0.75	0.65	5	-10	VISN's Q1 2026 shows -$1.5B net loss despite $471.8M revenue, suggesting accounting issues. Current price ($12.205) is approaching the updated $13.5 target, and with the thesis weakened and financial concerns, trimming 45% of the position is appropriate risk management.	null	90
91	2026-06-11 14:02:28.829506+00	BUR	SELL	0.85	0.75	0.01	-15	BUR's financials show consistent deterioration with negative operating income (-$53.7M) and net losses in recent quarters. Q4 2025 results show -$53.7M operating income and -$37.5M net income, indicating fundamental issues beyond market sentiment. The original thesis about strong risk-adjusted returns is invalidated by this financial data.	null	91
92	2026-06-15 14:01:47.600148+00	SU	SELL	0.75	0.65	0.01	-7.9	Geopolitical thesis weakened by conflicting Iran peace deal signals (Trump claims deal Sunday but CNBC reports deal in question as Israel strikes Lebanon). Updated thesis has decreased conviction and lowered target ($70 from $75). Current price ($58.55) is very close to new stop-loss ($57.5), making position highly vulnerable. With unknown earnings date (violates 7-day rule) and -7.9% unrealized loss, risk/reward is unfavorable. Full exit frees capital for higher-conviction opportunities.	null	92
93	2026-06-15 14:02:07.283337+00	OBE	SELL	0.8	0.7	0.01	-7.1	Geopolitical thesis significantly weakened by conflicting Iran peace deal signals (Trump claims deal Sunday but CNBC reports deal in question as Israel strikes Lebanon). Updated thesis has decreased conviction and lowered target ($13.5 from $15). With unknown earnings date (violates 7-day rule) and -7.1% unrealized loss, risk/reward is unfavorable. Full exit frees capital for higher-conviction opportunities that meet commission requirements.	null	93
94	2026-06-15 14:02:34.385221+00	MOBI	BUY	0.85	0.75	30	-15	MOBI has massive insider buying ($19.1M by 7 insiders) at $14.99, representing 30% upside from current price of $11.50. This is a strong signal of insider confidence in the company's prospects. As a medical device company, MOBI benefits from the growing healthcare technology sector. A 10-share position ($115) keeps commission drag at 1.74%, well within our 5% threshold.	null	94
95	2026-06-15 14:02:52.43632+00	BETR	BUY	0.8	0.7	25	-12	BETR has massive insider buying ($8.4M by 5 insiders) at $29.46, and is currently trading at $29.89, showing strong insider confidence. The stock is up 12.75% today, indicating positive market sentiment. A 5-share position ($149.45) keeps commission drag at 1.34%, well within our 5% threshold.	null	95
96	2026-06-15 14:03:11.599399+00	SMMT	BUY	0.9	0.75	20	-15	SMMT has massive insider buying ($100.7M by 3 insiders) at $13.13, and is currently trading at $14.01, showing strong insider confidence. The stock is up 0.000016% today, suggesting the market hasn't yet priced in this insider confidence. A 10-share position ($140.10) keeps commission drag at 1.43%, well within our 5% threshold.	null	96
97	2026-06-16 14:01:53.535328+00	OBE	BUY	0.75	0.65	25	-15	OBE is a pure-play Canadian oil producer with strong Q1 2026 operating income ($29.6M) despite net losses due to non-operating expenses. With ongoing Iran tensions, US military action against oil tankers, and UK seizure of Russian shadow tanker, oil supply disruptions are real and continuing. OBE's valuation appears attractive relative to peers, and it would provide direct exposure to oil price upside from continued geopolitical risk premium. The current price of $10.27 is below its 52-week high of $14.59, providing a margin of safety.	null	97
\.


--
-- Data for Name: portfolio_snapshots; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.portfolio_snapshots (id, "timestamp", total_value, cash_balance, positions, daily_pnl, daily_pnl_pct) FROM stdin;
\.


--
-- Data for Name: risk_checks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.risk_checks (id, trade_id, check_name, result, message, details, "timestamp") FROM stdin;
1	1	market_hours	APPROVED	Market is open	null	2026-02-19 18:51:17.08507+00
2	1	daily_trade_limit	APPROVED	Daily trades: 0/10	null	2026-02-19 18:51:17.085074+00
3	1	weekly_trade_limit	APPROVED	Weekly trades: 0/30	null	2026-02-19 18:51:17.085078+00
4	1	position_size	APPROVED	Position size 6.6% within limits	null	2026-02-19 18:51:17.085079+00
5	1	portfolio_concentration	APPROVED	Concentration check passed	null	2026-02-19 18:51:17.08508+00
6	1	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-02-19 18:51:17.085081+00
7	1	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-02-19 18:51:17.085083+00
8	1	account_balance	APPROVED	Sufficient funds ($500.00 available)	null	2026-02-19 18:51:17.085084+00
9	2	market_hours	APPROVED	Market is open	null	2026-02-19 18:51:21.456982+00
10	2	daily_trade_limit	APPROVED	Daily trades: 0/10	null	2026-02-19 18:51:21.456984+00
11	2	weekly_trade_limit	APPROVED	Weekly trades: 0/30	null	2026-02-19 18:51:21.456985+00
12	2	position_size	APPROVED	Position size 11.8% within limits	null	2026-02-19 18:51:21.456986+00
13	2	portfolio_concentration	APPROVED	Concentration check passed	null	2026-02-19 18:51:21.456986+00
14	2	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-02-19 18:51:21.456987+00
15	2	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-02-19 18:51:21.456987+00
16	2	account_balance	APPROVED	Sufficient funds ($466.50 available)	null	2026-02-19 18:51:21.456988+00
17	3	market_hours	APPROVED	Market is open	null	2026-02-19 19:14:37.245925+00
18	3	daily_trade_limit	APPROVED	Daily trades: 0/10	null	2026-02-19 19:14:37.245928+00
19	3	weekly_trade_limit	APPROVED	Weekly trades: 0/30	null	2026-02-19 19:14:37.24593+00
20	3	position_size	APPROVED	Position size 18.5% within limits	null	2026-02-19 19:14:37.245931+00
21	3	portfolio_concentration	APPROVED	Concentration check passed	null	2026-02-19 19:14:37.245932+00
22	3	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-02-19 19:14:37.245932+00
23	3	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-02-19 19:14:37.245933+00
24	3	account_balance	APPROVED	Sufficient funds ($406.83 available)	null	2026-02-19 19:14:37.245934+00
25	4	market_hours	APPROVED	Market is open	null	2026-02-19 19:17:32.272265+00
26	4	daily_trade_limit	APPROVED	Daily trades: 0/10	null	2026-02-19 19:17:32.272267+00
27	4	weekly_trade_limit	APPROVED	Weekly trades: 0/30	null	2026-02-19 19:17:32.27227+00
28	4	position_size	APPROVED	Position size 18.5% within limits	null	2026-02-19 19:17:32.272271+00
29	4	portfolio_concentration	APPROVED	Concentration check passed	null	2026-02-19 19:17:32.272272+00
30	4	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-02-19 19:17:32.272272+00
31	4	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-02-19 19:17:32.272273+00
32	4	account_balance	APPROVED	Sufficient funds ($406.83 available)	null	2026-02-19 19:17:32.272274+00
33	5	market_hours	APPROVED	Market is open	null	2026-02-20 20:02:54.155832+00
34	5	daily_trade_limit	APPROVED	Daily trades: 0/10	null	2026-02-20 20:02:54.155835+00
35	5	weekly_trade_limit	APPROVED	Weekly trades: 1/30	null	2026-02-20 20:02:54.155838+00
36	5	position_size	APPROVED	Position size 17.5% within limits	null	2026-02-20 20:02:54.155839+00
37	5	portfolio_concentration	APPROVED	Concentration check passed	null	2026-02-20 20:02:54.155839+00
38	5	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-02-20 20:02:54.15584+00
39	5	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-02-20 20:02:54.15584+00
40	5	account_balance	APPROVED	Sufficient funds ($202.86 available)	null	2026-02-20 20:02:54.155842+00
41	6	market_hours	APPROVED	Market is open	null	2026-03-12 17:29:06.073236+00
42	6	daily_trade_limit	APPROVED	Daily trades: 0/10	null	2026-03-12 17:29:06.073238+00
43	6	weekly_trade_limit	APPROVED	Weekly trades: 0/30	null	2026-03-12 17:29:06.073241+00
44	6	position_size	APPROVED	Position size 9.6% within limits	null	2026-03-12 17:29:06.073242+00
45	6	portfolio_concentration	APPROVED	Concentration check passed	null	2026-03-12 17:29:06.073242+00
46	6	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-03-12 17:29:06.073243+00
47	6	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-03-12 17:29:06.073244+00
48	6	account_balance	APPROVED	Sufficient funds ($114.87 available)	null	2026-03-12 17:29:06.073245+00
49	7	market_hours	APPROVED	Market is open	null	2026-03-17 14:02:15.246664+00
50	7	daily_trade_limit	APPROVED	Daily trades: 0/10	null	2026-03-17 14:02:15.246667+00
51	7	weekly_trade_limit	APPROVED	Weekly trades: 1/30	null	2026-03-17 14:02:15.24667+00
52	7	position_size	APPROVED	Position size 17.8% within limits	null	2026-03-17 14:02:15.246671+00
53	7	portfolio_concentration	APPROVED	Concentration check passed	null	2026-03-17 14:02:15.246671+00
54	7	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-03-17 14:02:15.246672+00
55	7	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-03-17 14:02:15.246673+00
56	7	account_balance	APPROVED	Sufficient funds ($163.48 available)	null	2026-03-17 14:02:15.246674+00
57	8	market_hours	APPROVED	Market is open	null	2026-03-25 14:01:47.51816+00
58	8	daily_trade_limit	APPROVED	Daily trades: 0/10	null	2026-03-25 14:01:47.518163+00
59	8	weekly_trade_limit	APPROVED	Weekly trades: 0/30	null	2026-03-25 14:01:47.518166+00
60	8	position_size	APPROVED	Position size 8.3% within limits	null	2026-03-25 14:01:47.518167+00
61	8	portfolio_concentration	APPROVED	Concentration check passed	null	2026-03-25 14:01:47.518167+00
62	8	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-03-25 14:01:47.518168+00
63	8	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-03-25 14:01:47.518169+00
64	8	account_balance	APPROVED	Sufficient funds ($280.67 available)	null	2026-03-25 14:01:47.51817+00
65	9	market_hours	APPROVED	Market is open	null	2026-04-06 14:01:15.973269+00
66	9	daily_trade_limit	APPROVED	Daily trades: 0/10	null	2026-04-06 14:01:15.973272+00
67	9	weekly_trade_limit	APPROVED	Weekly trades: 0/30	null	2026-04-06 14:01:15.973275+00
68	9	position_size	APPROVED	Position size 10.3% within limits	null	2026-04-06 14:01:15.973276+00
69	9	portfolio_concentration	APPROVED	Concentration check passed	null	2026-04-06 14:01:15.973276+00
70	9	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-04-06 14:01:15.973277+00
71	9	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-04-06 14:01:15.973278+00
72	9	account_balance	APPROVED	Sufficient funds ($510.67 available)	null	2026-04-06 14:01:15.973279+00
73	10	market_hours	APPROVED	Market is open	null	2026-04-14 14:01:16.40137+00
74	10	daily_trade_limit	APPROVED	Daily trades: 0/10	null	2026-04-14 14:01:16.401372+00
75	10	weekly_trade_limit	APPROVED	Weekly trades: 0/30	null	2026-04-14 14:01:16.401375+00
76	10	position_size	APPROVED	Position size 17.3% within limits	null	2026-04-14 14:01:16.401376+00
77	10	portfolio_concentration	APPROVED	Concentration check passed	null	2026-04-14 14:01:16.401376+00
78	10	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-04-14 14:01:16.401377+00
79	10	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-04-14 14:01:16.401378+00
80	10	account_balance	APPROVED	Sufficient funds ($405.71 available)	null	2026-04-14 14:01:16.401379+00
81	11	market_hours	APPROVED	Market is open	null	2026-04-15 14:01:00.02273+00
82	11	daily_trade_limit	APPROVED	Daily trades: 0/10	null	2026-04-15 14:01:00.022732+00
83	11	weekly_trade_limit	APPROVED	Weekly trades: 1/30	null	2026-04-15 14:01:00.022735+00
84	11	position_size	APPROVED	Position size 2.7% within limits	null	2026-04-15 14:01:00.022736+00
85	11	portfolio_concentration	APPROVED	Concentration check passed	null	2026-04-15 14:01:00.022736+00
86	11	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-04-15 14:01:00.022737+00
87	11	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-04-15 14:01:00.022738+00
88	11	account_balance	APPROVED	Sufficient funds ($220.63 available)	null	2026-04-15 14:01:00.022739+00
89	12	market_hours	APPROVED	Market is open	null	2026-04-16 14:02:05.606323+00
90	12	daily_trade_limit	APPROVED	Daily trades: 0/10	null	2026-04-16 14:02:05.606326+00
91	12	weekly_trade_limit	APPROVED	Weekly trades: 2/30	null	2026-04-16 14:02:05.606326+00
92	12	position_size	APPROVED	Position size 14.9% within limits	null	2026-04-16 14:02:05.606327+00
93	12	portfolio_concentration	APPROVED	Concentration check passed	null	2026-04-16 14:02:05.606328+00
94	12	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-04-16 14:02:05.606328+00
95	12	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-04-16 14:02:05.606329+00
96	12	account_balance	APPROVED	Sufficient funds ($247.44 available)	null	2026-04-16 14:02:05.606329+00
97	13	market_hours	APPROVED	Market is open	null	2026-04-17 14:03:56.348327+00
98	13	daily_trade_limit	APPROVED	Daily trades: 0/10	null	2026-04-17 14:03:56.348329+00
99	13	weekly_trade_limit	APPROVED	Weekly trades: 3/30	null	2026-04-17 14:03:56.34833+00
100	13	position_size	APPROVED	Position size 7.6% within limits	null	2026-04-17 14:03:56.348331+00
101	13	portfolio_concentration	APPROVED	Concentration check passed	null	2026-04-17 14:03:56.348331+00
102	13	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-04-17 14:03:56.348332+00
103	13	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-04-17 14:03:56.348332+00
104	13	account_balance	APPROVED	Sufficient funds ($92.60 available)	null	2026-04-17 14:03:56.348333+00
105	14	market_hours	APPROVED	Market is open	null	2026-04-23 14:01:23.085304+00
106	14	daily_trade_limit	APPROVED	Daily trades: 0/10	null	2026-04-23 14:01:23.085307+00
107	14	weekly_trade_limit	APPROVED	Weekly trades: 2/30	null	2026-04-23 14:01:23.08531+00
108	14	position_size	APPROVED	Position size check skipped (sell reduces concentration)	null	2026-04-23 14:01:23.085311+00
109	14	portfolio_concentration	APPROVED	Concentration check passed	null	2026-04-23 14:01:23.085311+00
110	14	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-04-23 14:01:23.085312+00
111	14	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-04-23 14:01:23.085312+00
112	14	account_balance	APPROVED	Account balance check skipped (sell generates cash)	null	2026-04-23 14:01:23.085313+00
113	15	market_hours	APPROVED	Market is open	null	2026-04-23 14:01:38.249177+00
114	15	daily_trade_limit	APPROVED	Daily trades: 1/10	null	2026-04-23 14:01:38.249179+00
115	15	weekly_trade_limit	APPROVED	Weekly trades: 3/30	null	2026-04-23 14:01:38.24918+00
116	15	position_size	APPROVED	Position size check skipped (sell reduces concentration)	null	2026-04-23 14:01:38.24918+00
117	15	portfolio_concentration	APPROVED	Concentration check passed	null	2026-04-23 14:01:38.249181+00
118	15	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-04-23 14:01:38.249181+00
119	15	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-04-23 14:01:38.249182+00
120	15	account_balance	APPROVED	Account balance check skipped (sell generates cash)	null	2026-04-23 14:01:38.249182+00
121	16	market_hours	APPROVED	Market is open	null	2026-04-23 14:01:51.818996+00
122	16	daily_trade_limit	APPROVED	Daily trades: 2/10	null	2026-04-23 14:01:51.819143+00
123	16	weekly_trade_limit	APPROVED	Weekly trades: 4/30	null	2026-04-23 14:01:51.819145+00
124	16	position_size	APPROVED	Position size 12.2% within limits	null	2026-04-23 14:01:51.819145+00
125	16	portfolio_concentration	APPROVED	Concentration check passed	null	2026-04-23 14:01:51.819146+00
126	16	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-04-23 14:01:51.819147+00
127	16	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-04-23 14:01:51.819147+00
128	16	account_balance	APPROVED	Sufficient funds ($185.80 available)	null	2026-04-23 14:01:51.819148+00
129	17	market_hours	APPROVED	Market is open	null	2026-04-29 14:01:04.76507+00
130	17	daily_trade_limit	APPROVED	Daily trades: 0/10	null	2026-04-29 14:01:04.765072+00
131	17	weekly_trade_limit	APPROVED	Weekly trades: 3/30	null	2026-04-29 14:01:04.765073+00
132	17	position_size	APPROVED	Position size check skipped (sell reduces concentration)	null	2026-04-29 14:01:04.765073+00
133	17	portfolio_concentration	APPROVED	Concentration check passed	null	2026-04-29 14:01:04.765074+00
134	17	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-04-29 14:01:04.765074+00
135	17	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-04-29 14:01:04.765075+00
136	17	account_balance	APPROVED	Account balance check skipped (sell generates cash)	null	2026-04-29 14:01:04.765075+00
137	18	market_hours	APPROVED	Market is open	null	2026-04-29 14:01:24.361007+00
138	18	daily_trade_limit	APPROVED	Daily trades: 1/10	null	2026-04-29 14:01:24.36101+00
139	18	weekly_trade_limit	APPROVED	Weekly trades: 4/30	null	2026-04-29 14:01:24.36101+00
140	18	position_size	APPROVED	Position size check skipped (sell reduces concentration)	null	2026-04-29 14:01:24.361011+00
141	18	portfolio_concentration	APPROVED	Concentration check passed	null	2026-04-29 14:01:24.361011+00
142	18	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-04-29 14:01:24.361012+00
143	18	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-04-29 14:01:24.361013+00
144	18	account_balance	APPROVED	Account balance check skipped (sell generates cash)	null	2026-04-29 14:01:24.361013+00
145	19	market_hours	APPROVED	Market is open	null	2026-04-30 14:01:48.481287+00
146	19	daily_trade_limit	APPROVED	Daily trades: 0/10	null	2026-04-30 14:01:48.481289+00
147	19	weekly_trade_limit	APPROVED	Weekly trades: 3/30	null	2026-04-30 14:01:48.48129+00
148	19	position_size	APPROVED	Position size check skipped (sell reduces concentration)	null	2026-04-30 14:01:48.48129+00
149	19	portfolio_concentration	APPROVED	Concentration check passed	null	2026-04-30 14:01:48.481291+00
150	19	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-04-30 14:01:48.481291+00
151	19	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-04-30 14:01:48.481292+00
152	19	account_balance	APPROVED	Account balance check skipped (sell generates cash)	null	2026-04-30 14:01:48.481292+00
153	20	market_hours	APPROVED	Market is open	null	2026-04-30 14:02:06.475179+00
154	20	daily_trade_limit	APPROVED	Daily trades: 1/10	null	2026-04-30 14:02:06.475182+00
155	20	weekly_trade_limit	APPROVED	Weekly trades: 3/30	null	2026-04-30 14:02:06.475182+00
156	20	position_size	APPROVED	Position size check skipped (sell reduces concentration)	null	2026-04-30 14:02:06.475183+00
157	20	portfolio_concentration	APPROVED	Concentration check passed	null	2026-04-30 14:02:06.475183+00
158	20	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-04-30 14:02:06.475184+00
159	20	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-04-30 14:02:06.475184+00
160	20	account_balance	APPROVED	Account balance check skipped (sell generates cash)	null	2026-04-30 14:02:06.475185+00
161	21	market_hours	APPROVED	Market is open	null	2026-04-30 14:02:25.321283+00
162	21	daily_trade_limit	APPROVED	Daily trades: 2/10	null	2026-04-30 14:02:25.321285+00
163	21	weekly_trade_limit	APPROVED	Weekly trades: 4/30	null	2026-04-30 14:02:25.321286+00
164	21	position_size	APPROVED	Position size 12.0% within limits	null	2026-04-30 14:02:25.321286+00
165	21	portfolio_concentration	APPROVED	Concentration check passed	null	2026-04-30 14:02:25.321287+00
166	21	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-04-30 14:02:25.321287+00
167	21	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-04-30 14:02:25.321288+00
168	21	account_balance	APPROVED	Sufficient funds ($417.19 available)	null	2026-04-30 14:02:25.321288+00
169	22	market_hours	APPROVED	Market is open	null	2026-05-01 14:01:06.889924+00
170	22	daily_trade_limit	APPROVED	Daily trades: 0/10	null	2026-05-01 14:01:06.889933+00
171	22	weekly_trade_limit	APPROVED	Weekly trades: 0/30	null	2026-05-01 14:01:06.889946+00
172	22	position_size	APPROVED	Position size check skipped (sell reduces concentration)	null	2026-05-01 14:01:06.889949+00
173	22	portfolio_concentration	APPROVED	Concentration check passed	null	2026-05-01 14:01:06.88995+00
174	22	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-05-01 14:01:06.889952+00
175	22	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-05-01 14:01:06.889954+00
176	22	account_balance	APPROVED	Account balance check skipped (sell generates cash)	null	2026-05-01 14:01:06.88996+00
177	23	market_hours	APPROVED	Market is open	null	2026-05-01 14:01:26.818372+00
178	23	daily_trade_limit	APPROVED	Daily trades: 1/10	null	2026-05-01 14:01:26.818383+00
179	23	weekly_trade_limit	APPROVED	Weekly trades: 1/30	null	2026-05-01 14:01:26.818386+00
180	23	position_size	APPROVED	Position size 11.7% within limits	null	2026-05-01 14:01:26.818388+00
181	23	portfolio_concentration	APPROVED	Concentration check passed	null	2026-05-01 14:01:26.81839+00
182	23	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-05-01 14:01:26.818392+00
183	23	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-05-01 14:01:26.818394+00
184	23	account_balance	APPROVED	Sufficient funds ($398.02 available)	null	2026-05-01 14:01:26.818396+00
185	24	market_hours	APPROVED	Market is open	null	2026-05-01 14:01:45.806403+00
186	24	daily_trade_limit	APPROVED	Daily trades: 2/10	null	2026-05-01 14:01:45.806413+00
187	24	weekly_trade_limit	APPROVED	Weekly trades: 2/30	null	2026-05-01 14:01:45.806416+00
188	24	position_size	APPROVED	Position size 13.1% within limits	null	2026-05-01 14:01:45.806418+00
189	24	portfolio_concentration	APPROVED	Concentration check passed	null	2026-05-01 14:01:45.80642+00
190	24	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-05-01 14:01:45.806422+00
191	24	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-05-01 14:01:45.806424+00
192	24	account_balance	APPROVED	Sufficient funds ($275.19 available)	null	2026-05-01 14:01:45.806426+00
193	25	market_hours	APPROVED	Market is open	null	2026-05-07 14:02:03.463611+00
194	25	daily_trade_limit	APPROVED	Daily trades: 0/10	null	2026-05-07 14:02:03.46362+00
195	25	weekly_trade_limit	APPROVED	Weekly trades: 3/30	null	2026-05-07 14:02:03.46363+00
196	25	position_size	APPROVED	Position size check skipped (sell reduces concentration)	null	2026-05-07 14:02:03.463633+00
197	25	portfolio_concentration	APPROVED	Concentration check passed	null	2026-05-07 14:02:03.463635+00
198	25	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-05-07 14:02:03.463637+00
199	25	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-05-07 14:02:03.46364+00
200	25	account_balance	APPROVED	Account balance check skipped (sell generates cash)	null	2026-05-07 14:02:03.463644+00
201	26	market_hours	APPROVED	Market is open	null	2026-05-07 14:02:28.475761+00
202	26	daily_trade_limit	APPROVED	Daily trades: 1/10	null	2026-05-07 14:02:28.475768+00
203	26	weekly_trade_limit	APPROVED	Weekly trades: 4/30	null	2026-05-07 14:02:28.475769+00
204	26	position_size	APPROVED	Position size check skipped (sell reduces concentration)	null	2026-05-07 14:02:28.475771+00
205	26	portfolio_concentration	APPROVED	Concentration check passed	null	2026-05-07 14:02:28.475773+00
206	26	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-05-07 14:02:28.475774+00
207	26	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-05-07 14:02:28.475775+00
208	26	account_balance	APPROVED	Account balance check skipped (sell generates cash)	null	2026-05-07 14:02:28.475776+00
209	27	market_hours	APPROVED	Market is open	null	2026-05-08 14:02:26.563548+00
210	27	daily_trade_limit	APPROVED	Daily trades: 0/10	null	2026-05-08 14:02:26.563557+00
211	27	weekly_trade_limit	APPROVED	Weekly trades: 2/30	null	2026-05-08 14:02:26.563559+00
212	27	position_size	APPROVED	Position size check skipped (sell reduces concentration)	null	2026-05-08 14:02:26.56356+00
213	27	portfolio_concentration	APPROVED	Concentration check passed	null	2026-05-08 14:02:26.563562+00
214	27	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-05-08 14:02:26.563563+00
215	27	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-05-08 14:02:26.563564+00
216	27	account_balance	APPROVED	Account balance check skipped (sell generates cash)	null	2026-05-08 14:02:26.563566+00
217	28	market_hours	APPROVED	Market is open	null	2026-05-08 14:02:35.821068+00
218	28	daily_trade_limit	APPROVED	Daily trades: 1/10	null	2026-05-08 14:02:35.82108+00
219	28	weekly_trade_limit	APPROVED	Weekly trades: 3/30	null	2026-05-08 14:02:35.821083+00
220	28	position_size	APPROVED	Position size 6.8% within limits	null	2026-05-08 14:02:35.821086+00
221	28	portfolio_concentration	APPROVED	Concentration check passed	null	2026-05-08 14:02:35.821089+00
222	28	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-05-08 14:02:35.821091+00
223	28	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-05-08 14:02:35.821094+00
224	28	account_balance	APPROVED	Sufficient funds ($517.58 available)	null	2026-05-08 14:02:35.821097+00
225	29	market_hours	APPROVED	Market is open	null	2026-05-13 14:03:25.157161+00
226	29	daily_trade_limit	APPROVED	Daily trades: 0/10	null	2026-05-13 14:03:25.157173+00
227	29	weekly_trade_limit	APPROVED	Weekly trades: 4/30	null	2026-05-13 14:03:25.157175+00
228	29	position_size	APPROVED	Position size 13.5% within limits	null	2026-05-13 14:03:25.157177+00
229	29	portfolio_concentration	APPROVED	Concentration check passed	null	2026-05-13 14:03:25.157179+00
230	29	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-05-13 14:03:25.157181+00
231	29	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-05-13 14:03:25.157183+00
232	29	account_balance	APPROVED	Sufficient funds ($447.95 available)	null	2026-05-13 14:03:25.157185+00
233	30	market_hours	APPROVED	Market is open	null	2026-05-13 14:03:40.532405+00
234	30	daily_trade_limit	APPROVED	Daily trades: 1/10	null	2026-05-13 14:03:40.532418+00
235	30	weekly_trade_limit	APPROVED	Weekly trades: 5/30	null	2026-05-13 14:03:40.532423+00
236	30	position_size	APPROVED	Position size check skipped (sell reduces concentration)	null	2026-05-13 14:03:40.532426+00
237	30	portfolio_concentration	APPROVED	Concentration check passed	null	2026-05-13 14:03:40.53243+00
238	30	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-05-13 14:03:40.532433+00
239	30	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-05-13 14:03:40.532437+00
240	30	account_balance	APPROVED	Account balance check skipped (sell generates cash)	null	2026-05-13 14:03:40.53244+00
241	31	market_hours	APPROVED	Market is open	null	2026-05-14 14:01:40.785986+00
242	31	daily_trade_limit	APPROVED	Daily trades: 0/10	null	2026-05-14 14:01:40.785995+00
243	31	weekly_trade_limit	APPROVED	Weekly trades: 6/30	null	2026-05-14 14:01:40.785997+00
244	31	position_size	APPROVED	Position size check skipped (sell reduces concentration)	null	2026-05-14 14:01:40.785999+00
245	31	portfolio_concentration	APPROVED	Concentration check passed	null	2026-05-14 14:01:40.786001+00
246	31	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-05-14 14:01:40.786002+00
247	31	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-05-14 14:01:40.786004+00
248	31	account_balance	APPROVED	Account balance check skipped (sell generates cash)	null	2026-05-14 14:01:40.786005+00
249	32	market_hours	APPROVED	Market is open	null	2026-05-14 14:01:59.807537+00
250	32	daily_trade_limit	APPROVED	Daily trades: 1/10	null	2026-05-14 14:01:59.807547+00
251	32	weekly_trade_limit	APPROVED	Weekly trades: 7/30	null	2026-05-14 14:01:59.80755+00
252	32	position_size	APPROVED	Position size 11.6% within limits	null	2026-05-14 14:01:59.807552+00
253	32	portfolio_concentration	APPROVED	Concentration check passed	null	2026-05-14 14:01:59.807554+00
254	32	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-05-14 14:01:59.807556+00
255	32	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-05-14 14:01:59.807558+00
256	32	account_balance	APPROVED	Sufficient funds ($444.63 available)	null	2026-05-14 14:01:59.80756+00
257	33	market_hours	APPROVED	Market is open	null	2026-05-14 14:02:14.335864+00
258	33	daily_trade_limit	APPROVED	Daily trades: 1/10	null	2026-05-14 14:02:14.335869+00
259	33	weekly_trade_limit	APPROVED	Weekly trades: 6/30	null	2026-05-14 14:02:14.33587+00
260	33	position_size	APPROVED	Position size 10.9% within limits	null	2026-05-14 14:02:14.335871+00
261	33	portfolio_concentration	APPROVED	Concentration check passed	null	2026-05-14 14:02:14.335871+00
262	33	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-05-14 14:02:14.335872+00
263	33	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-05-14 14:02:14.335873+00
264	33	account_balance	APPROVED	Sufficient funds ($444.63 available)	null	2026-05-14 14:02:14.335874+00
265	34	market_hours	APPROVED	Market is open	null	2026-05-14 14:02:38.274491+00
266	34	daily_trade_limit	APPROVED	Daily trades: 2/10	null	2026-05-14 14:02:38.2745+00
267	34	weekly_trade_limit	APPROVED	Weekly trades: 6/30	null	2026-05-14 14:02:38.274502+00
268	34	position_size	APPROVED	Position size 7.4% within limits	null	2026-05-14 14:02:38.274504+00
269	34	portfolio_concentration	APPROVED	Concentration check passed	null	2026-05-14 14:02:38.274505+00
270	34	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-05-14 14:02:38.274507+00
271	34	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-05-14 14:02:38.274509+00
272	34	account_balance	APPROVED	Sufficient funds ($333.75 available)	null	2026-05-14 14:02:38.27451+00
273	35	market_hours	APPROVED	Market is open	null	2026-05-14 14:02:50.609825+00
274	35	daily_trade_limit	APPROVED	Daily trades: 2/10	null	2026-05-14 14:02:50.609835+00
275	35	weekly_trade_limit	APPROVED	Weekly trades: 6/30	null	2026-05-14 14:02:50.609837+00
276	35	position_size	APPROVED	Position size 6.9% within limits	null	2026-05-14 14:02:50.609839+00
277	35	portfolio_concentration	APPROVED	Concentration check passed	null	2026-05-14 14:02:50.609841+00
278	35	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-05-14 14:02:50.609843+00
279	35	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-05-14 14:02:50.609846+00
280	35	account_balance	APPROVED	Sufficient funds ($333.75 available)	null	2026-05-14 14:02:50.609848+00
281	36	market_hours	APPROVED	Market is open	null	2026-05-14 14:03:27.186877+00
282	36	daily_trade_limit	APPROVED	Daily trades: 3/10	null	2026-05-14 14:03:27.186885+00
283	36	weekly_trade_limit	APPROVED	Weekly trades: 7/30	null	2026-05-14 14:03:27.186887+00
284	36	position_size	APPROVED	Position size 17.0% within limits	null	2026-05-14 14:03:27.186889+00
285	36	portfolio_concentration	APPROVED	Concentration check passed	null	2026-05-14 14:03:27.18689+00
286	36	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-05-14 14:03:27.186892+00
287	36	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-05-14 14:03:27.186894+00
288	36	account_balance	APPROVED	Sufficient funds ($262.10 available)	null	2026-05-14 14:03:27.186895+00
289	37	market_hours	APPROVED	Market is open	null	2026-05-15 14:02:12.447071+00
290	37	daily_trade_limit	APPROVED	Daily trades: 0/10	null	2026-05-15 14:02:12.447079+00
291	37	weekly_trade_limit	APPROVED	Weekly trades: 8/30	null	2026-05-15 14:02:12.447081+00
292	37	position_size	APPROVED	Position size check skipped (sell reduces concentration)	null	2026-05-15 14:02:12.447083+00
293	37	portfolio_concentration	APPROVED	Concentration check passed	null	2026-05-15 14:02:12.447084+00
294	37	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-05-15 14:02:12.447086+00
295	37	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-05-15 14:02:12.447087+00
296	37	account_balance	APPROVED	Account balance check skipped (sell generates cash)	null	2026-05-15 14:02:12.447088+00
297	38	market_hours	APPROVED	Market is open	null	2026-05-15 14:02:22.489107+00
298	38	daily_trade_limit	APPROVED	Daily trades: 1/10	null	2026-05-15 14:02:22.489122+00
299	38	weekly_trade_limit	APPROVED	Weekly trades: 9/30	null	2026-05-15 14:02:22.489125+00
300	38	position_size	APPROVED	Position size 7.8% within limits	null	2026-05-15 14:02:22.489129+00
301	38	portfolio_concentration	APPROVED	Concentration check passed	null	2026-05-15 14:02:22.489132+00
302	38	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-05-15 14:02:22.489135+00
303	38	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-05-15 14:02:22.489139+00
304	38	account_balance	APPROVED	Sufficient funds ($134.20 available)	null	2026-05-15 14:02:22.489142+00
305	39	market_hours	APPROVED	Market is open	null	2026-05-18 14:02:26.448875+00
306	39	daily_trade_limit	APPROVED	Daily trades: 0/10	null	2026-05-18 14:02:26.448885+00
307	39	weekly_trade_limit	APPROVED	Weekly trades: 8/30	null	2026-05-18 14:02:26.448887+00
308	39	position_size	APPROVED	Position size check skipped (sell reduces concentration)	null	2026-05-18 14:02:26.448889+00
309	39	portfolio_concentration	APPROVED	Concentration check passed	null	2026-05-18 14:02:26.448891+00
310	39	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-05-18 14:02:26.448893+00
311	39	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-05-18 14:02:26.448895+00
312	39	account_balance	APPROVED	Account balance check skipped (sell generates cash)	null	2026-05-18 14:02:26.448897+00
313	40	market_hours	APPROVED	Market is open	null	2026-05-18 14:02:35.528019+00
314	40	daily_trade_limit	APPROVED	Daily trades: 1/10	null	2026-05-18 14:02:35.528026+00
315	40	weekly_trade_limit	APPROVED	Weekly trades: 9/30	null	2026-05-18 14:02:35.528028+00
316	40	position_size	APPROVED	Position size 19.9% within limits	null	2026-05-18 14:02:35.528029+00
317	40	portfolio_concentration	APPROVED	Concentration check passed	null	2026-05-18 14:02:35.52803+00
318	40	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-05-18 14:02:35.528032+00
319	40	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-05-18 14:02:35.528033+00
320	40	account_balance	APPROVED	Sufficient funds ($214.74 available)	null	2026-05-18 14:02:35.528034+00
321	41	market_hours	APPROVED	Market is open	null	2026-05-18 14:02:44.813143+00
322	41	daily_trade_limit	APPROVED	Daily trades: 1/10	null	2026-05-18 14:02:44.813158+00
323	41	weekly_trade_limit	APPROVED	Weekly trades: 9/30	null	2026-05-18 14:02:44.813163+00
324	41	position_size	APPROVED	Position size check skipped (sell reduces concentration)	null	2026-05-18 14:02:44.813166+00
325	41	portfolio_concentration	APPROVED	Concentration check passed	null	2026-05-18 14:02:44.813171+00
326	41	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-05-18 14:02:44.813174+00
327	41	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-05-18 14:02:44.813177+00
328	41	account_balance	APPROVED	Account balance check skipped (sell generates cash)	null	2026-05-18 14:02:44.81318+00
329	42	market_hours	APPROVED	Market is open	null	2026-05-18 14:03:10.432976+00
330	42	daily_trade_limit	APPROVED	Daily trades: 2/10	null	2026-05-18 14:03:10.43299+00
331	42	weekly_trade_limit	APPROVED	Weekly trades: 10/30	null	2026-05-18 14:03:10.432993+00
332	42	position_size	APPROVED	Position size 19.7% within limits	null	2026-05-18 14:03:10.432996+00
333	42	portfolio_concentration	APPROVED	Concentration check passed	null	2026-05-18 14:03:10.432999+00
334	42	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-05-18 14:03:10.433002+00
335	42	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-05-18 14:03:10.433005+00
336	42	account_balance	APPROVED	Sufficient funds ($406.23 available)	null	2026-05-18 14:03:10.433009+00
337	43	market_hours	APPROVED	Market is open	null	2026-05-18 14:03:26.015214+00
338	43	daily_trade_limit	APPROVED	Daily trades: 2/10	null	2026-05-18 14:03:26.015225+00
339	43	weekly_trade_limit	APPROVED	Weekly trades: 10/30	null	2026-05-18 14:03:26.015227+00
340	43	position_size	APPROVED	Position size 19.7% within limits	null	2026-05-18 14:03:26.015229+00
341	43	portfolio_concentration	APPROVED	Concentration check passed	null	2026-05-18 14:03:26.015232+00
342	43	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-05-18 14:03:26.015234+00
343	43	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-05-18 14:03:26.015236+00
344	43	account_balance	APPROVED	Sufficient funds ($406.23 available)	null	2026-05-18 14:03:26.015239+00
345	44	market_hours	APPROVED	Market is open	null	2026-05-18 14:03:38.948353+00
346	44	daily_trade_limit	APPROVED	Daily trades: 2/10	null	2026-05-18 14:03:38.948359+00
347	44	weekly_trade_limit	APPROVED	Weekly trades: 10/30	null	2026-05-18 14:03:38.94836+00
348	44	position_size	APPROVED	Position size 17.9% within limits	null	2026-05-18 14:03:38.948361+00
349	44	portfolio_concentration	APPROVED	Concentration check passed	null	2026-05-18 14:03:38.948362+00
350	44	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-05-18 14:03:38.948363+00
351	44	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-05-18 14:03:38.948364+00
352	44	account_balance	APPROVED	Sufficient funds ($406.23 available)	null	2026-05-18 14:03:38.948365+00
353	45	market_hours	APPROVED	Market is open	null	2026-05-18 14:03:58.432977+00
354	45	daily_trade_limit	APPROVED	Daily trades: 3/10	null	2026-05-18 14:03:58.432983+00
355	45	weekly_trade_limit	APPROVED	Weekly trades: 11/30	null	2026-05-18 14:03:58.432984+00
356	45	position_size	APPROVED	Position size 4.6% within limits	null	2026-05-18 14:03:58.432985+00
357	45	portfolio_concentration	APPROVED	Concentration check passed	null	2026-05-18 14:03:58.432985+00
358	45	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-05-18 14:03:58.432986+00
359	45	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-05-18 14:03:58.432987+00
360	45	account_balance	APPROVED	Sufficient funds ($229.25 available)	null	2026-05-18 14:03:58.432988+00
361	46	market_hours	APPROVED	Market is open	null	2026-05-18 14:04:11.362473+00
362	46	daily_trade_limit	APPROVED	Daily trades: 3/10	null	2026-05-18 14:04:11.362481+00
363	46	weekly_trade_limit	APPROVED	Weekly trades: 11/30	null	2026-05-18 14:04:11.362482+00
364	46	position_size	APPROVED	Position size 4.6% within limits	null	2026-05-18 14:04:11.362484+00
365	46	portfolio_concentration	APPROVED	Concentration check passed	null	2026-05-18 14:04:11.362485+00
366	46	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-05-18 14:04:11.362487+00
367	46	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-05-18 14:04:11.362488+00
368	46	account_balance	APPROVED	Sufficient funds ($229.25 available)	null	2026-05-18 14:04:11.36249+00
369	47	market_hours	APPROVED	Market is open	null	2026-05-19 14:03:05.088883+00
370	47	daily_trade_limit	APPROVED	Daily trades: 0/10	null	2026-05-19 14:03:05.088893+00
371	47	weekly_trade_limit	APPROVED	Weekly trades: 11/30	null	2026-05-19 14:03:05.088895+00
372	47	position_size	APPROVED	Position size check skipped (sell reduces concentration)	null	2026-05-19 14:03:05.088897+00
373	47	portfolio_concentration	APPROVED	Concentration check passed	null	2026-05-19 14:03:05.088898+00
374	47	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-05-19 14:03:05.088899+00
375	47	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-05-19 14:03:05.088901+00
376	47	account_balance	APPROVED	Account balance check skipped (sell generates cash)	null	2026-05-19 14:03:05.088902+00
377	48	market_hours	APPROVED	Market is open	null	2026-05-19 14:03:23.026619+00
378	48	daily_trade_limit	APPROVED	Daily trades: 1/10	null	2026-05-19 14:03:23.026627+00
379	48	weekly_trade_limit	APPROVED	Weekly trades: 12/30	null	2026-05-19 14:03:23.026628+00
380	48	position_size	APPROVED	Position size 14.0% within limits	null	2026-05-19 14:03:23.026629+00
381	48	portfolio_concentration	APPROVED	Concentration check passed	null	2026-05-19 14:03:23.02663+00
382	48	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-05-19 14:03:23.026631+00
383	48	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-05-19 14:03:23.026632+00
384	48	account_balance	APPROVED	Sufficient funds ($286.27 available)	null	2026-05-19 14:03:23.026633+00
385	49	market_hours	APPROVED	Market is open	null	2026-05-19 14:03:30.608085+00
386	49	daily_trade_limit	APPROVED	Daily trades: 1/10	null	2026-05-19 14:03:30.608098+00
387	49	weekly_trade_limit	APPROVED	Weekly trades: 12/30	null	2026-05-19 14:03:30.608101+00
388	49	position_size	APPROVED	Position size 9.4% within limits	null	2026-05-19 14:03:30.608103+00
389	49	portfolio_concentration	APPROVED	Concentration check passed	null	2026-05-19 14:03:30.608105+00
390	49	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-05-19 14:03:30.608107+00
391	49	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-05-19 14:03:30.608109+00
392	49	account_balance	APPROVED	Sufficient funds ($286.27 available)	null	2026-05-19 14:03:30.608111+00
393	50	market_hours	APPROVED	Market is open	null	2026-05-19 14:03:55.026989+00
394	50	daily_trade_limit	APPROVED	Daily trades: 2/10	null	2026-05-19 14:03:55.027+00
395	50	weekly_trade_limit	APPROVED	Weekly trades: 13/30	null	2026-05-19 14:03:55.027002+00
396	50	position_size	APPROVED	Position size check skipped (sell reduces concentration)	null	2026-05-19 14:03:55.027003+00
397	50	portfolio_concentration	APPROVED	Concentration check passed	null	2026-05-19 14:03:55.027004+00
398	50	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-05-19 14:03:55.027006+00
399	50	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-05-19 14:03:55.027007+00
400	50	account_balance	APPROVED	Account balance check skipped (sell generates cash)	null	2026-05-19 14:03:55.027008+00
401	51	market_hours	APPROVED	Market is open	null	2026-05-19 14:04:10.133078+00
402	51	daily_trade_limit	APPROVED	Daily trades: 3/10	null	2026-05-19 14:04:10.133092+00
403	51	weekly_trade_limit	APPROVED	Weekly trades: 14/30	null	2026-05-19 14:04:10.133096+00
404	51	position_size	APPROVED	Position size 19.6% within limits	null	2026-05-19 14:04:10.133099+00
405	51	portfolio_concentration	APPROVED	Concentration check passed	null	2026-05-19 14:04:10.133103+00
406	51	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-05-19 14:04:10.133106+00
407	51	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-05-19 14:04:10.13311+00
408	51	account_balance	APPROVED	Sufficient funds ($262.65 available)	null	2026-05-19 14:04:10.133113+00
409	52	market_hours	APPROVED	Market is open	null	2026-05-19 14:04:24.094503+00
410	52	daily_trade_limit	APPROVED	Daily trades: 3/10	null	2026-05-19 14:04:24.09451+00
411	52	weekly_trade_limit	APPROVED	Weekly trades: 14/30	null	2026-05-19 14:04:24.094512+00
412	52	position_size	APPROVED	Position size 19.7% within limits	null	2026-05-19 14:04:24.094513+00
413	52	portfolio_concentration	APPROVED	Concentration check passed	null	2026-05-19 14:04:24.094514+00
414	52	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-05-19 14:04:24.094515+00
415	52	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-05-19 14:04:24.094516+00
416	52	account_balance	APPROVED	Sufficient funds ($262.65 available)	null	2026-05-19 14:04:24.094517+00
417	53	market_hours	APPROVED	Market is open	null	2026-05-20 14:01:16.989569+00
418	53	daily_trade_limit	APPROVED	Daily trades: 0/10	null	2026-05-20 14:01:16.98958+00
419	53	weekly_trade_limit	APPROVED	Weekly trades: 14/30	null	2026-05-20 14:01:16.989582+00
420	53	position_size	APPROVED	Position size 19.9% within limits	null	2026-05-20 14:01:16.989584+00
421	53	portfolio_concentration	APPROVED	Concentration check passed	null	2026-05-20 14:01:16.989587+00
422	53	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-05-20 14:01:16.989589+00
423	53	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-05-20 14:01:16.989591+00
424	53	account_balance	APPROVED	Sufficient funds ($262.65 available)	null	2026-05-20 14:01:16.989593+00
425	54	market_hours	APPROVED	Market is open	null	2026-05-20 14:01:31.205054+00
426	54	daily_trade_limit	APPROVED	Daily trades: 0/10	null	2026-05-20 14:01:31.205059+00
427	54	weekly_trade_limit	APPROVED	Weekly trades: 14/30	null	2026-05-20 14:01:31.205061+00
428	54	position_size	APPROVED	Position size 2.6% within limits	null	2026-05-20 14:01:31.205062+00
429	54	portfolio_concentration	APPROVED	Concentration check passed	null	2026-05-20 14:01:31.205064+00
430	54	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-05-20 14:01:31.205065+00
431	54	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-05-20 14:01:31.205067+00
432	54	account_balance	APPROVED	Sufficient funds ($262.65 available)	null	2026-05-20 14:01:31.205068+00
433	55	market_hours	APPROVED	Market is open	null	2026-05-20 14:01:53.520484+00
434	55	daily_trade_limit	APPROVED	Daily trades: 1/10	null	2026-05-20 14:01:53.520493+00
435	55	weekly_trade_limit	APPROVED	Weekly trades: 15/30	null	2026-05-20 14:01:53.520495+00
436	55	position_size	APPROVED	Position size 10.0% within limits	null	2026-05-20 14:01:53.520496+00
437	55	portfolio_concentration	APPROVED	Concentration check passed	null	2026-05-20 14:01:53.520497+00
438	55	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-05-20 14:01:53.520498+00
439	55	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-05-20 14:01:53.5205+00
440	55	account_balance	APPROVED	Sufficient funds ($236.63 available)	null	2026-05-20 14:01:53.520501+00
441	56	market_hours	APPROVED	Market is open	null	2026-05-20 14:02:09.191108+00
442	56	daily_trade_limit	APPROVED	Daily trades: 1/10	null	2026-05-20 14:02:09.191117+00
443	56	weekly_trade_limit	APPROVED	Weekly trades: 15/30	null	2026-05-20 14:02:09.191118+00
444	56	position_size	APPROVED	Position size 7.1% within limits	null	2026-05-20 14:02:09.19112+00
445	56	portfolio_concentration	APPROVED	Concentration check passed	null	2026-05-20 14:02:09.191121+00
446	56	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-05-20 14:02:09.191122+00
447	56	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-05-20 14:02:09.191123+00
448	56	account_balance	APPROVED	Sufficient funds ($236.63 available)	null	2026-05-20 14:02:09.191124+00
449	57	market_hours	APPROVED	Market is open	null	2026-05-20 14:03:10.139531+00
450	57	daily_trade_limit	APPROVED	Daily trades: 2/10	null	2026-05-20 14:03:10.139541+00
451	57	weekly_trade_limit	APPROVED	Weekly trades: 16/30	null	2026-05-20 14:03:10.139543+00
452	57	position_size	APPROVED	Position size 14.8% within limits	null	2026-05-20 14:03:10.139546+00
453	57	portfolio_concentration	APPROVED	Concentration check passed	null	2026-05-20 14:03:10.139549+00
454	57	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-05-20 14:03:10.139551+00
455	57	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-05-20 14:03:10.139553+00
456	57	account_balance	APPROVED	Sufficient funds ($167.28 available)	null	2026-05-20 14:03:10.139555+00
457	58	market_hours	APPROVED	Market is open	null	2026-05-21 16:04:37.936366+00
458	58	daily_trade_limit	APPROVED	Daily trades: 0/10	null	2026-05-21 16:04:37.936376+00
459	58	weekly_trade_limit	APPROVED	Weekly trades: 11/30	null	2026-05-21 16:04:37.936378+00
460	58	position_size	APPROVED	Position size check skipped (sell reduces concentration)	null	2026-05-21 16:04:37.936381+00
461	58	portfolio_concentration	APPROVED	Concentration check passed	null	2026-05-21 16:04:37.936384+00
462	58	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-05-21 16:04:37.936388+00
463	58	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-05-21 16:04:37.936391+00
464	58	account_balance	APPROVED	Account balance check skipped (sell generates cash)	null	2026-05-21 16:04:37.936395+00
465	59	market_hours	APPROVED	Market is open	null	2026-05-21 16:05:14.816703+00
466	59	daily_trade_limit	APPROVED	Daily trades: 1/10	null	2026-05-21 16:05:14.816711+00
467	59	weekly_trade_limit	APPROVED	Weekly trades: 12/30	null	2026-05-21 16:05:14.816712+00
468	59	position_size	APPROVED	Position size check skipped (sell reduces concentration)	null	2026-05-21 16:05:14.816713+00
469	59	portfolio_concentration	APPROVED	Concentration check passed	null	2026-05-21 16:05:14.816714+00
470	59	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-05-21 16:05:14.816716+00
471	59	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-05-21 16:05:14.816717+00
472	59	account_balance	APPROVED	Account balance check skipped (sell generates cash)	null	2026-05-21 16:05:14.816718+00
473	60	market_hours	APPROVED	Market is open	null	2026-05-25 14:01:22.796685+00
474	60	daily_trade_limit	APPROVED	Daily trades: 0/10	null	2026-05-25 14:01:22.796693+00
475	60	weekly_trade_limit	APPROVED	Weekly trades: 11/30	null	2026-05-25 14:01:22.796694+00
476	60	position_size	APPROVED	Position size check skipped (sell reduces concentration)	null	2026-05-25 14:01:22.796696+00
477	60	portfolio_concentration	APPROVED	Concentration check passed	null	2026-05-25 14:01:22.796697+00
478	60	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-05-25 14:01:22.796698+00
479	60	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-05-25 14:01:22.796699+00
480	60	account_balance	APPROVED	Account balance check skipped (sell generates cash)	null	2026-05-25 14:01:22.7967+00
481	61	market_hours	APPROVED	Market is open	null	2026-05-25 14:01:49.686521+00
482	61	daily_trade_limit	APPROVED	Daily trades: 0/10	null	2026-05-25 14:01:49.686531+00
483	61	weekly_trade_limit	APPROVED	Weekly trades: 11/30	null	2026-05-25 14:01:49.686534+00
484	61	position_size	APPROVED	Position size check skipped (sell reduces concentration)	null	2026-05-25 14:01:49.686538+00
485	61	portfolio_concentration	APPROVED	Concentration check passed	null	2026-05-25 14:01:49.68654+00
486	61	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-05-25 14:01:49.686542+00
487	61	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-05-25 14:01:49.686544+00
488	61	account_balance	APPROVED	Account balance check skipped (sell generates cash)	null	2026-05-25 14:01:49.686545+00
489	62	market_hours	APPROVED	Market is open	null	2026-05-25 14:02:12.783809+00
490	62	daily_trade_limit	APPROVED	Daily trades: 0/10	null	2026-05-25 14:02:12.783816+00
491	62	weekly_trade_limit	APPROVED	Weekly trades: 11/30	null	2026-05-25 14:02:12.783818+00
492	62	position_size	APPROVED	Position size check skipped (sell reduces concentration)	null	2026-05-25 14:02:12.783819+00
493	62	portfolio_concentration	APPROVED	Concentration check passed	null	2026-05-25 14:02:12.783821+00
494	62	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-05-25 14:02:12.783822+00
495	62	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-05-25 14:02:12.783823+00
496	62	account_balance	APPROVED	Account balance check skipped (sell generates cash)	null	2026-05-25 14:02:12.783825+00
497	63	market_hours	APPROVED	Market is open	null	2026-05-26 14:01:51.714401+00
498	63	daily_trade_limit	APPROVED	Daily trades: 0/10	null	2026-05-26 14:01:51.714417+00
499	63	weekly_trade_limit	APPROVED	Weekly trades: 8/30	null	2026-05-26 14:01:51.714422+00
500	63	position_size	APPROVED	Position size check skipped (sell reduces concentration)	null	2026-05-26 14:01:51.714425+00
501	63	portfolio_concentration	APPROVED	Concentration check passed	null	2026-05-26 14:01:51.714428+00
502	63	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-05-26 14:01:51.714432+00
503	63	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-05-26 14:01:51.714435+00
504	63	account_balance	APPROVED	Account balance check skipped (sell generates cash)	null	2026-05-26 14:01:51.714439+00
505	64	market_hours	APPROVED	Market is open	null	2026-05-26 14:02:00.641655+00
506	64	daily_trade_limit	APPROVED	Daily trades: 0/10	null	2026-05-26 14:02:00.641663+00
507	64	weekly_trade_limit	APPROVED	Weekly trades: 8/30	null	2026-05-26 14:02:00.641665+00
508	64	position_size	APPROVED	Position size check skipped (sell reduces concentration)	null	2026-05-26 14:02:00.641667+00
509	64	portfolio_concentration	APPROVED	Concentration check passed	null	2026-05-26 14:02:00.641668+00
510	64	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-05-26 14:02:00.64167+00
511	64	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-05-26 14:02:00.641671+00
512	64	account_balance	APPROVED	Account balance check skipped (sell generates cash)	null	2026-05-26 14:02:00.641673+00
513	65	market_hours	APPROVED	Market is open	null	2026-05-26 14:02:08.122426+00
514	65	daily_trade_limit	APPROVED	Daily trades: 1/10	null	2026-05-26 14:02:08.12244+00
515	65	weekly_trade_limit	APPROVED	Weekly trades: 9/30	null	2026-05-26 14:02:08.122444+00
516	65	position_size	APPROVED	Position size check skipped (sell reduces concentration)	null	2026-05-26 14:02:08.122448+00
517	65	portfolio_concentration	APPROVED	Concentration check passed	null	2026-05-26 14:02:08.12245+00
518	65	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-05-26 14:02:08.122454+00
519	65	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-05-26 14:02:08.122458+00
520	65	account_balance	APPROVED	Account balance check skipped (sell generates cash)	null	2026-05-26 14:02:08.122461+00
521	66	market_hours	APPROVED	Market is open	null	2026-05-26 14:02:15.722086+00
522	66	daily_trade_limit	APPROVED	Daily trades: 2/10	null	2026-05-26 14:02:15.722099+00
523	66	weekly_trade_limit	APPROVED	Weekly trades: 10/30	null	2026-05-26 14:02:15.722103+00
524	66	position_size	APPROVED	Position size 19.4% within limits	null	2026-05-26 14:02:15.722106+00
525	66	portfolio_concentration	APPROVED	Concentration check passed	null	2026-05-26 14:02:15.72211+00
526	66	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-05-26 14:02:15.722114+00
527	66	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-05-26 14:02:15.722118+00
528	66	account_balance	APPROVED	Sufficient funds ($391.72 available)	null	2026-05-26 14:02:15.722122+00
529	67	market_hours	APPROVED	Market is open	null	2026-05-26 14:02:40.288494+00
530	67	daily_trade_limit	APPROVED	Daily trades: 3/10	null	2026-05-26 14:02:40.288511+00
531	67	weekly_trade_limit	APPROVED	Weekly trades: 11/30	null	2026-05-26 14:02:40.288514+00
532	67	position_size	APPROVED	Position size 18.4% within limits	null	2026-05-26 14:02:40.288517+00
533	67	portfolio_concentration	APPROVED	Concentration check passed	null	2026-05-26 14:02:40.28852+00
534	67	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-05-26 14:02:40.288523+00
535	67	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-05-26 14:02:40.288527+00
536	67	account_balance	APPROVED	Sufficient funds ($200.68 available)	null	2026-05-26 14:02:40.28853+00
537	68	market_hours	APPROVED	Market is open	null	2026-05-27 14:02:12.842603+00
538	68	daily_trade_limit	APPROVED	Daily trades: 0/10	null	2026-05-27 14:02:12.842618+00
539	68	weekly_trade_limit	APPROVED	Weekly trades: 6/30	null	2026-05-27 14:02:12.842621+00
540	68	position_size	APPROVED	Position size 15.0% within limits	null	2026-05-27 14:02:12.842625+00
541	68	portfolio_concentration	APPROVED	Concentration check passed	null	2026-05-27 14:02:12.842627+00
542	68	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-05-27 14:02:12.84263+00
543	68	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-05-27 14:02:12.842633+00
544	68	account_balance	APPROVED	Sufficient funds ($200.67 available)	null	2026-05-27 14:02:12.842636+00
545	69	market_hours	APPROVED	Market is open	null	2026-05-27 14:03:33.512028+00
546	69	daily_trade_limit	APPROVED	Daily trades: 1/10	null	2026-05-27 14:03:33.512035+00
547	69	weekly_trade_limit	APPROVED	Weekly trades: 6/30	null	2026-05-27 14:03:33.512036+00
548	69	position_size	APPROVED	Position size 4.5% within limits	null	2026-05-27 14:03:33.512037+00
549	69	portfolio_concentration	APPROVED	Concentration check passed	null	2026-05-27 14:03:33.512039+00
550	69	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-05-27 14:03:33.51204+00
551	69	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-05-27 14:03:33.512041+00
552	69	account_balance	APPROVED	Sufficient funds ($51.93 available)	null	2026-05-27 14:03:33.512042+00
553	70	market_hours	APPROVED	Market is open	null	2026-05-28 14:02:50.088646+00
554	70	daily_trade_limit	APPROVED	Daily trades: 0/10	null	2026-05-28 14:02:50.088661+00
555	70	weekly_trade_limit	APPROVED	Weekly trades: 7/30	null	2026-05-28 14:02:50.088665+00
556	70	position_size	APPROVED	Position size check skipped (sell reduces concentration)	null	2026-05-28 14:02:50.088668+00
557	70	portfolio_concentration	APPROVED	Concentration check passed	null	2026-05-28 14:02:50.088671+00
558	70	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-05-28 14:02:50.088674+00
559	70	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-05-28 14:02:50.088677+00
560	70	account_balance	APPROVED	Account balance check skipped (sell generates cash)	null	2026-05-28 14:02:50.088681+00
561	71	market_hours	APPROVED	Market is open	null	2026-05-28 14:03:03.513753+00
562	71	daily_trade_limit	APPROVED	Daily trades: 1/10	null	2026-05-28 14:03:03.513762+00
563	71	weekly_trade_limit	APPROVED	Weekly trades: 8/30	null	2026-05-28 14:03:03.513763+00
564	71	position_size	APPROVED	Position size check skipped (sell reduces concentration)	null	2026-05-28 14:03:03.513765+00
565	71	portfolio_concentration	APPROVED	Concentration check passed	null	2026-05-28 14:03:03.513766+00
566	71	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-05-28 14:03:03.513767+00
567	71	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-05-28 14:03:03.513768+00
568	71	account_balance	APPROVED	Account balance check skipped (sell generates cash)	null	2026-05-28 14:03:03.513769+00
569	72	market_hours	APPROVED	Market is open	null	2026-05-28 14:03:29.553011+00
570	72	daily_trade_limit	APPROVED	Daily trades: 2/10	null	2026-05-28 14:03:29.553024+00
571	72	weekly_trade_limit	APPROVED	Weekly trades: 9/30	null	2026-05-28 14:03:29.553027+00
572	72	position_size	APPROVED	Position size check skipped (sell reduces concentration)	null	2026-05-28 14:03:29.553031+00
573	72	portfolio_concentration	APPROVED	Concentration check passed	null	2026-05-28 14:03:29.553034+00
574	72	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-05-28 14:03:29.553036+00
575	72	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-05-28 14:03:29.553039+00
576	72	account_balance	APPROVED	Account balance check skipped (sell generates cash)	null	2026-05-28 14:03:29.553043+00
577	73	market_hours	APPROVED	Market is open	null	2026-05-28 14:03:43.609212+00
578	73	daily_trade_limit	APPROVED	Daily trades: 3/10	null	2026-05-28 14:03:43.609226+00
579	73	weekly_trade_limit	APPROVED	Weekly trades: 10/30	null	2026-05-28 14:03:43.60923+00
580	73	position_size	APPROVED	Position size 17.9% within limits	null	2026-05-28 14:03:43.609233+00
581	73	portfolio_concentration	APPROVED	Concentration check passed	null	2026-05-28 14:03:43.609237+00
582	73	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-05-28 14:03:43.60924+00
583	73	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-05-28 14:03:43.609243+00
584	73	account_balance	APPROVED	Sufficient funds ($226.26 available)	null	2026-05-28 14:03:43.609246+00
585	74	market_hours	APPROVED	Market is open	null	2026-05-29 14:02:38.037527+00
586	74	daily_trade_limit	APPROVED	Daily trades: 0/10	null	2026-05-29 14:02:38.037533+00
587	74	weekly_trade_limit	APPROVED	Weekly trades: 9/30	null	2026-05-29 14:02:38.037535+00
588	74	position_size	APPROVED	Position size check skipped (sell reduces concentration)	null	2026-05-29 14:02:38.037537+00
589	74	portfolio_concentration	APPROVED	Concentration check passed	null	2026-05-29 14:02:38.037538+00
590	74	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-05-29 14:02:38.03754+00
591	74	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-05-29 14:02:38.037541+00
592	74	account_balance	APPROVED	Account balance check skipped (sell generates cash)	null	2026-05-29 14:02:38.037543+00
593	75	market_hours	APPROVED	Market is open	null	2026-05-29 14:03:09.659317+00
594	75	daily_trade_limit	APPROVED	Daily trades: 1/10	null	2026-05-29 14:03:09.659326+00
595	75	weekly_trade_limit	APPROVED	Weekly trades: 10/30	null	2026-05-29 14:03:09.659328+00
596	75	position_size	APPROVED	Position size check skipped (sell reduces concentration)	null	2026-05-29 14:03:09.65933+00
597	75	portfolio_concentration	APPROVED	Concentration check passed	null	2026-05-29 14:03:09.659332+00
598	75	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-05-29 14:03:09.659334+00
599	75	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-05-29 14:03:09.659336+00
600	75	account_balance	APPROVED	Account balance check skipped (sell generates cash)	null	2026-05-29 14:03:09.659338+00
601	76	market_hours	APPROVED	Market is open	null	2026-05-29 14:03:45.570797+00
602	76	daily_trade_limit	APPROVED	Daily trades: 2/10	null	2026-05-29 14:03:45.570804+00
603	76	weekly_trade_limit	APPROVED	Weekly trades: 11/30	null	2026-05-29 14:03:45.570806+00
604	76	position_size	APPROVED	Position size 8.1% within limits	null	2026-05-29 14:03:45.570807+00
605	76	portfolio_concentration	APPROVED	Concentration check passed	null	2026-05-29 14:03:45.570808+00
606	76	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-05-29 14:03:45.57081+00
607	76	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-05-29 14:03:45.570811+00
608	76	account_balance	APPROVED	Sufficient funds ($116.15 available)	null	2026-05-29 14:03:45.570812+00
609	77	market_hours	APPROVED	Market is open	null	2026-06-02 14:02:52.265961+00
610	77	daily_trade_limit	APPROVED	Daily trades: 0/10	null	2026-06-02 14:02:52.265971+00
611	77	weekly_trade_limit	APPROVED	Weekly trades: 9/30	null	2026-06-02 14:02:52.265973+00
612	77	position_size	APPROVED	Position size check skipped (sell reduces concentration)	null	2026-06-02 14:02:52.265974+00
613	77	portfolio_concentration	APPROVED	Concentration check passed	null	2026-06-02 14:02:52.265976+00
614	77	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-06-02 14:02:52.265978+00
615	77	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-06-02 14:02:52.26598+00
616	77	account_balance	APPROVED	Account balance check skipped (sell generates cash)	null	2026-06-02 14:02:52.265982+00
617	78	market_hours	APPROVED	Market is open	null	2026-06-02 14:03:00.629287+00
618	78	daily_trade_limit	APPROVED	Daily trades: 1/10	null	2026-06-02 14:03:00.629294+00
619	78	weekly_trade_limit	APPROVED	Weekly trades: 10/30	null	2026-06-02 14:03:00.629296+00
620	78	position_size	APPROVED	Position size check skipped (sell reduces concentration)	null	2026-06-02 14:03:00.629297+00
621	78	portfolio_concentration	APPROVED	Concentration check passed	null	2026-06-02 14:03:00.629299+00
622	78	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-06-02 14:03:00.6293+00
623	78	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-06-02 14:03:00.629302+00
624	78	account_balance	APPROVED	Account balance check skipped (sell generates cash)	null	2026-06-02 14:03:00.629303+00
625	79	market_hours	APPROVED	Market is open	null	2026-06-02 14:03:08.565427+00
626	79	daily_trade_limit	APPROVED	Daily trades: 2/10	null	2026-06-02 14:03:08.565436+00
627	79	weekly_trade_limit	APPROVED	Weekly trades: 11/30	null	2026-06-02 14:03:08.565437+00
628	79	position_size	APPROVED	Position size check skipped (sell reduces concentration)	null	2026-06-02 14:03:08.565439+00
629	79	portfolio_concentration	APPROVED	Concentration check passed	null	2026-06-02 14:03:08.56544+00
630	79	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-06-02 14:03:08.565442+00
631	79	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-06-02 14:03:08.565443+00
632	79	account_balance	APPROVED	Account balance check skipped (sell generates cash)	null	2026-06-02 14:03:08.565444+00
633	80	market_hours	APPROVED	Market is open	null	2026-06-03 14:01:50.057429+00
634	80	daily_trade_limit	APPROVED	Daily trades: 0/10	null	2026-06-03 14:01:50.057441+00
635	80	weekly_trade_limit	APPROVED	Weekly trades: 12/30	null	2026-06-03 14:01:50.057444+00
636	80	position_size	APPROVED	Position size 10.9% within limits	null	2026-06-03 14:01:50.057446+00
637	80	portfolio_concentration	APPROVED	Concentration check passed	null	2026-06-03 14:01:50.057449+00
638	80	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-06-03 14:01:50.057452+00
639	80	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-06-03 14:01:50.057455+00
640	80	account_balance	APPROVED	Sufficient funds ($130.57 available)	null	2026-06-03 14:01:50.057458+00
641	81	market_hours	APPROVED	Market is open	null	2026-06-03 14:02:18.005655+00
642	81	daily_trade_limit	APPROVED	Daily trades: 1/10	null	2026-06-03 14:02:18.005662+00
643	81	weekly_trade_limit	APPROVED	Weekly trades: 12/30	null	2026-06-03 14:02:18.005663+00
644	81	position_size	APPROVED	Position size check skipped (sell reduces concentration)	null	2026-06-03 14:02:18.005664+00
645	81	portfolio_concentration	APPROVED	Concentration check passed	null	2026-06-03 14:02:18.005665+00
646	81	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-06-03 14:02:18.005666+00
647	81	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-06-03 14:02:18.005667+00
648	81	account_balance	APPROVED	Account balance check skipped (sell generates cash)	null	2026-06-03 14:02:18.005668+00
649	82	market_hours	APPROVED	Market is open	null	2026-06-03 14:02:26.684154+00
650	82	daily_trade_limit	APPROVED	Daily trades: 2/10	null	2026-06-03 14:02:26.684161+00
651	82	weekly_trade_limit	APPROVED	Weekly trades: 13/30	null	2026-06-03 14:02:26.684163+00
652	82	position_size	APPROVED	Position size check skipped (sell reduces concentration)	null	2026-06-03 14:02:26.684164+00
653	82	portfolio_concentration	APPROVED	Concentration check passed	null	2026-06-03 14:02:26.684165+00
654	82	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-06-03 14:02:26.684167+00
655	82	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-06-03 14:02:26.684168+00
656	82	account_balance	APPROVED	Account balance check skipped (sell generates cash)	null	2026-06-03 14:02:26.684169+00
657	83	market_hours	APPROVED	Market is open	null	2026-06-03 14:02:43.713989+00
658	83	daily_trade_limit	APPROVED	Daily trades: 3/10	null	2026-06-03 14:02:43.713997+00
659	83	weekly_trade_limit	APPROVED	Weekly trades: 14/30	null	2026-06-03 14:02:43.713998+00
660	83	position_size	APPROVED	Position size check skipped (sell reduces concentration)	null	2026-06-03 14:02:43.713999+00
661	83	portfolio_concentration	APPROVED	Concentration check passed	null	2026-06-03 14:02:43.714+00
662	83	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-06-03 14:02:43.714002+00
663	83	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-06-03 14:02:43.714003+00
664	83	account_balance	APPROVED	Account balance check skipped (sell generates cash)	null	2026-06-03 14:02:43.714004+00
665	84	market_hours	APPROVED	Market is open	null	2026-06-03 14:02:51.302979+00
666	84	daily_trade_limit	APPROVED	Daily trades: 4/10	null	2026-06-03 14:02:51.302989+00
667	84	weekly_trade_limit	APPROVED	Weekly trades: 15/30	null	2026-06-03 14:02:51.302991+00
668	84	position_size	APPROVED	Position size 19.9% within limits	null	2026-06-03 14:02:51.302992+00
669	84	portfolio_concentration	APPROVED	Concentration check passed	null	2026-06-03 14:02:51.302994+00
670	84	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-06-03 14:02:51.302996+00
671	84	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-06-03 14:02:51.302997+00
672	84	account_balance	APPROVED	Sufficient funds ($282.20 available)	null	2026-06-03 14:02:51.302999+00
673	85	market_hours	APPROVED	Market is open	null	2026-06-08 14:02:59.5619+00
674	85	daily_trade_limit	APPROVED	Daily trades: 0/10	null	2026-06-08 14:02:59.561911+00
675	85	weekly_trade_limit	APPROVED	Weekly trades: 8/30	null	2026-06-08 14:02:59.561914+00
676	85	position_size	APPROVED	Position size check skipped (sell reduces concentration)	null	2026-06-08 14:02:59.561916+00
677	85	portfolio_concentration	APPROVED	Concentration check passed	null	2026-06-08 14:02:59.561919+00
678	85	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-06-08 14:02:59.561921+00
679	85	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-06-08 14:02:59.561923+00
680	85	account_balance	APPROVED	Account balance check skipped (sell generates cash)	null	2026-06-08 14:02:59.561925+00
681	86	market_hours	APPROVED	Market is open	null	2026-06-08 14:03:13.230375+00
682	86	daily_trade_limit	APPROVED	Daily trades: 1/10	null	2026-06-08 14:03:13.230386+00
683	86	weekly_trade_limit	APPROVED	Weekly trades: 9/30	null	2026-06-08 14:03:13.230388+00
684	86	position_size	APPROVED	Position size check skipped (sell reduces concentration)	null	2026-06-08 14:03:13.23039+00
685	86	portfolio_concentration	APPROVED	Concentration check passed	null	2026-06-08 14:03:13.230393+00
686	86	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-06-08 14:03:13.230395+00
687	86	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-06-08 14:03:13.230397+00
688	86	account_balance	APPROVED	Account balance check skipped (sell generates cash)	null	2026-06-08 14:03:13.230399+00
689	87	market_hours	APPROVED	Market is open	null	2026-06-09 14:02:29.742615+00
690	87	daily_trade_limit	APPROVED	Daily trades: 0/10	null	2026-06-09 14:02:29.742628+00
691	87	weekly_trade_limit	APPROVED	Weekly trades: 10/30	null	2026-06-09 14:02:29.742632+00
692	87	position_size	APPROVED	Position size 6.7% within limits	null	2026-06-09 14:02:29.742636+00
693	87	portfolio_concentration	APPROVED	Concentration check passed	null	2026-06-09 14:02:29.74264+00
694	87	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-06-09 14:02:29.742644+00
695	87	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-06-09 14:02:29.742648+00
696	87	account_balance	APPROVED	Sufficient funds ($409.87 available)	null	2026-06-09 14:02:29.742652+00
697	88	market_hours	APPROVED	Market is open	null	2026-06-10 14:02:54.42636+00
698	88	daily_trade_limit	APPROVED	Daily trades: 0/10	null	2026-06-10 14:02:54.426369+00
699	88	weekly_trade_limit	APPROVED	Weekly trades: 3/30	null	2026-06-10 14:02:54.42637+00
700	88	position_size	APPROVED	Position size 9.6% within limits	null	2026-06-10 14:02:54.426371+00
701	88	portfolio_concentration	APPROVED	Concentration check passed	null	2026-06-10 14:02:54.426373+00
702	88	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-06-10 14:02:54.426374+00
703	88	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-06-10 14:02:54.426376+00
704	88	account_balance	APPROVED	Sufficient funds ($347.41 available)	null	2026-06-10 14:02:54.426378+00
705	89	market_hours	APPROVED	Market is open	null	2026-06-11 14:02:03.531552+00
706	89	daily_trade_limit	APPROVED	Daily trades: 0/10	null	2026-06-11 14:02:03.531561+00
707	89	weekly_trade_limit	APPROVED	Weekly trades: 4/30	null	2026-06-11 14:02:03.531563+00
708	89	position_size	APPROVED	Position size check skipped (sell reduces concentration)	null	2026-06-11 14:02:03.531565+00
709	89	portfolio_concentration	APPROVED	Concentration check passed	null	2026-06-11 14:02:03.531566+00
710	89	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-06-11 14:02:03.531568+00
711	89	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-06-11 14:02:03.53157+00
712	89	account_balance	APPROVED	Account balance check skipped (sell generates cash)	null	2026-06-11 14:02:03.531571+00
713	90	market_hours	APPROVED	Market is open	null	2026-06-11 14:02:12.765656+00
714	90	daily_trade_limit	APPROVED	Daily trades: 1/10	null	2026-06-11 14:02:12.765665+00
715	90	weekly_trade_limit	APPROVED	Weekly trades: 5/30	null	2026-06-11 14:02:12.765667+00
716	90	position_size	APPROVED	Position size check skipped (sell reduces concentration)	null	2026-06-11 14:02:12.765669+00
717	90	portfolio_concentration	APPROVED	Concentration check passed	null	2026-06-11 14:02:12.765672+00
718	90	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-06-11 14:02:12.765674+00
719	90	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-06-11 14:02:12.765676+00
720	90	account_balance	APPROVED	Account balance check skipped (sell generates cash)	null	2026-06-11 14:02:12.765678+00
721	91	market_hours	APPROVED	Market is open	null	2026-06-11 14:02:28.824808+00
722	91	daily_trade_limit	APPROVED	Daily trades: 2/10	null	2026-06-11 14:02:28.824813+00
723	91	weekly_trade_limit	APPROVED	Weekly trades: 6/30	null	2026-06-11 14:02:28.824814+00
724	91	position_size	APPROVED	Position size check skipped (sell reduces concentration)	null	2026-06-11 14:02:28.824815+00
725	91	portfolio_concentration	APPROVED	Concentration check passed	null	2026-06-11 14:02:28.824815+00
726	91	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-06-11 14:02:28.824816+00
727	91	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-06-11 14:02:28.824817+00
728	91	account_balance	APPROVED	Account balance check skipped (sell generates cash)	null	2026-06-11 14:02:28.824818+00
729	92	market_hours	APPROVED	Market is open	null	2026-06-15 14:01:47.589638+00
730	92	daily_trade_limit	APPROVED	Daily trades: 0/10	null	2026-06-15 14:01:47.589653+00
731	92	weekly_trade_limit	APPROVED	Weekly trades: 7/30	null	2026-06-15 14:01:47.589657+00
732	92	position_size	APPROVED	Position size check skipped (sell reduces concentration)	null	2026-06-15 14:01:47.58966+00
733	92	portfolio_concentration	APPROVED	Concentration check passed	null	2026-06-15 14:01:47.589663+00
734	92	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-06-15 14:01:47.589666+00
735	92	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-06-15 14:01:47.589669+00
736	92	account_balance	APPROVED	Account balance check skipped (sell generates cash)	null	2026-06-15 14:01:47.589672+00
737	93	market_hours	APPROVED	Market is open	null	2026-06-15 14:02:07.275327+00
738	93	daily_trade_limit	APPROVED	Daily trades: 1/10	null	2026-06-15 14:02:07.275338+00
739	93	weekly_trade_limit	APPROVED	Weekly trades: 8/30	null	2026-06-15 14:02:07.27534+00
740	93	position_size	APPROVED	Position size check skipped (sell reduces concentration)	null	2026-06-15 14:02:07.275342+00
741	93	portfolio_concentration	APPROVED	Concentration check passed	null	2026-06-15 14:02:07.275344+00
742	93	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-06-15 14:02:07.275346+00
743	93	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-06-15 14:02:07.275348+00
744	93	account_balance	APPROVED	Account balance check skipped (sell generates cash)	null	2026-06-15 14:02:07.27535+00
745	94	market_hours	APPROVED	Market is open	null	2026-06-15 14:02:34.373861+00
746	94	daily_trade_limit	APPROVED	Daily trades: 2/10	null	2026-06-15 14:02:34.373874+00
747	94	weekly_trade_limit	APPROVED	Weekly trades: 9/30	null	2026-06-15 14:02:34.373876+00
748	94	position_size	APPROVED	Position size 12.5% within limits	null	2026-06-15 14:02:34.373878+00
749	94	portfolio_concentration	APPROVED	Concentration check passed	null	2026-06-15 14:02:34.37388+00
750	94	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-06-15 14:02:34.373882+00
751	94	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-06-15 14:02:34.373884+00
752	94	account_balance	APPROVED	Sufficient funds ($719.93 available)	null	2026-06-15 14:02:34.373886+00
753	95	market_hours	APPROVED	Market is open	null	2026-06-15 14:02:52.429006+00
754	95	daily_trade_limit	APPROVED	Daily trades: 2/10	null	2026-06-15 14:02:52.429016+00
755	95	weekly_trade_limit	APPROVED	Weekly trades: 9/30	null	2026-06-15 14:02:52.429018+00
756	95	position_size	APPROVED	Position size 16.2% within limits	null	2026-06-15 14:02:52.429021+00
757	95	portfolio_concentration	APPROVED	Concentration check passed	null	2026-06-15 14:02:52.429023+00
758	95	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-06-15 14:02:52.429025+00
759	95	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-06-15 14:02:52.429027+00
760	95	account_balance	APPROVED	Sufficient funds ($719.93 available)	null	2026-06-15 14:02:52.429029+00
761	96	market_hours	APPROVED	Market is open	null	2026-06-15 14:03:11.591893+00
762	96	daily_trade_limit	APPROVED	Daily trades: 2/10	null	2026-06-15 14:03:11.591902+00
763	96	weekly_trade_limit	APPROVED	Weekly trades: 8/30	null	2026-06-15 14:03:11.591905+00
764	96	position_size	APPROVED	Position size 15.7% within limits	null	2026-06-15 14:03:11.591906+00
765	96	portfolio_concentration	APPROVED	Concentration check passed	null	2026-06-15 14:03:11.591908+00
766	96	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-06-15 14:03:11.59191+00
767	96	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-06-15 14:03:11.591912+00
768	96	account_balance	APPROVED	Sufficient funds ($719.93 available)	null	2026-06-15 14:03:11.591914+00
769	97	market_hours	APPROVED	Market is open	null	2026-06-16 14:01:53.524942+00
770	97	daily_trade_limit	APPROVED	Daily trades: 0/10	null	2026-06-16 14:01:53.524955+00
771	97	weekly_trade_limit	APPROVED	Weekly trades: 8/30	null	2026-06-16 14:01:53.524957+00
772	97	position_size	APPROVED	Position size 3.4% within limits	null	2026-06-16 14:01:53.524959+00
773	97	portfolio_concentration	APPROVED	Concentration check passed	null	2026-06-16 14:01:53.524961+00
774	97	daily_loss_limit	APPROVED	Daily P&L: 0.00%	null	2026-06-16 14:01:53.524963+00
775	97	duplicate_trade	APPROVED	No recent duplicate trades	null	2026-06-16 14:01:53.524965+00
776	97	account_balance	APPROVED	Sufficient funds ($578.84 available)	null	2026-06-16 14:01:53.524967+00
\.


--
-- Data for Name: trades; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.trades (id, request_id, "timestamp", ticker, action, quantity, order_type, status, filled_price, commission, order_id, reason, kelly_fraction, half_kelly_fraction, portfolio_value_at_trade, analysis_data, dry_run) FROM stdin;
\.


--
-- Name: bgw_job_id_seq; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: -
--

SELECT pg_catalog.setval('_timescaledb_catalog.bgw_job_id_seq', 1000, false);


--
-- Name: chunk_column_stats_id_seq; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: -
--

SELECT pg_catalog.setval('_timescaledb_catalog.chunk_column_stats_id_seq', 1, false);


--
-- Name: chunk_constraint_name; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: -
--

SELECT pg_catalog.setval('_timescaledb_catalog.chunk_constraint_name', 9, true);


--
-- Name: chunk_id_seq; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: -
--

SELECT pg_catalog.setval('_timescaledb_catalog.chunk_id_seq', 16, true);


--
-- Name: dimension_id_seq; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: -
--

SELECT pg_catalog.setval('_timescaledb_catalog.dimension_id_seq', 3, true);


--
-- Name: dimension_slice_id_seq; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: -
--

SELECT pg_catalog.setval('_timescaledb_catalog.dimension_slice_id_seq', 15, true);


--
-- Name: hypertable_id_seq; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: -
--

SELECT pg_catalog.setval('_timescaledb_catalog.hypertable_id_seq', 3, true);


--
-- Name: claude_decisions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.claude_decisions_id_seq', 97, true);


--
-- Name: portfolio_snapshots_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.portfolio_snapshots_id_seq', 1, true);


--
-- Name: risk_checks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.risk_checks_id_seq', 776, true);


--
-- Name: trades_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.trades_id_seq', 97, true);


--
-- Name: _hyper_2_1_chunk 1_1_trades_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_2_1_chunk
    ADD CONSTRAINT "1_1_trades_pkey" PRIMARY KEY (id, "timestamp");


--
-- Name: _hyper_3_2_chunk 2_2_portfolio_snapshots_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_3_2_chunk
    ADD CONSTRAINT "2_2_portfolio_snapshots_pkey" PRIMARY KEY (id, "timestamp");


--
-- Name: _hyper_2_3_chunk 3_3_trades_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_2_3_chunk
    ADD CONSTRAINT "3_3_trades_pkey" PRIMARY KEY (id, "timestamp");


--
-- Name: _hyper_2_4_chunk 4_4_trades_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_2_4_chunk
    ADD CONSTRAINT "4_4_trades_pkey" PRIMARY KEY (id, "timestamp");


--
-- Name: _hyper_2_5_chunk 5_5_trades_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_2_5_chunk
    ADD CONSTRAINT "5_5_trades_pkey" PRIMARY KEY (id, "timestamp");


--
-- Name: _hyper_2_6_chunk 6_6_trades_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_2_6_chunk
    ADD CONSTRAINT "6_6_trades_pkey" PRIMARY KEY (id, "timestamp");


--
-- Name: _hyper_2_7_chunk 7_7_trades_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_2_7_chunk
    ADD CONSTRAINT "7_7_trades_pkey" PRIMARY KEY (id, "timestamp");


--
-- Name: _hyper_2_8_chunk 8_8_trades_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_2_8_chunk
    ADD CONSTRAINT "8_8_trades_pkey" PRIMARY KEY (id, "timestamp");


--
-- Name: _hyper_2_9_chunk 9_9_trades_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_2_9_chunk
    ADD CONSTRAINT "9_9_trades_pkey" PRIMARY KEY (id, "timestamp");


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: claude_decisions claude_decisions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.claude_decisions
    ADD CONSTRAINT claude_decisions_pkey PRIMARY KEY (id);


--
-- Name: risk_checks risk_checks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.risk_checks
    ADD CONSTRAINT risk_checks_pkey PRIMARY KEY (id);


--
-- Name: _hyper_2_1_chunk_ix_status; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_2_1_chunk_ix_status ON _timescaledb_internal._hyper_2_1_chunk USING btree (status);


--
-- Name: _hyper_2_1_chunk_ix_ticker; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_2_1_chunk_ix_ticker ON _timescaledb_internal._hyper_2_1_chunk USING btree (ticker);


--
-- Name: _hyper_2_1_chunk_ix_timestamp; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_2_1_chunk_ix_timestamp ON _timescaledb_internal._hyper_2_1_chunk USING btree ("timestamp");


--
-- Name: _hyper_2_3_chunk_ix_status; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_2_3_chunk_ix_status ON _timescaledb_internal._hyper_2_3_chunk USING btree (status);


--
-- Name: _hyper_2_3_chunk_ix_ticker; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_2_3_chunk_ix_ticker ON _timescaledb_internal._hyper_2_3_chunk USING btree (ticker);


--
-- Name: _hyper_2_3_chunk_ix_timestamp; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_2_3_chunk_ix_timestamp ON _timescaledb_internal._hyper_2_3_chunk USING btree ("timestamp");


--
-- Name: _hyper_2_4_chunk_ix_status; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_2_4_chunk_ix_status ON _timescaledb_internal._hyper_2_4_chunk USING btree (status);


--
-- Name: _hyper_2_4_chunk_ix_ticker; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_2_4_chunk_ix_ticker ON _timescaledb_internal._hyper_2_4_chunk USING btree (ticker);


--
-- Name: _hyper_2_4_chunk_ix_timestamp; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_2_4_chunk_ix_timestamp ON _timescaledb_internal._hyper_2_4_chunk USING btree ("timestamp");


--
-- Name: _hyper_2_5_chunk_ix_status; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_2_5_chunk_ix_status ON _timescaledb_internal._hyper_2_5_chunk USING btree (status);


--
-- Name: _hyper_2_5_chunk_ix_ticker; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_2_5_chunk_ix_ticker ON _timescaledb_internal._hyper_2_5_chunk USING btree (ticker);


--
-- Name: _hyper_2_5_chunk_ix_timestamp; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_2_5_chunk_ix_timestamp ON _timescaledb_internal._hyper_2_5_chunk USING btree ("timestamp");


--
-- Name: _hyper_2_6_chunk_ix_status; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_2_6_chunk_ix_status ON _timescaledb_internal._hyper_2_6_chunk USING btree (status);


--
-- Name: _hyper_2_6_chunk_ix_ticker; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_2_6_chunk_ix_ticker ON _timescaledb_internal._hyper_2_6_chunk USING btree (ticker);


--
-- Name: _hyper_2_6_chunk_ix_timestamp; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_2_6_chunk_ix_timestamp ON _timescaledb_internal._hyper_2_6_chunk USING btree ("timestamp");


--
-- Name: _hyper_2_7_chunk_ix_status; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_2_7_chunk_ix_status ON _timescaledb_internal._hyper_2_7_chunk USING btree (status);


--
-- Name: _hyper_2_7_chunk_ix_ticker; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_2_7_chunk_ix_ticker ON _timescaledb_internal._hyper_2_7_chunk USING btree (ticker);


--
-- Name: _hyper_2_7_chunk_ix_timestamp; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_2_7_chunk_ix_timestamp ON _timescaledb_internal._hyper_2_7_chunk USING btree ("timestamp");


--
-- Name: _hyper_2_8_chunk_ix_status; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_2_8_chunk_ix_status ON _timescaledb_internal._hyper_2_8_chunk USING btree (status);


--
-- Name: _hyper_2_8_chunk_ix_ticker; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_2_8_chunk_ix_ticker ON _timescaledb_internal._hyper_2_8_chunk USING btree (ticker);


--
-- Name: _hyper_2_8_chunk_ix_timestamp; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_2_8_chunk_ix_timestamp ON _timescaledb_internal._hyper_2_8_chunk USING btree ("timestamp");


--
-- Name: _hyper_2_9_chunk_ix_status; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_2_9_chunk_ix_status ON _timescaledb_internal._hyper_2_9_chunk USING btree (status);


--
-- Name: _hyper_2_9_chunk_ix_ticker; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_2_9_chunk_ix_ticker ON _timescaledb_internal._hyper_2_9_chunk USING btree (ticker);


--
-- Name: _hyper_2_9_chunk_ix_timestamp; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_2_9_chunk_ix_timestamp ON _timescaledb_internal._hyper_2_9_chunk USING btree ("timestamp");


--
-- Name: _hyper_3_2_chunk_ix_portfolio_snapshots_timestamp; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_3_2_chunk_ix_portfolio_snapshots_timestamp ON _timescaledb_internal._hyper_3_2_chunk USING btree ("timestamp");


--
-- Name: ix_claude_decisions_ticker; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_claude_decisions_ticker ON public.claude_decisions USING btree (ticker);


--
-- Name: ix_claude_decisions_timestamp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_claude_decisions_timestamp ON public.claude_decisions USING btree ("timestamp");


--
-- Name: ix_claude_decisions_trade_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_claude_decisions_trade_id ON public.claude_decisions USING btree (trade_id);


--
-- Name: ix_risk_checks_timestamp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_risk_checks_timestamp ON public.risk_checks USING btree ("timestamp");


--
-- Name: ix_trade_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_trade_id ON public.risk_checks USING btree (trade_id);


--
-- PostgreSQL database dump complete
--

\unrestrict 6c6dlX5UwPd37AzwVZmFUVWgGOC3yHyvJAws8rd8bvmxAWJgPuXlhazqkRIPUoB

